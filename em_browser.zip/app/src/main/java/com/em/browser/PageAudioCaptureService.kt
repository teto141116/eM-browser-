package com.em.browser

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

class PageAudioCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.em.browser.action.START_PAGE_AUDIO_CAPTURE"
        const val ACTION_STOP = "com.em.browser.action.STOP_PAGE_AUDIO_CAPTURE"
        const val ACTION_FINISHED = "com.em.browser.action.PAGE_AUDIO_CAPTURE_FINISHED"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        const val EXTRA_OUTPUT_PATH = "page_audio_output_path"
        const val EXTRA_ERROR = "page_audio_capture_error"

        private const val NOTIFICATION_ID = 7104
        private const val CHANNEL_ID = "page_audio_transcription"
        private const val SAMPLE_RATE = 16000
    }

    private val stopRequested = AtomicBoolean(false)
    private val finishing = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var outputPath = ""
    private var audioRecord: AudioRecord? = null
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var captureThread: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture(intent)
            ACTION_STOP -> finishCapture()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        if (captureThread != null) return
        outputPath = intent.getStringExtra(EXTRA_OUTPUT_PATH).orEmpty()
        if (outputPath.isBlank()) {
            finishCapture("No output file was provided.")
            return
        }

        try {
            startCaptureForeground()
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                ?: throw IllegalStateException("Screen capture permission was not returned.")
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val activeProjection = manager.getMediaProjection(resultCode, resultData)
                ?: throw IllegalStateException("Android did not grant audio capture.")
            projection = activeProjection

            val callback = object : MediaProjection.Callback() {
                override fun onStop() {
                    finishCapture(projectionAlreadyStopped = true)
                }
            }
            projectionCallback = callback
            activeProjection.registerCallback(callback, mainHandler)

            val config = android.media.AudioPlaybackCaptureConfiguration.Builder(activeProjection)
                .addMatchingUid(android.os.Process.myUid())
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            val minBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuffer <= 0) throw IllegalStateException("This device cannot capture page audio.")

            val recorder = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(maxOf(minBuffer, SAMPLE_RATE * 2))
                .setAudioPlaybackCaptureConfig(config)
                .build()
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release()
                throw IllegalStateException("Audio capture could not be initialized.")
            }
            audioRecord = recorder
            recorder.startRecording()

            stopRequested.set(false)
            captureThread = Thread({ recordToFile(recorder) }, "page-audio-capture").apply { start() }
        } catch (error: Exception) {
            finishCapture(error.message ?: "Audio capture could not be started.")
        }
    }

    private fun recordToFile(recorder: AudioRecord) {
        var errorMessage: String? = null
        try {
            File(outputPath).parentFile?.mkdirs()
            FileOutputStream(outputPath, false).use { output ->
                val buffer = ByteArray(maxOf(SAMPLE_RATE * 2, 8192))
                while (!stopRequested.get()) {
                    val count = recorder.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING)
                    if (count > 0) {
                        output.write(buffer, 0, count)
                    } else if (count < 0) {
                        errorMessage = "Audio capture stopped unexpectedly ($count)."
                        break
                    }
                }
                output.flush()
            }
        } catch (error: Exception) {
            if (!stopRequested.get()) errorMessage = error.message ?: "Could not save captured audio."
        }
        errorMessage?.let { message -> mainHandler.post { finishCapture(message) } }
    }

    private fun finishCapture(errorMessage: String? = null, projectionAlreadyStopped: Boolean = false) {
        if (!finishing.compareAndSet(false, true)) return
        stopRequested.set(true)

        audioRecord?.let { recorder ->
            runCatching { recorder.stop() }
        }
        runCatching { captureThread?.join(4000L) }
        audioRecord?.let { recorder -> runCatching { recorder.release() } }
        audioRecord = null
        captureThread = null

        projection?.let { activeProjection ->
            projectionCallback?.let { callback -> runCatching { activeProjection.unregisterCallback(callback) } }
            if (!projectionAlreadyStopped) runCatching { activeProjection.stop() }
        }
        projection = null
        projectionCallback = null

        sendBroadcast(
            Intent(ACTION_FINISHED)
                .setPackage(packageName)
                .putExtra(EXTRA_OUTPUT_PATH, outputPath)
                .putExtra(EXTRA_ERROR, errorMessage)
        )
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startCaptureForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Page audio transcription",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Transcribing page audio")
            .setContentText("Play the page audio, then stop capture in eM Browser.")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onDestroy() {
        if (!finishing.get()) finishCapture("Audio capture service stopped.")
        super.onDestroy()
    }
}
