plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.em.browser"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.em.browser"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    flavorDimensions += "edition"
    productFlavors {
        create("basic") {
            dimension = "edition"
            applicationId = "com.em.browser"
            resValue("string", "app_name", "eM gmail")
        }
        create("copy1") {
            dimension = "edition"
            applicationIdSuffix = ".copy1"
            versionNameSuffix = "-copy1"
            resValue("string", "app_name", "eM gmail 2")
        }
        create("copy2") {
            dimension = "edition"
            applicationIdSuffix = ".copy2"
            versionNameSuffix = "-copy2"
            resValue("string", "app_name", "eM gmail 3")
        }
        create("copy3") {
            dimension = "edition"
            applicationIdSuffix = ".copy3"
            versionNameSuffix = "-copy3"
            resValue("string", "app_name", "eM gmail 4")
        }
        create("copy4") {
            dimension = "edition"
            applicationIdSuffix = ".copy4"
            versionNameSuffix = "-copy4"
            resValue("string", "app_name", "eM gmail 5")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.drawerlayout:drawerlayout:1.2.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.webkit:webkit:1.9.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.zxing:core:3.5.3")
}
