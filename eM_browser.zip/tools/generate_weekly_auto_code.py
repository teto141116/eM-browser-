#!/usr/bin/env python3
import hashlib,hmac,datetime
SECRET=bytes.fromhex("71ed4e7f9b48b6bfa75c6b64ca9dc26f9ac1c849f4be01896e157a6e09a50b6a")
ALPHABET="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
d=datetime.datetime.now(datetime.timezone.utc).date(); iso=d.isocalendar(); week=f"{iso.year:04d}-{iso.week:02d}"
digest=hmac.new(SECRET,week.encode(),hashlib.sha256).digest(); acc=bits=0; out=[]
for b in digest:
 acc=(acc<<8)|b; bits+=8
 while bits>=5 and len(out)<12:
  bits-=5; out.append(ALPHABET[(acc>>bits)&31])
print("".join(out))
