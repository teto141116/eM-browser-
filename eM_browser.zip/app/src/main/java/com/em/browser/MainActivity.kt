package com.em.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.materialswitch.MaterialSwitch
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var incognitoSwitch: MaterialSwitch

    private var incognitoEnabled = false
    private var isFinishingForBack = false

    companion object {
        private const val HOME_URL = "https://accounts.google.com/?hl=ar"
        private const val PREFS = "browser_prefs"
        private const val KEY_INCOGNITO = "incognito"
        private const val ARABIC_UA_MARKER = "eM-browser/1.0"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        incognitoSwitch = findViewById(R.id.incognitoSwitch)

        incognitoEnabled = getSharedPreferences(PREFS, MODE_PRIVATE)
            .getBoolean(KEY_INCOGNITO, false)

        incognitoSwitch.isChecked = incognitoEnabled
        incognitoSwitch.setOnCheckedChangeListener { _, checked ->
            setIncognitoMode(checked)
        }

        configureWebView()
        webView.loadUrl(HOME_URL)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isFinishingForBack = true
                    finish()
                }
            }
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        WebView.setWebContentsDebuggingEnabled(false)

        webView.settings.apply {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)

            builtInZoomControls = false
            displayZoomControls = false

            domStorageEnabled = !incognitoEnabled
            databaseEnabled = !incognitoEnabled

            cacheMode = if (incognitoEnabled) {
                WebSettings.LOAD_NO_CACHE
            } else {
                WebSettings.LOAD_DEFAULT
            }

            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false
            allowContentAccess = false

            userAgentString = buildArabicUserAgent()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            webView.importantForAutofill =
                View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webView.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }

        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val url = request.url.toString()
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    view.loadUrl(withArabicLanguage(url))
                    return true
                }
                return true
            }

            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    view.loadUrl(withArabicLanguage(url))
                    return true
                }
                return true
            }
        }

        if (incognitoEnabled) {
            clearPrivateData()
        }
    }

    private fun setIncognitoMode(enabled: Boolean) {
        if (incognitoEnabled == enabled) return

        incognitoEnabled = enabled
        getSharedPreferences(PREFS, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_INCOGNITO, enabled)
            .apply()

        if (enabled) {
            clearPrivateData()
        }

        configureWebView()

        val currentUrl = webView.url
        if (!currentUrl.isNullOrBlank()) {
            webView.loadUrl(withArabicLanguage(currentUrl))
        } else {
            webView.loadUrl(HOME_URL)
        }
    }

    private fun clearPrivateData() {
        webView.clearHistory()
        webView.clearCache(true)
        webView.clearFormData()
        webView.clearSslPreferences()

        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()

        WebStorage.getInstance().deleteAllData()
    }

    private fun buildArabicUserAgent(): String {
        val defaultUa = WebSettings.getDefaultUserAgent(this)
        return "$defaultUa $ARABIC_UA_MARKER (ar-EG)"
    }

    private fun withArabicLanguage(rawUrl: String): String {
        return try {
            if (!rawUrl.startsWith("http://") && !rawUrl.startsWith("https://")) {
                rawUrl
            } else if (rawUrl.contains("hl=", ignoreCase = true)) {
                rawUrl
            } else {
                val separator = if (rawUrl.contains("?")) "&" else "?"
                "$rawUrl${separator}hl=ar"
            }
        } catch (_: Exception) {
            rawUrl
        }
    }

    override fun onDestroy() {
        if (incognitoEnabled) {
            clearPrivateData()
        }

        webView.stopLoading()
        webView.webChromeClient = null
        webView.destroy()

        super.onDestroy()
    }
}
