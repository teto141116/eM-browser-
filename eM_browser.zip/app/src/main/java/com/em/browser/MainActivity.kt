package com.em.browser

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebViewDatabase
import java.io.File
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private data class BrowserTab(val webView: WebView, var title: String = "New tab")

    private val tabs = mutableListOf<BrowserTab>()
    private var activeTab = 0
    private lateinit var rootLayout: LinearLayout
    private lateinit var toolbar: MaterialToolbar
    private lateinit var tabsBar: LinearLayout
    private lateinit var contentFrame: LinearLayout

    private var incognitoEnabled = false
    private var darkModeEnabled = false
    private var zoomPercent = 100

    companion object {
        private const val HOME_URL = "https://accounts.google.com/?hl=ar"
        private const val PREFS = "browser_prefs"
        private const val KEY_INCOGNITO = "incognito"
        private const val KEY_DARK = "dark"
        private const val KEY_ZOOM = "zoom"
        private const val MIN_ZOOM = 50
        private const val MAX_ZOOM = 120
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        incognitoEnabled = prefs.getBoolean(KEY_INCOGNITO, false)
        darkModeEnabled = prefs.getBoolean(KEY_DARK, false)
        zoomPercent = prefs.getInt(KEY_ZOOM, 100).coerceIn(MIN_ZOOM, MAX_ZOOM)

        AppCompatDelegate.setDefaultNightMode(
            if (darkModeEnabled) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )

        buildInterface()
        addTab(HOME_URL)
    }

    private fun buildInterface() {
        rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        toolbar = MaterialToolbar(this).apply {
            title = "eM browser"
            setTitleTextAppearance(this@MainActivity, com.google.android.material.R.style.TextAppearance_Material3_TitleLarge)
            titleMarginStart = dp(12)
            elevation = dp(2).toFloat()
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
            setTitleTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
        }

        toolbar.menu.add(Menu.NONE, 1001, Menu.NONE, "القائمة").apply {
            setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
            setIcon(android.R.drawable.ic_menu_more)
        }
        toolbar.setOnMenuItemClickListener {
            if (it.itemId == 1001) {
                showBrowserMenu(toolbar)
                true
            } else false
        }

        tabsBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(5), dp(6), dp(5))
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurfaceVariant))
        }

        contentFrame = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        rootLayout.addView(toolbar, LinearLayout.LayoutParams(-1, dp(56)))
        rootLayout.addView(tabsBar, LinearLayout.LayoutParams(-1, dp(50)))
        rootLayout.addView(contentFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(rootLayout)

        toolbar.post {
            for (i in 0 until toolbar.childCount) {
                val child = toolbar.getChildAt(i)
                if (child is TextView && child.text?.toString() == "eM browser") {
                    child.setTypeface(child.typeface, android.graphics.Typeface.BOLD)
                    break
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun addTab(url: String) {
        val webView = WebView(this)
        val tab = BrowserTab(webView)
        tabs.add(tab)
        configureWebView(webView)
        activeTab = tabs.lastIndex
        showActiveWebView()
        webView.loadUrl(withArabicLanguage(url))
        rebuildTabsBar()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(webView: WebView) {
        webView.settings.apply {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            builtInZoomControls = false
            displayZoomControls = false
            domStorageEnabled = !incognitoEnabled
            databaseEnabled = !incognitoEnabled
            cacheMode = if (incognitoEnabled) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false
            allowContentAccess = false
            textZoom = zoomPercent
            userAgentString = "${WebSettings.getDefaultUserAgent(this@MainActivity)} eM-browser/2.0 (ar-EG)"
        }

        webView.setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                view.loadUrl(withArabicLanguage(request.url.toString()))
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.settings.textZoom = zoomPercent
                val index = tabs.indexOfFirst { it.webView === view }
                if (index >= 0) {
                    tabs[index].title = view.title?.ifBlank { "eM browser" } ?: "eM browser"
                    if (index == activeTab) rebuildTabsBar()
                }
            }
        }
    }

    private fun showActiveWebView() {
        contentFrame.removeAllViews()
        val webView = tabs[activeTab].webView
        val refresh = SwipeRefreshLayout(this).apply {
            setColorSchemeColors(resolveColor(com.google.android.material.R.attr.colorPrimary))
            addView(webView, ViewGroup.LayoutParams(-1, -1))
            setOnRefreshListener {
                webView.reload()
                postDelayed({ isRefreshing = false }, 800)
            }
        }
        contentFrame.addView(refresh, LinearLayout.LayoutParams(-1, -1))
        rebuildTabsBar()
    }

    private fun rebuildTabsBar() {
        tabsBar.removeAllViews()
        tabs.forEachIndexed { index, tab ->
            val holder = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(9), 0, dp(3), 0)
                setBackgroundColor(
                    if (index == activeTab) resolveColor(com.google.android.material.R.attr.colorSurface)
                    else resolveColor(com.google.android.material.R.attr.colorSurfaceVariant)
                )
                setOnClickListener { activeTab = index; showActiveWebView() }
            }

            val title = TextView(this).apply {
                text = tab.title.take(18).ifBlank { "New tab" }
                textSize = 13f * zoomPercent / 100f
                setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER_VERTICAL
            }

            val close = TextView(this).apply {
                text = "×"
                textSize = 20f
                gravity = Gravity.CENTER
                setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
                setOnClickListener { closeTab(index) }
            }

            holder.addView(title, LinearLayout.LayoutParams(0, -1, 1f))
            holder.addView(close, LinearLayout.LayoutParams(dp(30), -1))
            tabsBar.addView(holder, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
        }

        val add = TextView(this).apply {
            text = "+"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setOnClickListener { addTab(HOME_URL) }
        }
        tabsBar.addView(add, LinearLayout.LayoutParams(dp(46), dp(40)))
    }

    private fun closeTab(index: Int) {
        if (tabs.size == 1) {
            tabs[0].webView.loadUrl(HOME_URL)
            tabs[0].title = "New tab"
            rebuildTabsBar()
            return
        }
        val tab = tabs.removeAt(index)
        tab.webView.stopLoading()
        tab.webView.destroy()
        activeTab = when {
            activeTab >= tabs.size -> tabs.lastIndex
            index < activeTab -> activeTab - 1
            else -> activeTab
        }
        showActiveWebView()
    }

    private fun showBrowserMenu(anchor: View) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(4))
        }

        fun switchRow(labelText: String, checked: Boolean, onChanged: (Boolean) -> Unit): LinearLayout {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val label = TextView(this).apply {
                text = labelText
                textSize = 16f
                setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            }
            val toggle = MaterialSwitch(this).apply {
                isChecked = checked
                setOnCheckedChangeListener { _, value -> onChanged(value) }
            }
            row.addView(label, LinearLayout.LayoutParams(0, dp(52), 1f))
            row.addView(toggle, LinearLayout.LayoutParams(dp(64), dp(52)))
            return row
        }

        box.addView(switchRow("التصفح الخفي", incognitoEnabled) { value ->
            setIncognitoMode(value)
        })

        box.addView(switchRow("الوضع الداكن", darkModeEnabled) { value ->
            setDarkMode(value)
        })

        val zoomButton = TextView(this).apply {
            text = "حجم النص والواجهة: $zoomPercent%"
            textSize = 16f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12))
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setOnClickListener { showZoomDialog() }
        }
        box.addView(zoomButton)

        val refreshButton = TextView(this).apply {
            text = "تحديث الصفحة"
            textSize = 16f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12))
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setOnClickListener { currentWebView()?.reload() }
        }
        box.addView(refreshButton)

        val newTabButton = TextView(this).apply {
            text = "تبويب جديد"
            textSize = 16f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12))
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setOnClickListener { addTab(HOME_URL) }
        }
        box.addView(newTabButton)

        val clearDataButton = TextView(this).apply {
            text = "حذف جميع بيانات المتصفح"
            textSize = 16f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(14))
            setTextColor(resolveColor(com.google.android.material.R.attr.colorError))
            setOnClickListener { showClearAllDataDialog() }
        }
        box.addView(clearDataButton)

        AlertDialog.Builder(this)
            .setTitle("القائمة")
            .setView(box)
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun showClearAllDataDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(4))
        }

        val period = TextView(this).apply {
            text = "الفترة الزمنية: جميع الأوقات"
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, dp(4), 0, dp(12))
        }
        box.addView(period)

        val items = listOf(
            "سجل التصفح",
            "علامات التبويب والجلسات",
            "ملفات تعريف الارتباط وبيانات المواقع",
            "الصور والملفات المخزنة مؤقتًا",
            "بيانات النماذج",
            "كلمات المرور وبيانات تسجيل الدخول",
            "بيانات Web Storage وLocal Storage",
            "بيانات الموقع وإعدادات المواقع"
        )

        items.forEach { textValue ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val label = TextView(this).apply {
                text = textValue
                textSize = 15f
                setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            }
            val check = MaterialSwitch(this).apply {
                isChecked = true
                isEnabled = false
                contentDescription = textValue
            }
            row.addView(label, LinearLayout.LayoutParams(0, dp(44), 1f))
            row.addView(check, LinearLayout.LayoutParams(dp(64), dp(44)))
            box.addView(row)
        }

        box.addView(TextView(this).apply {
            text = "سيتم حذف كل البيانات التي يحتفظ بها eM browser، وستُغلق التبويبات الحالية وتبدأ جلسة جديدة."
            textSize = 13f
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            setPadding(0, dp(10), 0, dp(4))
        })

        AlertDialog.Builder(this)
            .setTitle("حذف جميع بيانات المتصفح")
            .setView(box)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حذف جميع البيانات") { _, _ ->
                clearAllBrowserData()
            }
            .show()
    }

    /**
     * Resets eM browser to a first-install state without uninstalling the APK.
     * All browser/site data and all app preferences created by the browser are removed.
     */
    private fun clearAllBrowserData() {
        // Destroy every WebView first so no page can recreate data while we are clearing it.
        tabs.forEach { tab ->
            tab.webView.stopLoading()
            tab.webView.clearHistory()
            tab.webView.clearCache(true)
            tab.webView.clearFormData()
            tab.webView.clearSslPreferences()
            tab.webView.clearMatches()
            tab.webView.destroy()
        }
        tabs.clear()
        activeTab = 0

        // Clear WebView's shared browser stores.
        WebStorage.getInstance().deleteAllData()
        val webViewDatabase = WebViewDatabase.getInstance(this)
        webViewDatabase.clearHttpAuthUsernamePassword()
        webViewDatabase.clearFormData()
        webViewDatabase.clearUsernamePassword()

        // Cookie deletion is asynchronous; finish the reset only after it completes.
        val cookieManager = CookieManager.getInstance()
        cookieManager.removeAllCookies {
            cookieManager.removeSessionCookies {
                cookieManager.flush()
                finishFullBrowserReset()
            }
        }
        cookieManager.flush()
    }

    private fun finishFullBrowserReset() {
        // Remove all preferences saved by eM browser, including appearance and zoom settings.
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().commit()
        incognitoEnabled = false
        darkModeEnabled = false
        zoomPercent = 100

        // Remove app-private files, databases, caches, and preferences created at runtime.
        deleteDirectoryContents(filesDir)
        deleteDirectoryContents(cacheDir)
        deleteDirectoryContents(noBackupFilesDir)
        deleteDirectoryContents(File(applicationInfo.dataDir, "shared_prefs"))
        databaseList().forEach { name -> deleteDatabase(name) }
        externalCacheDir?.let { deleteDirectoryContents(it) }

        // WebView can keep additional runtime data under app_webview/code_cache.
        File(applicationInfo.dataDir, "app_webview").let { if (it.exists()) it.deleteRecursively() }
        File(applicationInfo.dataDir, "code_cache").let { if (it.exists()) it.deleteRecursively() }

        // Re-read the same defaults used by a brand-new installation.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        // Recreate the activity so a completely fresh WebView and UI are constructed.
        recreate()
    }

    private fun deleteDirectoryContents(directory: File) {
        directory.listFiles()?.forEach { file ->
            if (file.isDirectory) file.deleteRecursively() else file.delete()
        }
    }

    private fun showZoomDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), dp(8))
        }
        val label = TextView(this).apply {
            text = "حجم النص والواجهة: $zoomPercent%"
            textSize = 17f
        }
        val seek = SeekBar(this).apply {
            min = MIN_ZOOM
            max = MAX_ZOOM
            progress = zoomPercent
        }
        box.addView(label)
        box.addView(seek)

        val dialog = AlertDialog.Builder(this)
            .setTitle("حجم النص والواجهة")
            .setView(box)
            .setPositiveButton("تم", null)
            .create()

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                zoomPercent = value.coerceIn(MIN_ZOOM, MAX_ZOOM)
                label.text = "حجم النص والواجهة: $zoomPercent%"
                tabs.forEach { it.webView.settings.textZoom = zoomPercent }
                rebuildTabsBar()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        dialog.setOnDismissListener {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_ZOOM, zoomPercent).apply()
        }
        dialog.show()
    }

    private fun setIncognitoMode(enabled: Boolean) {
        incognitoEnabled = enabled
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_INCOGNITO, enabled).apply()
        if (enabled) clearPrivateData()
        tabs.forEach {
            it.webView.settings.domStorageEnabled = !enabled
            it.webView.settings.databaseEnabled = !enabled
            it.webView.settings.cacheMode = if (enabled) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        }
    }

    private fun clearPrivateData() {
        tabs.forEach {
            it.webView.clearHistory()
            it.webView.clearCache(true)
            it.webView.clearFormData()
            it.webView.clearSslPreferences()
        }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
    }

    private fun setDarkMode(enabled: Boolean) {
        darkModeEnabled = enabled
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_DARK, enabled).apply()
        AppCompatDelegate.setDefaultNightMode(
            if (enabled) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    private fun currentWebView(): WebView? = tabs.getOrNull(activeTab)?.webView

    private fun withArabicLanguage(url: String): String {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return url
        if (url.contains("hl=", ignoreCase = true)) return url
        return url + if (url.contains("?")) "&hl=ar" else "?hl=ar"
    }

    private fun resolveColor(attr: Int): Int {
        val value = android.util.TypedValue()
        theme.resolveAttribute(attr, value, true)
        return if (value.resourceId != 0) ContextCompat.getColor(this, value.resourceId) else value.data
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (incognitoEnabled) clearPrivateData()
        tabs.forEach { it.webView.stopLoading(); it.webView.destroy() }
        super.onDestroy()
    }
}
