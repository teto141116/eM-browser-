package com.em.browser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebChromeClient
import android.webkit.WebStorage
import android.webkit.WebViewDatabase
import java.io.File
import android.webkit.WebView
import android.webkit.WebViewClient
import android.animation.ObjectAnimator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private data class BrowserTab(var webView: WebView, var title: String = "New tab", var thumbnail: Bitmap? = null)

    private val tabs = mutableListOf<BrowserTab>()
    private var activeTab = 0
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var rootLayout: LinearLayout
    private lateinit var chromeBar: LinearLayout
    private lateinit var addressBar: android.widget.EditText
    private lateinit var tabCountView: TextView
    private lateinit var contentFrame: LinearLayout
    private lateinit var pageProgress: ProgressBar
    private lateinit var sideMenu: LinearLayout
    private lateinit var systemBottomSpacer: View
    private var progressAnimator: ObjectAnimator? = null

    private var incognitoEnabled = false
    private var darkModeEnabled = false
    private var zoomPercent = 100

    companion object {
        private const val HOME_URL = "https://www.google.com/?hl=ar"
        private const val PREFS = "browser_prefs"
        private const val KEY_INCOGNITO = "incognito"
        private const val KEY_DARK = "dark"
        private const val KEY_ZOOM = "zoom"
        private const val MIN_ZOOM = 50
        private const val MAX_ZOOM = 120
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        incognitoEnabled = prefs.getBoolean(KEY_INCOGNITO, false)
        darkModeEnabled = prefs.getBoolean(KEY_DARK, false)
        zoomPercent = prefs.getInt(KEY_ZOOM, 100).coerceIn(MIN_ZOOM, MAX_ZOOM)

        AppCompatDelegate.setDefaultNightMode(
            if (darkModeEnabled) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )

        buildInterface()
        addTab(HOME_URL)
    }

    private fun buildInterface() {
        // Keep the Android status/navigation areas visible instead of drawing the browser UI over them.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = resolveColor(com.google.android.material.R.attr.colorSurface)
        window.navigationBarColor = resolveColor(com.google.android.material.R.attr.colorSurface)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !darkModeEnabled
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !darkModeEnabled

        drawerLayout = DrawerLayout(this).apply {
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        // Android 15 can enforce edge-to-edge for targetSdk 35. Explicitly reserve the system-bar space.
        // Keep browser content below the Android status bar and, importantly,
        // reserve the full navigation-bar area at the bottom. Some Android
        // devices use an overlay/gesture navigation bar, so relying only on
        // WebView scrolling can leave website footer links (Privacy, Terms,
        // Language, etc.) underneath the phone's navigation controls.
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, bars.top, 0, 0)
            if (::systemBottomSpacer.isInitialized) {
                systemBottomSpacer.layoutParams = systemBottomSpacer.layoutParams.apply {
                    height = bars.bottom
                }
                systemBottomSpacer.requestLayout()
            }
            insets
        }

        chromeBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(4), dp(5), dp(4), dp(5))
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
            elevation = dp(2).toFloat()
        }

        fun chromeButton(label: String, size: Float = 24f): TextView = TextView(this).apply {
            text = label
            textSize = size
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            isClickable = true
            isFocusable = true
            background = null
        }

        val menuButton = chromeButton("⋮", 30f).apply {
            contentDescription = "القائمة"
            setOnClickListener { drawerLayout.openDrawer(Gravity.END) }
        }
        chromeBar.addView(menuButton, LinearLayout.LayoutParams(dp(44), dp(48)))

        tabCountView = chromeButton("1", 12f).apply {
            contentDescription = "علامات التبويب"
            setPadding(dp(5), dp(3), dp(5), dp(3))
            background = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.bg_tab_count)
            setOnClickListener { showTabSwitcher() }
        }
        chromeBar.addView(tabCountView, LinearLayout.LayoutParams(dp(22), dp(24)).apply { gravity = Gravity.CENTER_VERTICAL })

        val addButton = chromeButton("+", 30f).apply {
            contentDescription = "تبويب جديد"
            setOnClickListener { addTab(HOME_URL) }
        }
        chromeBar.addView(addButton, LinearLayout.LayoutParams(dp(44), dp(48)))

        addressBar = android.widget.EditText(this).apply {
            textSize = 16f
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setHintTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            hint = "بحث أو إدخال عنوان"
            setPadding(dp(14), 0, dp(14), 0)
            background = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.bg_address_bar)
            isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setOnEditorActionListener { v, _, _ ->
                loadAddress(v.text?.toString().orEmpty())
                true
            }
        }
        chromeBar.addView(addressBar, LinearLayout.LayoutParams(0, dp(40), 1f).apply {
            gravity = Gravity.CENTER_VERTICAL
            marginStart = dp(7)
            marginEnd = dp(7)
        })

        val homeButton = chromeButton("⌂", 28f).apply {
            contentDescription = "الصفحة الرئيسية"
            setOnClickListener { currentWebView()?.loadUrl(HOME_URL) }
        }
        chromeBar.addView(homeButton, LinearLayout.LayoutParams(dp(48), dp(48)))

        // Standard browser-style page loading indicator: a thin, natural blue line
        // directly below the tab/address bar. It does not consume the status-bar area.
        pageProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            isIndeterminate = false
            visibility = View.GONE
            progressDrawable = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.progress_page)
            setPadding(0, 0, 0, 0)
        }

        contentFrame = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // A dedicated inset spacer guarantees that the bottom of every WebView
        // stays above the phone's system navigation/gesture area.
        systemBottomSpacer = View(this).apply {
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        rootLayout.addView(chromeBar, LinearLayout.LayoutParams(-1, dp(58)))
        rootLayout.addView(pageProgress, LinearLayout.LayoutParams(-1, dp(3)))
        rootLayout.addView(contentFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        rootLayout.addView(systemBottomSpacer, LinearLayout.LayoutParams(-1, 0))

        drawerLayout.addView(rootLayout, DrawerLayout.LayoutParams(-1, -1))
        buildSideMenu()
        drawerLayout.addView(sideMenu, DrawerLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.END
            topMargin = dp(12)
            bottomMargin = dp(12)
        })
        ViewCompat.setOnApplyWindowInsetsListener(drawerLayout) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val lp = sideMenu.layoutParams as DrawerLayout.LayoutParams
            lp.topMargin = bars.top + dp(12)
            lp.bottomMargin = bars.bottom + dp(12)
            sideMenu.layoutParams = lp
            insets
        }
        setContentView(drawerLayout)
    }

    private fun buildSideMenu() {
        sideMenu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(16), 0, dp(10))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(28).toFloat()
                setColor(resolveColor(com.google.android.material.R.attr.colorSurface))
            }
            elevation = dp(8).toFloat()
            clipToOutline = true
        }

        val title = TextView(this).apply {
            text = "eM browser"
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(dp(28), dp(6), dp(28), dp(12))
        }
        sideMenu.addView(title)

        fun menuItem(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
            text = label
            textSize = 15.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(dp(28), 0, dp(28), 0)
            // No pressed/selected highlight color: keep the app monochrome.
            background = null
            setOnClickListener { onClick() }
        }

        sideMenu.addView(menuItem("Refresh Page") { currentWebView()?.reload(); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("New Tab") { addTab(HOME_URL); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Incognito") { setIncognitoMode(!incognitoEnabled); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Dark Mode") { setDarkMode(!darkModeEnabled); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Text Size") { drawerLayout.closeDrawer(Gravity.END); showZoomDialog() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Clear Browsing Data") { drawerLayout.closeDrawer(Gravity.END); showClearAllDataDialog() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
    }

    private fun captureTabThumbnail(tab: BrowserTab): Bitmap? {
        val webView = tab.webView
        if (webView.width <= 0 || webView.height <= 0) return tab.thumbnail
        return try {
            val maxWidth = dp(170)
            val ratio = maxWidth.toFloat() / webView.width.toFloat()
            val bitmap = Bitmap.createBitmap(maxWidth, (webView.height * ratio).toInt().coerceAtLeast(dp(120)), Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.scale(ratio, ratio)
            webView.draw(canvas)
            bitmap
        } catch (_: Throwable) {
            tab.thumbnail
        }
    }

    private fun showTabSwitcher() {
        if (tabs.isNotEmpty()) {
            tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
        }

        val backgroundColor = if (darkModeEnabled) Color.BLACK else Color.rgb(248, 248, 248)
        val textColor = if (darkModeEnabled) Color.WHITE else Color.rgb(35, 35, 35)
        val secondaryColor = if (darkModeEnabled) Color.LTGRAY else Color.DKGRAY
        val cardColor = if (darkModeEnabled) Color.rgb(28, 28, 28) else Color.WHITE
        val dialogRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(backgroundColor)
        }
        lateinit var dialog: AlertDialog

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(8))
        }
        val title = TextView(this).apply {
            text = "Tabs (${tabs.size})"
            textSize = 19f
            setTextColor(textColor)
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        dialogRoot.addView(header, LinearLayout.LayoutParams(-1, dp(48)))

        val grid = android.widget.GridLayout(this).apply {
            columnCount = 2
            rowCount = (tabs.size + 1) / 2
            useDefaultMargins = false
        }
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            addView(grid, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        dialogRoot.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val horizontalGap = dp(8)
        val verticalGap = dp(10)
        val cardHeight = dp(220)

        tabs.forEachIndexed { index, tab ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(18).toFloat()
                    setColor(cardColor)
                    setStroke(dp(1), if (index == activeTab) {
                        if (darkModeEnabled) Color.WHITE else Color.DKGRAY
                    } else {
                        if (darkModeEnabled) Color.DKGRAY else Color.rgb(225, 225, 225)
                    })
                }
                elevation = dp(1).toFloat()
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    if (tabs.isNotEmpty()) {
                        tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
                    }
                    activeTab = index
                    dialog.dismiss()
                    showActiveWebView()
                }
            }

            val topRow = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(2), 0, 0, dp(4))
            }
            val tabTitle = TextView(this).apply {
                text = tab.title.ifBlank { "New tab" }
                textSize = 14f
                setTextColor(textColor)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER_VERTICAL
            }
            topRow.addView(tabTitle, LinearLayout.LayoutParams(0, dp(30), 1f))

            val close = TextView(this).apply {
                text = "×"
                textSize = 25f
                gravity = Gravity.CENTER
                setTextColor(secondaryColor)
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    closeTab(index)
                    dialog.dismiss()
                    if (tabs.isNotEmpty()) showTabSwitcher()
                }
            }
            topRow.addView(close, LinearLayout.LayoutParams(dp(32), dp(30)))
            card.addView(topRow, LinearLayout.LayoutParams(-1, dp(34)))

            val thumbnail = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(if (darkModeEnabled) Color.rgb(45, 45, 45) else Color.rgb(242, 242, 242))
                clipToOutline = true
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: android.graphics.Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, dp(13).toFloat())
                    }
                }
                tab.thumbnail?.let { setImageBitmap(it) }
                if (drawable == null) {
                    setImageDrawable(ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.ic_em_browser))
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                }
            }
            card.addView(thumbnail, LinearLayout.LayoutParams(-1, 0, 1f))

            val lp = android.widget.GridLayout.LayoutParams().apply {
                width = 0
                height = cardHeight
                columnSpec = android.widget.GridLayout.spec(index % 2, 1, 1f)
                rowSpec = android.widget.GridLayout.spec(index / 2)
                setMargins(if (index % 2 == 0) 0 else horizontalGap / 2, verticalGap / 2,
                    if (index % 2 == 0) horizontalGap / 2 else 0, verticalGap / 2)
            }
            grid.addView(card, lp)
        }

        val newTabButton = TextView(this).apply {
            text = "+  New Tab"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(textColor)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(if (darkModeEnabled) Color.rgb(35, 35, 35) else Color.WHITE)
                setStroke(dp(1), if (darkModeEnabled) Color.DKGRAY else Color.rgb(225, 225, 225))
            }
            isClickable = true
            isFocusable = true
            setOnClickListener {
                dialog.dismiss()
                addTab(HOME_URL)
            }
        }
        dialogRoot.addView(newTabButton, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(8)
        })

        dialog = AlertDialog.Builder(this)
            .setView(dialogRoot)
            .create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(22).toFloat()
                setColor(backgroundColor)
            })
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.96f).toInt(),
                (resources.displayMetrics.heightPixels * 0.88f).toInt())
        }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.96f).toInt(),
            (resources.displayMetrics.heightPixels * 0.88f).toInt())
    }

    private fun loadAddress(raw: String) {
        val input = raw.trim()
        if (input.isBlank()) return
        val url = if (android.util.Patterns.WEB_URL.matcher(input).matches() &&
            (input.startsWith("http://") || input.startsWith("https://"))) {
            input
        } else if (input.contains(".") && !input.contains(" ")) {
            "https://$input"
        } else {
            "https://www.google.com/search?q=" + android.net.Uri.encode(input)
        }
        progressAnimator?.cancel()
        pageProgress.progress = 0
        pageProgress.visibility = View.VISIBLE
        currentWebView()?.loadUrl(withArabicLanguage(url))
        addressBar.clearFocus()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun addTab(url: String) {
        if (tabs.isNotEmpty()) {
            tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
        }
        val webView = WebView(this)
        val tab = BrowserTab(webView)
        tabs.add(tab)
        configureWebView(webView)
        activeTab = tabs.lastIndex
        showActiveWebView()
        progressAnimator?.cancel()
        pageProgress.progress = 0
        pageProgress.visibility = View.VISIBLE
        webView.loadUrl(withArabicLanguage(url))
        updateChromeBar()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(webView: WebView) {
        webView.settings.apply {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            builtInZoomControls = false
            displayZoomControls = false
            domStorageEnabled = !incognitoEnabled
            databaseEnabled = !incognitoEnabled
            cacheMode = if (incognitoEnabled) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false
            allowContentAccess = false
            textZoom = zoomPercent
            userAgentString = "${WebSettings.getDefaultUserAgent(this@MainActivity)} eM-browser/2.0 (ar-EG)"
        }

        webView.setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (::pageProgress.isInitialized && view === currentWebView()) {
                    val target = newProgress.coerceIn(0, 100)
                    if (target < 100) {
                        pageProgress.visibility = View.VISIBLE
                    }
                    progressAnimator?.cancel()
                    progressAnimator = ObjectAnimator.ofInt(pageProgress, "progress", pageProgress.progress, target).apply {
                        duration = if (target >= 100) 220L else 260L
                        start()
                    }
                    if (target >= 100) {
                        pageProgress.postDelayed({
                            if (pageProgress.progress >= 100) pageProgress.visibility = View.GONE
                        }, 240L)
                    }
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                view.loadUrl(withArabicLanguage(request.url.toString()))
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.settings.textZoom = zoomPercent
                val index = tabs.indexOfFirst { it.webView === view }
                if (index >= 0) {
                    tabs[index].title = view.title?.ifBlank { "eM browser" } ?: "eM browser"
                    if (index == activeTab) {
                        updateChromeBar()
                        addressBar.setText(url ?: view.url ?: "")
                    }
                }
            }

            override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                // Recover from a WebView renderer crash without taking down the
                // whole browser. This is important when several tabs are open.
                val index = tabs.indexOfFirst { it.webView === view }
                if (index < 0) return true

                val urlToRestore = view.url ?: HOME_URL
                (view.parent as? ViewGroup)?.removeView(view)
                view.stopLoading()
                view.destroy()

                val replacement = WebView(this@MainActivity)
                val oldTitle = tabs[index].title
                tabs[index].webView = replacement
                tabs[index].title = oldTitle
                configureWebView(replacement)

                if (index == activeTab) {
                    showActiveWebView()
                    replacement.loadUrl(withArabicLanguage(urlToRestore))
                } else {
                    replacement.loadUrl(withArabicLanguage(urlToRestore))
                }
                return true
            }
        }
    }

    private fun showActiveWebView() {
        // A WebView can only have one parent. The previous implementation left
        // an inactive WebView attached to its old SwipeRefreshLayout after the
        // tab container was removed, which could crash when switching between
        // multiple tabs (especially when the same page was opened more than once).
        val webView = tabs.getOrNull(activeTab)?.webView ?: return
        (webView.parent as? ViewGroup)?.removeView(webView)
        contentFrame.removeAllViews()

        val refresh = SwipeRefreshLayout(this).apply {
            setColorSchemeColors(ContextCompat.getColor(this@MainActivity, R.color.page_progress_blue))
            addView(webView, ViewGroup.LayoutParams(-1, -1))
            setOnRefreshListener {
                webView.reload()
                postDelayed({ isRefreshing = false }, 800)
            }
        }
        contentFrame.addView(refresh, LinearLayout.LayoutParams(-1, -1))
        updateChromeBar()
    }

    private fun updateChromeBar() {
        if (::tabCountView.isInitialized) tabCountView.text = tabs.size.toString()
        if (::addressBar.isInitialized) {
            currentWebView()?.url?.let { addressBar.setText(it) }
        }
    }

    private fun closeTab(index: Int) {
        if (tabs.size == 1) {
            tabs[0].webView.loadUrl(HOME_URL)
            tabs[0].title = "New tab"
            updateChromeBar()
            return
        }
        val tab = tabs.removeAt(index)
        tab.webView.stopLoading()
        tab.webView.destroy()
        activeTab = when {
            activeTab >= tabs.size -> tabs.lastIndex
            index < activeTab -> activeTab - 1
            else -> activeTab
        }
        showActiveWebView()
    }

    private fun showClearAllDataDialog() {
        val dialog = AlertDialog.Builder(this)
            .setMessage("هل تريد مسح جميع البيانات؟")
            .setNegativeButton("لا", null)
            .setPositiveButton("نعم") { _, _ ->
                clearAllBrowserData()
            }
            .create()

        dialog.setOnShowListener {
            val isDark = darkModeEnabled
            val dialogBackground = if (isDark) Color.BLACK else Color.WHITE
            val dialogText = if (isDark) Color.WHITE else Color.BLACK

            dialog.window?.setBackgroundDrawable(
                android.graphics.drawable.ColorDrawable(dialogBackground)
            )
            dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(dialogText)
        }

        dialog.show()
    }

    /**
     * Resets eM browser to a first-install state without uninstalling the APK.
     * All browser/site data and all app preferences created by the browser are removed.
     */
    private fun clearAllBrowserData() {
        // Destroy every WebView first so no page can recreate data while we are clearing it.
        tabs.forEach { tab ->
            tab.webView.stopLoading()
            tab.webView.clearHistory()
            tab.webView.clearCache(true)
            tab.webView.clearFormData()
            tab.webView.clearSslPreferences()
            tab.webView.clearMatches()
            tab.webView.destroy()
        }
        tabs.clear()
        activeTab = 0

        // Clear WebView's shared browser stores.
        WebStorage.getInstance().deleteAllData()
        val webViewDatabase = WebViewDatabase.getInstance(this)
        webViewDatabase.clearHttpAuthUsernamePassword()
        webViewDatabase.clearFormData()
        webViewDatabase.clearUsernamePassword()

        // Cookie deletion is asynchronous; finish the reset only after it completes.
        val cookieManager = CookieManager.getInstance()
        cookieManager.removeAllCookies {
            cookieManager.removeSessionCookies {
                cookieManager.flush()
                finishFullBrowserReset()
            }
        }
        cookieManager.flush()
    }

    private fun finishFullBrowserReset() {
        // Remove all preferences saved by eM browser, including appearance and zoom settings.
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().commit()
        incognitoEnabled = false
        darkModeEnabled = false
        zoomPercent = 100

        // Remove app-private files, databases, caches, and preferences created at runtime.
        deleteDirectoryContents(filesDir)
        deleteDirectoryContents(cacheDir)
        deleteDirectoryContents(noBackupFilesDir)
        deleteDirectoryContents(File(applicationInfo.dataDir, "shared_prefs"))
        databaseList().forEach { name -> deleteDatabase(name) }
        externalCacheDir?.let { deleteDirectoryContents(it) }

        // WebView can keep additional runtime data under app_webview/code_cache.
        File(applicationInfo.dataDir, "app_webview").let { if (it.exists()) it.deleteRecursively() }
        File(applicationInfo.dataDir, "code_cache").let { if (it.exists()) it.deleteRecursively() }

        // Re-read the same defaults used by a brand-new installation.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        // Recreate the activity so a completely fresh WebView and UI are constructed.
        recreate()
    }

    private fun deleteDirectoryContents(directory: File) {
        directory.listFiles()?.forEach { file ->
            if (file.isDirectory) file.deleteRecursively() else file.delete()
        }
    }

    private fun showZoomDialog() {
        val appTextColor = if (darkModeEnabled) Color.WHITE else Color.BLACK
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), dp(8))
        }
        val label = TextView(this).apply {
            text = "حجم النص والواجهة: $zoomPercent%"
            textSize = 17f
            setTextColor(appTextColor)
        }
        val seek = SeekBar(this).apply {
            min = MIN_ZOOM
            max = MAX_ZOOM
            progress = zoomPercent
            progressTintList = android.content.res.ColorStateList.valueOf(appTextColor)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(
                if (darkModeEnabled) Color.DKGRAY else Color.LTGRAY
            )
            thumbTintList = android.content.res.ColorStateList.valueOf(appTextColor)
        }
        box.addView(label)
        box.addView(seek)

        val dialog = AlertDialog.Builder(this)
            .setTitle("حجم النص والواجهة")
            .setView(box)
            .setPositiveButton("تم", null)
            .create()

        dialog.setOnShowListener {
            val dialogBackground = if (darkModeEnabled) Color.BLACK else Color.WHITE
            val dialogText = if (darkModeEnabled) Color.WHITE else Color.BLACK
            dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(dialogBackground))
            dialog.findViewById<TextView>(androidx.appcompat.R.id.alertTitle)?.setTextColor(dialogText)
            dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(dialogText)
        }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                zoomPercent = value.coerceIn(MIN_ZOOM, MAX_ZOOM)
                label.text = "حجم النص والواجهة: $zoomPercent%"
                tabs.forEach { it.webView.settings.textZoom = zoomPercent }
                updateChromeBar()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        dialog.setOnDismissListener {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_ZOOM, zoomPercent).apply()
        }
        dialog.show()
    }

    private fun setIncognitoMode(enabled: Boolean) {
        incognitoEnabled = enabled
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_INCOGNITO, enabled).apply()
        if (enabled) clearPrivateData()
        tabs.forEach {
            it.webView.settings.domStorageEnabled = !enabled
            it.webView.settings.databaseEnabled = !enabled
            it.webView.settings.cacheMode = if (enabled) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        }
    }

    private fun clearPrivateData() {
        tabs.forEach {
            it.webView.clearHistory()
            it.webView.clearCache(true)
            it.webView.clearFormData()
            it.webView.clearSslPreferences()
        }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
    }

    private fun setDarkMode(enabled: Boolean) {
        darkModeEnabled = enabled
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_DARK, enabled).apply()
        AppCompatDelegate.setDefaultNightMode(
            if (enabled) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !enabled
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !enabled
    }

    private fun currentWebView(): WebView? = tabs.getOrNull(activeTab)?.webView

    private fun withArabicLanguage(url: String): String {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return url
        if (url.contains("hl=", ignoreCase = true)) return url
        return url + if (url.contains("?")) "&hl=ar" else "?hl=ar"
    }

    private fun resolveColor(attr: Int): Int {
        val value = android.util.TypedValue()
        theme.resolveAttribute(attr, value, true)
        return if (value.resourceId != 0) ContextCompat.getColor(this, value.resourceId) else value.data
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (incognitoEnabled) clearPrivateData()
        tabs.forEach { it.webView.stopLoading(); it.webView.destroy() }
        super.onDestroy()
    }
}
