package com.em.browser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject
import android.text.Spannable
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebChromeClient
import android.webkit.WebStorage
import android.webkit.WebViewDatabase
import java.io.File
import java.util.TimeZone
import android.webkit.WebView
import android.webkit.WebViewClient
import android.animation.ObjectAnimator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.EditText
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.core.content.ContextCompat
import androidx.webkit.Profile
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private data class BrowserTab(
        var webView: WebView,
        var profileName: String = Profile.DEFAULT_PROFILE_NAME,
        var title: String = "New tab",
        var thumbnail: Bitmap? = null
    )

    private val tabs = mutableListOf<BrowserTab>()
    private var activeTab = 0
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var rootLayout: LinearLayout
    private lateinit var chromeBar: LinearLayout
    private lateinit var addressBar: android.widget.EditText
    private lateinit var tabCountView: TextView
    private lateinit var contentFrame: LinearLayout
    private lateinit var pageProgress: ProgressBar
    private lateinit var sideMenu: LinearLayout
    private lateinit var timeZoneMenuItem: TextView
    private lateinit var systemBottomSpacer: View
    private var progressAnimator: ObjectAnimator? = null

    private var incognitoEnabled = false
    private var darkModeEnabled = false
    private var zoomPercent = 100
    private var countryCode = "EG"
    private var countryName = "Egypt"
    private var timeZoneId = "Africa/Cairo"
    private var timeZoneCity = "القاهرة"
    private var automationMasterEnabled = false
    private var passwordAutomationEnabled = false
    private var passwordAutomationActive = false
    private var passwordAutomationCurrent = ""
    private var passwordAutomationNew = ""
    private var passwordChangeSubmitted = false
    private var passwordReauthSubmitted = false
    // Hard guard for the entire password stage. This stays true across WebView
    // reloads/navigation and is cleared only after Google reports success or an
    // explicit password-change error.
    private var passwordFlowStartedForCurrentAutomation = false
    private var recoveryDirectRetryCount = 0
    private var recoveryEmailAutomationEnabled = false
    private var recoveryEmailAutomationActive = false
    private var combinedAutomationWaitingForPassword = false
    private var automationCompletedForCurrentAccount = false
    private var automationHasRunInCurrentGoogleSession = false
    private var lastAutomationUrl = ""
    private var recoveryRemovalAwaitingVerification = false
    private var recoveryEmailPageOpened = false
    private var recoveryTrashClicked = false
    private var recoverySuccessNotificationSeen = false
    private var completedAccountKey = ""
    private var currentAccountKey = ""

    companion object {
        private const val HOME_URL = "https://accounts.google.com/?hl=ar"
        private const val RECOVERY_EMAIL_URL = "https://myaccount.google.com/recovery/email?hl=ar"
        private const val PREFS = "browser_prefs"
        private const val KEY_INCOGNITO = "incognito"
        private const val KEY_DARK = "dark"
        private const val KEY_ZOOM = "zoom"
        private const val KEY_COUNTRY_CODE = "country_code"
        private const val KEY_COUNTRY_NAME = "country_name"
        private const val KEY_TIME_ZONE = "time_zone"
        private const val KEY_TIME_ZONE_CITY = "time_zone_city"
        private const val KEY_TABS_STATE = "tabs_state"
        private const val KEY_ACTIVE_TAB = "active_tab"
        private const val KEY_AUTOMATION_MASTER_ENABLED = "automation_master_enabled"
        private const val KEY_PASSWORD_AUTOMATION_ENABLED = "password_automation_enabled"
        private const val KEY_PASSWORD_CURRENT = "password_automation_current"
        private const val KEY_PASSWORD_NEW = "password_automation_new"
        private const val KEY_RECOVERY_EMAIL_AUTOMATION_ENABLED = "recovery_email_automation_enabled"
        private const val MIN_ZOOM = 50
        private const val MAX_ZOOM = 120
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        incognitoEnabled = prefs.getBoolean(KEY_INCOGNITO, false)
        darkModeEnabled = prefs.getBoolean(KEY_DARK, false)
        zoomPercent = prefs.getInt(KEY_ZOOM, 100).coerceIn(MIN_ZOOM, MAX_ZOOM)
        countryCode = prefs.getString(KEY_COUNTRY_CODE, "EG") ?: "EG"
        countryName = prefs.getString(KEY_COUNTRY_NAME, "Egypt") ?: "Egypt"
        timeZoneId = prefs.getString(KEY_TIME_ZONE, "Africa/Cairo") ?: "Africa/Cairo"
        timeZoneCity = prefs.getString(KEY_TIME_ZONE_CITY, "القاهرة") ?: "القاهرة"
        automationMasterEnabled = prefs.getBoolean(KEY_AUTOMATION_MASTER_ENABLED, false)
        passwordAutomationEnabled = prefs.getBoolean(KEY_PASSWORD_AUTOMATION_ENABLED, false)
        passwordAutomationCurrent = prefs.getString(KEY_PASSWORD_CURRENT, "") ?: ""
        passwordAutomationNew = prefs.getString(KEY_PASSWORD_NEW, "") ?: ""
        recoveryEmailAutomationEnabled = prefs.getBoolean(KEY_RECOVERY_EMAIL_AUTOMATION_ENABLED, false)

        AppCompatDelegate.setDefaultNightMode(
            if (darkModeEnabled) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )

        buildInterface()
        if (!restoreTabsState()) {
            addTab(homeUrl())
        }

        var lastBackPressedAt = 0L
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Close the side menu first if it is open.
                if (::drawerLayout.isInitialized && drawerLayout.isDrawerOpen(Gravity.START)) {
                    drawerLayout.closeDrawer(Gravity.START)
                    lastBackPressedAt = 0L
                    return
                }

                // Keep normal browser navigation working.
                val webView = currentWebView()
                if (webView?.canGoBack() == true) {
                    webView.goBack()
                    lastBackPressedAt = 0L
                    return
                }

                val now = System.currentTimeMillis()
                if (now - lastBackPressedAt <= 2000L) {
                    lastBackPressedAt = 0L
                    finish()
                } else {
                    lastBackPressedAt = now
                    Snackbar.make(
                        drawerLayout,
                        "دوس رجوع مرة أخرى للخروج",
                        1200
                    ).apply {
                        setDuration(1200)
                    }.show()
                }
            }
        })
    }

    private fun buildInterface() {
        // Keep the Android status/navigation areas visible instead of drawing the browser UI over them.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = resolveColor(com.google.android.material.R.attr.colorSurface)
        window.navigationBarColor = resolveColor(com.google.android.material.R.attr.colorSurface)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !darkModeEnabled
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !darkModeEnabled

        drawerLayout = DrawerLayout(this).apply {
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        // Android 15 can enforce edge-to-edge for targetSdk 35. Explicitly reserve the system-bar space.
        // Keep browser content below the Android status bar and, importantly,
        // reserve the full navigation-bar area at the bottom. Some Android
        // devices use an overlay/gesture navigation bar, so relying only on
        // WebView scrolling can leave website footer links (Privacy, Terms,
        // Language, etc.) underneath the phone's navigation controls.
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, bars.top, 0, 0)
            if (::systemBottomSpacer.isInitialized) {
                systemBottomSpacer.layoutParams = systemBottomSpacer.layoutParams.apply {
                    height = bars.bottom
                }
                systemBottomSpacer.requestLayout()
            }
            insets
        }

        chromeBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(4), dp(5), dp(4), dp(5))
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
            elevation = dp(2).toFloat()
        }

        fun chromeButton(label: String, size: Float = 24f): TextView = TextView(this).apply {
            text = label
            textSize = size
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            isClickable = true
            isFocusable = true
            background = null
        }

        val menuButton = chromeButton("⋮", 30f).apply {
            contentDescription = "القائمة"
            setOnClickListener { drawerLayout.openDrawer(Gravity.END) }
        }
        chromeBar.addView(menuButton, LinearLayout.LayoutParams(dp(44), dp(48)))

        tabCountView = chromeButton("1", 12f).apply {
            contentDescription = "علامات التبويب"
            setPadding(dp(5), dp(3), dp(5), dp(3))
            background = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.bg_tab_count)
            setOnClickListener { showTabSwitcher() }
        }
        chromeBar.addView(tabCountView, LinearLayout.LayoutParams(dp(22), dp(24)).apply { gravity = Gravity.CENTER_VERTICAL })

        val addButton = chromeButton("+", 30f).apply {
            contentDescription = "تبويب جديد"
            setOnClickListener { addTab(homeUrl()) }
        }
        chromeBar.addView(addButton, LinearLayout.LayoutParams(dp(44), dp(48)))

        addressBar = android.widget.EditText(this).apply {
            textSize = 16f
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setHintTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            hint = "بحث أو إدخال عنوان"
            setPadding(dp(14), 0, dp(14), 0)
            background = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.bg_address_bar)
            isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setOnEditorActionListener { v, _, _ ->
                loadAddress(v.text?.toString().orEmpty())
                true
            }
        }
        chromeBar.addView(addressBar, LinearLayout.LayoutParams(0, dp(40), 1f).apply {
            gravity = Gravity.CENTER_VERTICAL
            marginStart = dp(7)
            marginEnd = dp(7)
        })

        val homeButton = chromeButton("⌂", 28f).apply {
            contentDescription = "الصفحة الرئيسية"
            setOnClickListener { currentWebView()?.loadUrl(homeUrl()) }
        }
        chromeBar.addView(homeButton, LinearLayout.LayoutParams(dp(48), dp(48)))

        // Standard browser-style page loading indicator: a thin, natural blue line
        // directly below the tab/address bar. It does not consume the status-bar area.
        pageProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            isIndeterminate = false
            visibility = View.GONE
            progressDrawable = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.progress_page)
            setPadding(0, 0, 0, 0)
        }

        contentFrame = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // A dedicated inset spacer guarantees that the bottom of every WebView
        // stays above the phone's system navigation/gesture area.
        systemBottomSpacer = View(this).apply {
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        rootLayout.addView(chromeBar, LinearLayout.LayoutParams(-1, dp(58)))
        rootLayout.addView(pageProgress, LinearLayout.LayoutParams(-1, dp(3)))
        rootLayout.addView(contentFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        rootLayout.addView(systemBottomSpacer, LinearLayout.LayoutParams(-1, 0))

        drawerLayout.addView(rootLayout, DrawerLayout.LayoutParams(-1, -1))
        buildSideMenu()
        drawerLayout.addView(sideMenu, DrawerLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.END
            topMargin = dp(12)
            bottomMargin = dp(12)
        })
        ViewCompat.setOnApplyWindowInsetsListener(drawerLayout) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val lp = sideMenu.layoutParams as DrawerLayout.LayoutParams
            lp.topMargin = bars.top + dp(12)
            lp.bottomMargin = bars.bottom + dp(12)
            sideMenu.layoutParams = lp
            insets
        }
        setContentView(drawerLayout)
    }

    private fun buildSideMenu() {
        sideMenu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Menu content is English, so keep the menu itself LTR.
            // The DrawerLayout position remains unchanged.
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(0, dp(16), 0, dp(10))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(28).toFloat()
                setColor(resolveColor(com.google.android.material.R.attr.colorSurface))
            }
            elevation = dp(8).toFloat()
            clipToOutline = true
        }

        val title = TextView(this).apply {
            text = "eM gmail"
            textSize = 20f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(dp(28), dp(6), dp(28), dp(12))
        }
        sideMenu.addView(title)

        fun menuItem(label: CharSequence, onClick: () -> Unit): TextView = TextView(this).apply {
            text = label
            textSize = 15.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(dp(28), 0, dp(28), 0)
            // No pressed/selected highlight color: keep the app monochrome.
            background = null
            setOnClickListener { onClick() }
        }

        sideMenu.addView(menuItem("Refresh Page") { currentWebView()?.reload(); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("New Tab") { addTab(homeUrl()); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Incognito") { setIncognitoMode(!incognitoEnabled); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Dark Mode") { setDarkMode(!darkModeEnabled); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Text Size") { drawerLayout.closeDrawer(Gravity.END); showZoomDialog() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        timeZoneMenuItem = menuItem(timeZoneMenuLabel()) { drawerLayout.closeDrawer(Gravity.END); showTimeZoneDialog() }
        sideMenu.addView(timeZoneMenuItem, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        addAutomationMasterMenuItem()
        addPasswordChangeMenuItem()
        addRecoveryEmailMenuItem()
        sideMenu.addView(menuItem("Clear Browsing Data") { drawerLayout.closeDrawer(Gravity.END); showClearAllDataDialog() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
    }

    private fun addAutomationMasterMenuItem() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), 0, dp(16), 0)
        }
        val label = TextView(this).apply {
            text = "Automation"
            textSize = 15.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, 0, dp(12), 0)
        }
        val switch = MaterialSwitch(this).apply {
            isChecked = automationMasterEnabled
            text = ""
            showText = false
            minWidth = dp(32); minimumWidth = dp(32); minimumHeight = dp(24)
            scaleX = 0.62f; scaleY = 0.62f
            val primaryBlue = resolveColor(com.google.android.material.R.attr.colorPrimary)
            val surfaceVariant = resolveColor(com.google.android.material.R.attr.colorSurfaceVariant)
            thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(primaryBlue, resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant)))
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Color.argb(90, Color.red(primaryBlue), Color.green(primaryBlue), Color.blue(primaryBlue)), surfaceVariant))
            setOnCheckedChangeListener { _, checked ->
                automationMasterEnabled = checked
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_AUTOMATION_MASTER_ENABLED, checked).apply()
                if (checked) {
                    automationCompletedForCurrentAccount = false
                    automationHasRunInCurrentGoogleSession = false
                    // The master switch is the only control that starts execution.
                    // Start immediately only when the current tab is already on Google/Gmail;
                    // otherwise onPageFinished will start it when the page arrives.
                    val currentUrl = currentWebView()?.url.orEmpty()
                    if (currentUrl.contains("google.com")) {
                        startConfiguredAutomationForCurrentAccount()
                    }
                } else {
                    passwordAutomationActive = false
                    passwordChangeSubmitted = false
                    passwordReauthSubmitted = false
                    recoveryEmailAutomationActive = false
                    combinedAutomationWaitingForPassword = false
                }
            }
        }
        row.addView(label, LinearLayout.LayoutParams(0, dp(46), 1f))
        row.addView(switch, LinearLayout.LayoutParams(dp(44), dp(30)))
        sideMenu.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
    }

    private fun addPasswordChangeMenuItem() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), 0, dp(16), 0)
        }

        val label = TextView(this).apply {
            text = "Password"
            textSize = 15.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, 0, dp(12), 0)
            setOnClickListener {
                drawerLayout.closeDrawer(Gravity.END)
                showPasswordChangeDialog()
            }
        }

        val switch = MaterialSwitch(this).apply {
            isChecked = passwordAutomationEnabled
            text = ""
            showText = false
            // Compact switch: no On/Off text, blue when enabled, neutral when disabled.
            minWidth = dp(32)
            minimumWidth = dp(32)
            minimumHeight = dp(24)
            scaleX = 0.62f
            scaleY = 0.62f
            val primaryBlue = resolveColor(com.google.android.material.R.attr.colorPrimary)
            val surfaceVariant = resolveColor(com.google.android.material.R.attr.colorSurfaceVariant)
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(primaryBlue, resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.argb(90, Color.red(primaryBlue), Color.green(primaryBlue), Color.blue(primaryBlue)), surfaceVariant)
            )
            setOnCheckedChangeListener { _, checked ->
                passwordAutomationEnabled = checked
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean(KEY_PASSWORD_AUTOMATION_ENABLED, checked)
                    .apply()
                if (!checked) {
                    clearPasswordAutomationState()
                    if (!automationMasterEnabled) passwordChangeSubmitted = false
                }
            }
        }

        row.addView(label, LinearLayout.LayoutParams(0, dp(46), 1f))
        row.addView(switch, LinearLayout.LayoutParams(dp(44), dp(30)))
        sideMenu.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
    }

    private fun addRecoveryEmailMenuItem() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), 0, dp(16), 0)
        }

        val label = TextView(this).apply {
            text = "Recovery"
            textSize = 15.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, 0, dp(12), 0)
            setOnClickListener {
                drawerLayout.closeDrawer(Gravity.END)
                showRecoveryEmailInfoDialog()
            }
        }

        val switch = MaterialSwitch(this).apply {
            isChecked = recoveryEmailAutomationEnabled
            text = ""
            showText = false
            // Compact switch: no On/Off text, blue when enabled, neutral when disabled.
            minWidth = dp(32)
            minimumWidth = dp(32)
            minimumHeight = dp(24)
            scaleX = 0.62f
            scaleY = 0.62f
            val primaryBlue = resolveColor(com.google.android.material.R.attr.colorPrimary)
            val surfaceVariant = resolveColor(com.google.android.material.R.attr.colorSurfaceVariant)
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(primaryBlue, resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.argb(90, Color.red(primaryBlue), Color.green(primaryBlue), Color.blue(primaryBlue)), surfaceVariant)
            )
            setOnCheckedChangeListener { _, checked ->
                recoveryEmailAutomationEnabled = checked
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean(KEY_RECOVERY_EMAIL_AUTOMATION_ENABLED, checked)
                    .apply()
                if (!checked) {
                    recoveryEmailAutomationActive = false
                    recoveryRemovalAwaitingVerification = false
                }
            }
        }

        row.addView(label, LinearLayout.LayoutParams(0, dp(46), 1f))
        row.addView(switch, LinearLayout.LayoutParams(dp(44), dp(30)))
        sideMenu.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
    }

    private fun showRecoveryEmailInfoDialog() {
        AlertDialog.Builder(this)
            .setTitle("Recovery")
            .setMessage("اضغط On لإزالة بريد الاسترداد من حساب Google المفتوح حاليًا. إذا طلب Google تحققًا إضافيًا، أكمله يدويًا.")
            .setPositiveButton("موافق", null)
            .show()
    }

    private fun showPasswordChangeDialog() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val savedCurrent = prefs.getString(KEY_PASSWORD_CURRENT, passwordAutomationCurrent) ?: ""
        val savedNew = prefs.getString(KEY_PASSWORD_NEW, passwordAutomationNew) ?: ""

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), 0, dp(8), 0)
        }

        fun passwordField(hint: String, value: String): EditText = EditText(this).apply {
            this.hint = hint
            setText(value)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            isSingleLine = true
        }

        val current = passwordField("كلمة المرور الحالية", savedCurrent)
        val newPassword = passwordField("كلمة المرور الجديدة", savedNew)
        val confirm = passwordField("تأكيد كلمة المرور الجديدة", savedNew)
        container.addView(current, LinearLayout.LayoutParams(-1, dp(56)))
        container.addView(newPassword, LinearLayout.LayoutParams(-1, dp(56)))
        container.addView(confirm, LinearLayout.LayoutParams(-1, dp(56)))

        val dialog = AlertDialog.Builder(this)
            .setTitle("Password")
            .setView(container)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val oldPassword = current.text?.toString().orEmpty()
                val newValue = newPassword.text?.toString().orEmpty()
                val confirmation = confirm.text?.toString().orEmpty()

                if (oldPassword.isBlank() || newValue.isBlank() || confirmation.isBlank()) {
                    Snackbar.make(drawerLayout, "اكتب كلمات المرور الثلاثة أولًا", Snackbar.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (newValue != confirmation) {
                    Snackbar.make(drawerLayout, "كلمة المرور الجديدة والتأكيد غير متطابقين", Snackbar.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                passwordAutomationCurrent = oldPassword
                passwordAutomationNew = newValue
                prefs.edit()
                    .putString(KEY_PASSWORD_CURRENT, oldPassword)
                    .putString(KEY_PASSWORD_NEW, newValue)
                    .apply()

                dialog.dismiss()
                Snackbar.make(drawerLayout, "تم حفظ بيانات Password", Snackbar.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun startPasswordChange() {
        // A password flow may only be started once for the current cycle.
        // onPageFinished and recovery callbacks can arrive close together.
        if (passwordAutomationActive || passwordFlowStartedForCurrentAutomation) return
        if (!passwordAutomationEnabled) {
            Snackbar.make(drawerLayout, "Password مطفأ. فعّل الزر أولًا", Snackbar.LENGTH_SHORT).show()
            return
        }
        if (passwordAutomationCurrent.isBlank() || passwordAutomationNew.isBlank()) {
            Snackbar.make(drawerLayout, "افتح Password واحفظ بيانات الباسورد أولًا", Snackbar.LENGTH_LONG).show()
            return
        }

        passwordAutomationActive = true
        passwordFlowStartedForCurrentAutomation = true
        passwordChangeSubmitted = false
        passwordReauthSubmitted = false
        recoveryEmailAutomationActive = false
        combinedAutomationWaitingForPassword = false
        val webView = currentWebView()
        if (webView == null) {
            passwordAutomationActive = false
            Snackbar.make(drawerLayout, "لا يوجد تبويب مفتوح", Snackbar.LENGTH_SHORT).show()
            return
        }

        // Clear only the previous password-flow lock before opening a fresh flow.
        // The lock itself is stored in sessionStorage by the page script so it
        // survives Google's navigation/reload between the submit and its result.
        webView.evaluateJavascript("try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); sessionStorage.removeItem('__emPasswordFlowReauth'); } catch(e) {}", null)
        webView.loadUrl("https://myaccount.google.com/signinoptions/password?hl=ar")
    }

    private fun startRecoveryEmailRemoval() {
        if (!recoveryEmailAutomationEnabled) return
        val webView = currentWebView()
        if (webView == null) {
            recoveryEmailAutomationActive = false
            Snackbar.make(drawerLayout, "لا يوجد تبويب مفتوح", Snackbar.LENGTH_SHORT).show()
            return
        }
        recoveryEmailAutomationActive = true
        recoveryRemovalAwaitingVerification = false
        recoveryDirectRetryCount = 0
        recoveryEmailPageOpened = false
        recoveryTrashClicked = false
        recoverySuccessNotificationSeen = false
        passwordAutomationActive = false
        combinedAutomationWaitingForPassword = passwordAutomationEnabled
        // Open Google's dedicated Recovery Email page directly. The rapt/continue
        // parameters are session-specific, so do not hard-code the user's temporary token;
        // Google will use the currently signed-in WebView session.
        webView.loadUrl(RECOVERY_EMAIL_URL)
    }

    private fun startConfiguredAutomationForCurrentAccount() {
        if (!automationMasterEnabled) return
        if (automationCompletedForCurrentAccount || automationHasRunInCurrentGoogleSession) return
        if (!recoveryEmailAutomationEnabled && !passwordAutomationEnabled) return
        // While Recovery is handing off to Password, or while Password is waiting
        // for Google's result, never start another automation cycle from onPageFinished.
        if (combinedAutomationWaitingForPassword || passwordAutomationActive || passwordFlowStartedForCurrentAutomation) return

        automationHasRunInCurrentGoogleSession = true
        if (recoveryEmailAutomationEnabled) {
            startRecoveryEmailRemoval()
        } else if (passwordAutomationEnabled) {
            startPasswordChange()
        }
    }

    private fun injectRecoveryEmailRemovalScript(view: WebView) {
        if (!recoveryEmailAutomationActive) return
        val script = """
            (function() {
              const visible = el => !!el && el.offsetParent !== null;
              const normalize = s => (s || '').replace(/\\s+/g, ' ').trim();
              const lower = s => normalize(s).toLowerCase();
              const attrs = el => [el?.getAttribute('aria-label'), el?.getAttribute('data-tooltip'), el?.getAttribute('title')]
                .filter(Boolean).join(' ').replace(/\\s+/g, ' ').trim();
              const recoveryHeaderRe = /البريد الإلكتروني المخصص لاسترداد الحساب|عنوان البريد الإلكتروني المخصص لاسترداد الحساب|recovery email/i;
              const addRecoveryRe = /إضافة بريد إلكتروني لاسترداد الحساب|add a recovery email|add recovery email/i;
              const deleteLabelRe = /^(حذف|delete|remove|إزالة)$/i;
              const successRe = /تمت إزالة البريد الإلكتروني المخصص لاسترداد الحساب|تم حذف البريد الإلكتروني المخصص لاسترداد الحساب|تمت إزالة بريد الاسترداد|تم حذف بريد الاسترداد|recovery email.*(?:removed|deleted)|recovery.*email.*(?:removed|deleted)/i;

              // 1) The dedicated Recovery Email page is opened directly by Kotlin.
              // If the email is already absent, report that only when Google explicitly
              // renders the "Add recovery email" action.
              const bodyText = normalize(document.body?.innerText || '');
              const isRecoveryPage = location.href.includes('/recovery/email') ||
                                     (recoveryHeaderRe.test(bodyText) && !location.href.includes('/security'));

              // 2) Confirmation dialog after pressing the trash icon.
              const dialogs = Array.from(document.querySelectorAll('[role="dialog"], [aria-modal="true"]')).filter(visible);
              for (const dialog of dialogs) {
                const confirm = Array.from(dialog.querySelectorAll('button,[role="button"],a'))
                  .filter(visible)
                  .find(el => deleteLabelRe.test(normalize(el.innerText || el.textContent || '')) || deleteLabelRe.test(attrs(el)));
                if (confirm) {
                  confirm.click();
                  return 'delete_confirmed';
                }
              }

              if (isRecoveryPage) {
                // Do not click the trash icon again after the confirmation flow has begun.
                const controls = Array.from(document.querySelectorAll('button,[role="button"],a,input[type="button"],input[type="submit"]')).filter(visible);
                const trash = controls.find(el => {
                  const a = lower(attrs(el));
                  const icon = lower(el.querySelector('svg')?.getAttribute('aria-label') || '');
                  const data = lower(el.getAttribute('data-tooltip-id') || '');
                  return /trash|delete|remove|حذف|إزالة|سلة|مهملات/.test(a) ||
                         /trash|delete|remove|حذف|إزالة|سلة|مهملات/.test(icon) ||
                         /trash|delete|remove/.test(data);
                });
                if (trash && !%s) {
                  trash.click();
                  return 'trash_clicked';
                }

                if (addRecoveryRe.test(bodyText)) return 'not_present';
                return 'waiting';
              }

              return 'waiting';
            })();
        """.trimIndent().format(if (recoveryTrashClicked) "true" else "false")

        if (recoveryRemovalAwaitingVerification) {
            verifyRecoveryRemoval(view)
            return
        }
        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "trash_clicked" -> {
                    recoveryTrashClicked = true
                    view.postDelayed({ if (recoveryEmailAutomationActive) injectRecoveryEmailRemovalScript(view) }, 900L)
                }
                "delete_confirmed" -> {
                    recoveryRemovalAwaitingVerification = true
                    view.postDelayed({ if (recoveryRemovalAwaitingVerification) verifyRecoveryRemoval(view) }, 900L)
                }
                "not_present" -> {
                    // Google explicitly shows the "Add recovery email" action, which
                    // means there is no recovery email configured. In that case there
                    // is nothing to delete, so Recovery is considered satisfied and
                    // the combined flow may continue directly to Password.
                    finishRecoveryStage(view, recoveryWasAlreadyAbsent = true)
                }
                "waiting" -> {
                    view.postDelayed({ if (recoveryEmailAutomationActive) injectRecoveryEmailRemovalScript(view) }, 900L)
                }
            }
        }
    }

    private fun verifyRecoveryRemoval(view: WebView) {
        if (!recoveryRemovalAwaitingVerification) return
        val script = """
            (function() {
              const visible = el => !!el && el.offsetParent !== null;
              const normalize = s => (s || '').replace(/\\s+/g, ' ').trim();
              const bodyText = normalize(document.body?.innerText || '');
              const recoveryHeaderRe = /البريد الإلكتروني المخصص لاسترداد الحساب|عنوان البريد الإلكتروني المخصص لاسترداد الحساب|recovery email/i;
              const addRecoveryRe = /إضافة بريد إلكتروني لاسترداد الحساب|add a recovery email|add recovery email/i;
              const successRe = /تمت إزالة البريد الإلكتروني المخصص لاسترداد الحساب|تم حذف البريد الإلكتروني المخصص لاسترداد الحساب|تمت إزالة بريد الاسترداد|تم حذف بريد الاسترداد|recovery email.*(?:removed|deleted)|recovery.*email.*(?:removed|deleted)/i;

              // This must be Google's dedicated Recovery Email destination, not the
              // Security & sign-in page. The screenshot shows the Recovery Email header
              // together with the Add Recovery Email action after deletion.
              const isRecoveryDestination =
                    (location.href.includes('/recovery/email') || recoveryHeaderRe.test(bodyText)) &&
                    !location.href.includes('/security');

              // Google may render the success message in a snackbar/alert that is
              // not part of the main page text. Check the whole visible document and
              // live/alert regions as well. The success notification itself is the
              // authoritative signal that the deletion completed.
              const liveText = Array.from(document.querySelectorAll('[role="alert"],[role="status"],[aria-live],.snackbar,.toast'))
                .filter(visible)
                .map(el => normalize(el.innerText || el.textContent || el.getAttribute('aria-label') || ''))
                .join(' ');
              const hasSuccessNotification = successRe.test(bodyText) || successRe.test(liveText);

              // Once Google shows the deletion confirmation, move immediately to
              // Password. Do not require the Add Recovery Email button because the
              // snackbar can appear while Google is still finishing its navigation.
              if (isRecoveryDestination && hasSuccessNotification) return 'success_seen';

              // No recovery email: this is the only case where we may continue without
              // a deletion notification. Google must explicitly show the add-recovery
              // action on the dedicated Recovery Email page.
              const hasAddButton = Array.from(document.querySelectorAll('button,a,[role="button"],[role="link"]'))
                .filter(visible)
                .some(el => addRecoveryRe.test(normalize(el.innerText || el.textContent || el.getAttribute('aria-label') || '')));
              if (isRecoveryDestination && hasAddButton) return 'destination_only';
              return 'waiting';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "removed_confirmed" -> {
                    recoverySuccessNotificationSeen = true
                    finishRecoveryStage(view)
                }
                "success_seen" -> {
                    // This is the exact hand-off point: Google's deletion notification
                    // has appeared. Stop Recovery immediately and start Password.
                    recoverySuccessNotificationSeen = true
                    finishRecoveryStage(view)
                }
                "destination_only" -> {
                    // Explicitly no recovery email exists. This is the only successful
                    // no-email path and does not require a deletion snackbar.
                    finishRecoveryStage(view, recoveryWasAlreadyAbsent = true)
                }
                else -> {
                    view.postDelayed({ if (recoveryRemovalAwaitingVerification) verifyRecoveryRemoval(view) }, 500L)
                }
            }
        }
    }

    private fun finishRecoveryStage(view: WebView, recoveryWasAlreadyAbsent: Boolean = false) {
        recoveryRemovalAwaitingVerification = false
        recoveryEmailPageOpened = false
        recoveryTrashClicked = false
        recoverySuccessNotificationSeen = false
        recoveryEmailAutomationActive = false

        if (combinedAutomationWaitingForPassword && passwordAutomationEnabled) {
            // If no recovery email existed, there is nothing to delete and therefore
            // no deletion snackbar is required. Go straight to Password. If an email
            // did exist, this method is reached only after Google's deletion success
            // notification has been observed.
            combinedAutomationWaitingForPassword = false
            view.postDelayed({ startPasswordChange() }, if (recoveryWasAlreadyAbsent) 150L else 220L)
        } else {
            automationCompletedForCurrentAccount = true
            automationHasRunInCurrentGoogleSession = true
            completedAccountKey = currentAccountKey
            val message = if (recoveryWasAlreadyAbsent) {
                "لا يوجد بريد استرداد — تم الانتقال للخطوة التالية"
            } else {
                "تمت إزالة بريد الاسترداد بنجاح"
            }
            Snackbar.make(drawerLayout, message, Snackbar.LENGTH_LONG).show()
        }
    }

    private fun clearPasswordAutomationState() {
        passwordAutomationActive = false
        passwordChangeSubmitted = false
        passwordReauthSubmitted = false
    }

    private fun injectPasswordChangeScript(view: WebView) {
        if (!passwordAutomationActive) return
        val current = JSONObject.quote(passwordAutomationCurrent)
        val newPassword = JSONObject.quote(passwordAutomationNew)

        val script = """
            (function() {
              const currentPassword = $current;
              const newPassword = $newPassword;
              const visible = el => !!el && el.offsetParent !== null;
              const setValue = (el, value) => {
                const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
                if (setter) setter.call(el, value); else el.value = value;
                el.dispatchEvent(new Event('input', {bubbles:true}));
                el.dispatchEvent(new Event('change', {bubbles:true}));
              };
              const buttonText = el => ((el.innerText || el.value || el.getAttribute('aria-label') || '') + '').trim().toLowerCase();
              const buttons = Array.from(document.querySelectorAll('button, input[type=submit]')).filter(visible);
              const passwords = Array.from(document.querySelectorAll('input[type=password]')).filter(visible);
              const pageText = document.body?.innerText || '';
              const successText = /تم تغيير كلمة المرور(?: بنجاح)?|تم تغيير كلمة السر(?: بنجاح)?|تم تحديث كلمة المرور(?: بنجاح)?|password changed successfully|your password was changed|password has been changed|your password has been changed|password updated successfully/i;
              // window-scoped locks disappear when Google navigates/reloads the
              // password page. sessionStorage survives that navigation, preventing
              // a second fill/click while the first request is still awaiting Google's response.
              const submitLocked = window.__emPasswordAutomationSubmitted === true ||
                    (() => { try { return sessionStorage.getItem('__emPasswordFlowSubmitted') === '1'; } catch(e) { return false; } })();
              const reauthLocked = window.__emPasswordAutomationReauthSubmitted === true ||
                    (() => { try { return sessionStorage.getItem('__emPasswordFlowReauth') === '1'; } catch(e) { return false; } })();
              const errorText = /حدث خطأ(?: أثناء تغيير كلمة المرور| في تغيير كلمة المرور)?|حدثت مشكلة(?: أثناء تغيير كلمة المرور| في تغيير كلمة المرور)?|تعذر تغيير كلمة المرور|تعذر تحديث كلمة المرور|لم نتمكن من تغيير كلمة المرور|لم يتم تغيير كلمة المرور|فشل تغيير كلمة المرور|حدث خطأ ما|هناك خطأ ما|هناك مشكلة(?: أثناء تغيير كلمة المرور| في تغيير كلمة المرور)?|حدثت مشكلة ما|something went wrong(?: while changing your password)?|there was a problem(?: changing your password)?|couldn['\\'’]t change your password|could not change your password|unable to change your password|we couldn['\\'’]t change your password|password change failed|failed to change your password|password could not be changed/i;

              if (successText.test(pageText)) return 'success';
              if (${passwordChangeSubmitted} || submitLocked) {
                if (errorText.test(pageText)) {
                  window.__emPasswordAutomationSubmitted = false;
                  try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); } catch(e) {}
                  return 'retry_error';
                }
                return 'waiting_success';
              }

              if (passwords.length >= 3) {
                setValue(passwords[0], currentPassword);
                setValue(passwords[1], newPassword);
                setValue(passwords[2], newPassword);
                const submit = buttons.find(b => /change|تغيير|حفظ|save/.test(buttonText(b))) || buttons.find(b => b.type === 'submit');
                if (submit && !submit.disabled) {
                  window.__emPasswordAutomationSubmitted = true;
                  try { sessionStorage.setItem('__emPasswordFlowSubmitted', '1'); } catch(e) {}
                  submit.click();
                  return 'submitted';
                }
                return 'filled';
              }

              if (passwords.length === 2) {
                setValue(passwords[0], newPassword);
                setValue(passwords[1], newPassword);
                const submit = buttons.find(b => /change|تغيير|حفظ|save/.test(buttonText(b))) || buttons.find(b => b.type === 'submit');
                if (submit && !submit.disabled) {
                  window.__emPasswordAutomationSubmitted = true;
                  try { sessionStorage.setItem('__emPasswordFlowSubmitted', '1'); } catch(e) {}
                  submit.click();
                  return 'submitted';
                }
                return 'filled';
              }

              if (passwords.length === 1) {
                if (reauthLocked || ${passwordReauthSubmitted}) return 'waiting_reauth';
                setValue(passwords[0], currentPassword);
                const next = buttons.find(b => /next|التالي|continue|متابعة/.test(buttonText(b))) || buttons.find(b => b.type === 'submit');
                if (next && !next.disabled) {
                  window.__emPasswordAutomationReauthSubmitted = true;
                  try { sessionStorage.setItem('__emPasswordFlowReauth', '1'); } catch(e) {}
                  return (next.click(), 'reauth');
                }
                return 'one_password';
              }
              return 'waiting';
            })();
        """.trimIndent()

        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "submitted" -> {
                    // After submitting, never press the change button again unless
                    // Google explicitly reports a password-change error.
                    passwordChangeSubmitted = true
                    view.postDelayed({ if (passwordAutomationActive) injectPasswordChangeScript(view) }, 500L)
                }
                "retry_error" -> {
                    // Google explicitly reported that the password change failed.
                    // Only in this case is another attempt allowed.
                    passwordChangeSubmitted = false
                    passwordReauthSubmitted = false
                    passwordFlowStartedForCurrentAutomation = false
                    view.evaluateJavascript("try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); sessionStorage.removeItem('__emPasswordFlowReauth'); } catch(e) {}", null)
                    view.postDelayed({ if (passwordAutomationActive) injectPasswordChangeScript(view) }, 350L)
                }
                "filled", "reauth", "one_password", "waiting_reauth", "waiting", "waiting_success" -> {
                    if (result?.trim('"') == "reauth") passwordReauthSubmitted = true
                    view.postDelayed({ if (passwordAutomationActive) injectPasswordChangeScript(view) }, 900L)
                }
                "success" -> {
                    passwordAutomationActive = false
                    passwordChangeSubmitted = false
                    passwordReauthSubmitted = false
                    passwordFlowStartedForCurrentAutomation = false
                    view.evaluateJavascript("try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); sessionStorage.removeItem('__emPasswordFlowReauth'); } catch(e) {}", null)
                    recoveryEmailAutomationActive = false
                    combinedAutomationWaitingForPassword = false
                    automationCompletedForCurrentAccount = true
                    automationHasRunInCurrentGoogleSession = true
                    completedAccountKey = currentAccountKey
                    Snackbar.make(drawerLayout, "تم تغيير كلمة المرور بنجاح", Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    private data class TimeZoneOption(
        val country: String,
        val code: String,
        val city: String,
        val zoneId: String
    )

    private fun showTimeZoneDialog() {
        val zones = listOf(
            TimeZoneOption("أفغانستان", "AF", "كابول", "Asia/Kabul"),
            TimeZoneOption("ألبانيا", "AL", "تيرانا", "Europe/Tirane"),
            TimeZoneOption("الجزائر", "DZ", "الجزائر", "Africa/Algiers"),
            TimeZoneOption("أندورا", "AD", "أندورا لا فيلا", "Europe/Andorra"),
            TimeZoneOption("أنغولا", "AO", "لواندا", "Africa/Luanda"),
            TimeZoneOption("أنتيغوا وبربودا", "AG", "سانت جونز", "America/Antigua"),
            TimeZoneOption("الأرجنتين", "AR", "بوينس آيرس", "America/Argentina/Buenos_Aires"),
            TimeZoneOption("أرمينيا", "AM", "يريفان", "Asia/Yerevan"),
            TimeZoneOption("أستراليا", "AU", "سيدني", "Australia/Sydney"),
            TimeZoneOption("النمسا", "AT", "فيينا", "Europe/Vienna"),
            TimeZoneOption("أذربيجان", "AZ", "باكو", "Asia/Baku"),
            TimeZoneOption("الباهاما", "BS", "ناساو", "America/Nassau"),
            TimeZoneOption("البحرين", "BH", "المنامة", "Asia/Bahrain"),
            TimeZoneOption("بنغلاديش", "BD", "دكا", "Asia/Dhaka"),
            TimeZoneOption("بربادوس", "BB", "بريدجتاون", "America/Barbados"),
            TimeZoneOption("بيلاروسيا", "BY", "مينسك", "Europe/Minsk"),
            TimeZoneOption("بلجيكا", "BE", "بروكسل", "Europe/Brussels"),
            TimeZoneOption("بليز", "BZ", "بلموبان", "America/Belize"),
            TimeZoneOption("بنين", "BJ", "بورتو نوفو", "Africa/Porto-Novo"),
            TimeZoneOption("بوتان", "BT", "تيمفو", "Asia/Thimphu"),
            TimeZoneOption("بوليفيا", "BO", "لاباز", "America/La_Paz"),
            TimeZoneOption("البوسنة والهرسك", "BA", "سراييفو", "Europe/Sarajevo"),
            TimeZoneOption("بوتسوانا", "BW", "غابورون", "Africa/Gaborone"),
            TimeZoneOption("البرازيل", "BR", "برازيليا", "America/Sao_Paulo"),
            TimeZoneOption("بروناي", "BN", "بندر سري بكاوان", "Asia/Brunei"),
            TimeZoneOption("بلغاريا", "BG", "صوفيا", "Europe/Sofia"),
            TimeZoneOption("بوركينا فاسو", "BF", "واغادوغو", "Africa/Ouagadougou"),
            TimeZoneOption("بوروندي", "BI", "بوجومبورا", "Africa/Bujumbura"),
            TimeZoneOption("الرأس الأخضر", "CV", "برايا", "Atlantic/Cape_Verde"),
            TimeZoneOption("كمبوديا", "KH", "بنوم بنه", "Asia/Phnom_Penh"),
            TimeZoneOption("الكاميرون", "CM", "ياوندي", "Africa/Douala"),
            TimeZoneOption("كندا", "CA", "تورونتو", "America/Toronto"),
            TimeZoneOption("جمهورية أفريقيا الوسطى", "CF", "بانغي", "Africa/Bangui"),
            TimeZoneOption("تشاد", "TD", "نجامينا", "Africa/Ndjamena"),
            TimeZoneOption("تشيلي", "CL", "سانتياغو", "America/Santiago"),
            TimeZoneOption("الصين", "CN", "بكين", "Asia/Shanghai"),
            TimeZoneOption("كولومبيا", "CO", "بوغوتا", "America/Bogota"),
            TimeZoneOption("جزر القمر", "KM", "موروني", "Indian/Comoro"),
            TimeZoneOption("الكونغو", "CG", "برازافيل", "Africa/Brazzaville"),
            TimeZoneOption("جمهورية الكونغو الديمقراطية", "CD", "كينشاسا", "Africa/Kinshasa"),
            TimeZoneOption("كوستاريكا", "CR", "سان خوسيه", "America/Costa_Rica"),
            TimeZoneOption("ساحل العاج", "CI", "أبيدجان", "Africa/Abidjan"),
            TimeZoneOption("كرواتيا", "HR", "زغرب", "Europe/Zagreb"),
            TimeZoneOption("كوبا", "CU", "هافانا", "America/Havana"),
            TimeZoneOption("قبرص", "CY", "نيقوسيا", "Asia/Nicosia"),
            TimeZoneOption("التشيك", "CZ", "براغ", "Europe/Prague"),
            TimeZoneOption("الدنمارك", "DK", "كوبنهاغن", "Europe/Copenhagen"),
            TimeZoneOption("جيبوتي", "DJ", "جيبوتي", "Africa/Djibouti"),
            TimeZoneOption("دومينيكا", "DM", "روسو", "America/Dominica"),
            TimeZoneOption("جمهورية الدومينيكان", "DO", "سانتو دومينغو", "America/Santo_Domingo"),
            TimeZoneOption("الإكوادور", "EC", "كيتو", "America/Guayaquil"),
            TimeZoneOption("مصر", "EG", "القاهرة", "Africa/Cairo"),
            TimeZoneOption("السلفادور", "SV", "سان سلفادور", "America/El_Salvador"),
            TimeZoneOption("غينيا الاستوائية", "GQ", "مالابو", "Africa/Malabo"),
            TimeZoneOption("إريتريا", "ER", "أسمرة", "Africa/Asmara"),
            TimeZoneOption("إستونيا", "EE", "تالين", "Europe/Tallinn"),
            TimeZoneOption("إسواتيني", "SZ", "مباباني", "Africa/Mbabane"),
            TimeZoneOption("إثيوبيا", "ET", "أديس أبابا", "Africa/Addis_Ababa"),
            TimeZoneOption("فيجي", "FJ", "سوفا", "Pacific/Fiji"),
            TimeZoneOption("فنلندا", "FI", "هلسنكي", "Europe/Helsinki"),
            TimeZoneOption("فرنسا", "FR", "باريس", "Europe/Paris"),
            TimeZoneOption("الغابون", "GA", "ليبرفيل", "Africa/Libreville"),
            TimeZoneOption("غامبيا", "GM", "بانجول", "Africa/Banjul"),
            TimeZoneOption("جورجيا", "GE", "تبليسي", "Asia/Tbilisi"),
            TimeZoneOption("ألمانيا", "DE", "برلين", "Europe/Berlin"),
            TimeZoneOption("غانا", "GH", "أكرا", "Africa/Accra"),
            TimeZoneOption("اليونان", "GR", "أثينا", "Europe/Athens"),
            TimeZoneOption("غرينادا", "GD", "سانت جورجز", "America/Grenada"),
            TimeZoneOption("غواتيمالا", "GT", "غواتيمالا سيتي", "America/Guatemala"),
            TimeZoneOption("غينيا", "GN", "كوناكري", "Africa/Conakry"),
            TimeZoneOption("غينيا بيساو", "GW", "بيساو", "Africa/Bissau"),
            TimeZoneOption("غيانا", "GY", "جورج تاون", "America/Guyana"),
            TimeZoneOption("هايتي", "HT", "بورت أو برنس", "America/Port-au-Prince"),
            TimeZoneOption("هندوراس", "HN", "تيغوسيغالبا", "America/Tegucigalpa"),
            TimeZoneOption("المجر", "HU", "بودابست", "Europe/Budapest"),
            TimeZoneOption("آيسلندا", "IS", "ريكيافيك", "Atlantic/Reykjavik"),
            TimeZoneOption("الهند", "IN", "نيودلهي", "Asia/Kolkata"),
            TimeZoneOption("إندونيسيا", "ID", "جاكرتا", "Asia/Jakarta"),
            TimeZoneOption("إيران", "IR", "طهران", "Asia/Tehran"),
            TimeZoneOption("العراق", "IQ", "بغداد", "Asia/Baghdad"),
            TimeZoneOption("أيرلندا", "IE", "دبلن", "Europe/Dublin"),
            TimeZoneOption("إيطاليا", "IT", "روما", "Europe/Rome"),
            TimeZoneOption("جامايكا", "JM", "كينغستون", "America/Jamaica"),
            TimeZoneOption("اليابان", "JP", "طوكيو", "Asia/Tokyo"),
            TimeZoneOption("الأردن", "JO", "عمّان", "Asia/Amman"),
            TimeZoneOption("كازاخستان", "KZ", "أستانا", "Asia/Almaty"),
            TimeZoneOption("كينيا", "KE", "نيروبي", "Africa/Nairobi"),
            TimeZoneOption("كيريباتي", "KI", "تاراوا", "Pacific/Tarawa"),
            TimeZoneOption("الكويت", "KW", "الكويت", "Asia/Kuwait"),
            TimeZoneOption("قيرغيزستان", "KG", "بيشكيك", "Asia/Bishkek"),
            TimeZoneOption("لاوس", "LA", "فيينتيان", "Asia/Vientiane"),
            TimeZoneOption("لاتفيا", "LV", "ريغا", "Europe/Riga"),
            TimeZoneOption("لبنان", "LB", "بيروت", "Asia/Beirut"),
            TimeZoneOption("ليسوتو", "LS", "ماسيرو", "Africa/Maseru"),
            TimeZoneOption("ليبيريا", "LR", "مونروفيا", "Africa/Monrovia"),
            TimeZoneOption("ليبيا", "LY", "طرابلس", "Africa/Tripoli"),
            TimeZoneOption("ليختنشتاين", "LI", "فادوتس", "Europe/Vaduz"),
            TimeZoneOption("ليتوانيا", "LT", "فيلنيوس", "Europe/Vilnius"),
            TimeZoneOption("لوكسمبورغ", "LU", "لوكسمبورغ", "Europe/Luxembourg"),
            TimeZoneOption("مدغشقر", "MG", "أنتاناناريفو", "Indian/Antananarivo"),
            TimeZoneOption("ملاوي", "MW", "ليلونغوي", "Africa/Blantyre"),
            TimeZoneOption("ماليزيا", "MY", "كوالالمبور", "Asia/Kuala_Lumpur"),
            TimeZoneOption("المالديف", "MV", "ماليه", "Indian/Maldives"),
            TimeZoneOption("مالي", "ML", "باماكو", "Africa/Bamako"),
            TimeZoneOption("مالطا", "MT", "فاليتا", "Europe/Malta"),
            TimeZoneOption("جزر مارشال", "MH", "ماجورو", "Pacific/Majuro"),
            TimeZoneOption("موريتانيا", "MR", "نواكشوط", "Africa/Nouakchott"),
            TimeZoneOption("موريشيوس", "MU", "بورت لويس", "Indian/Mauritius"),
            TimeZoneOption("المكسيك", "MX", "مكسيكو سيتي", "America/Mexico_City"),
            TimeZoneOption("ميكرونيزيا", "FM", "باليكير", "Pacific/Pohnpei"),
            TimeZoneOption("مولدوفا", "MD", "كيشيناو", "Europe/Chisinau"),
            TimeZoneOption("موناكو", "MC", "موناكو", "Europe/Monaco"),
            TimeZoneOption("منغوليا", "MN", "أولان باتور", "Asia/Ulaanbaatar"),
            TimeZoneOption("الجبل الأسود", "ME", "بودغوريتسا", "Europe/Podgorica"),
            TimeZoneOption("المغرب", "MA", "الرباط", "Africa/Casablanca"),
            TimeZoneOption("موزمبيق", "MZ", "مابوتو", "Africa/Maputo"),
            TimeZoneOption("ميانمار", "MM", "نايبيداو", "Asia/Yangon"),
            TimeZoneOption("ناميبيا", "NA", "ويندهوك", "Africa/Windhoek"),
            TimeZoneOption("ناورو", "NR", "يارين", "Pacific/Nauru"),
            TimeZoneOption("نيبال", "NP", "كاتماندو", "Asia/Kathmandu"),
            TimeZoneOption("هولندا", "NL", "أمستردام", "Europe/Amsterdam"),
            TimeZoneOption("نيوزيلندا", "NZ", "أوكلاند", "Pacific/Auckland"),
            TimeZoneOption("نيكاراغوا", "NI", "ماناغوا", "America/Managua"),
            TimeZoneOption("النيجر", "NE", "نيامي", "Africa/Niamey"),
            TimeZoneOption("نيجيريا", "NG", "أبوجا", "Africa/Lagos"),
            TimeZoneOption("كوريا الشمالية", "KP", "بيونغ يانغ", "Asia/Pyongyang"),
            TimeZoneOption("مقدونيا الشمالية", "MK", "سكوبيه", "Europe/Skopje"),
            TimeZoneOption("النرويج", "NO", "أوسلو", "Europe/Oslo"),
            TimeZoneOption("عُمان", "OM", "مسقط", "Asia/Muscat"),
            TimeZoneOption("باكستان", "PK", "إسلام آباد", "Asia/Karachi"),
            TimeZoneOption("بالاو", "PW", "نغيرولمود", "Pacific/Palau"),
            TimeZoneOption("فلسطين", "PS", "القدس", "Asia/Gaza"),
            TimeZoneOption("بنما", "PA", "بنما سيتي", "America/Panama"),
            TimeZoneOption("بابوا غينيا الجديدة", "PG", "بورت مورسبي", "Pacific/Port_Moresby"),
            TimeZoneOption("باراغواي", "PY", "أسونسيون", "America/Asuncion"),
            TimeZoneOption("بيرو", "PE", "ليما", "America/Lima"),
            TimeZoneOption("الفلبين", "PH", "مانيلا", "Asia/Manila"),
            TimeZoneOption("بولندا", "PL", "وارسو", "Europe/Warsaw"),
            TimeZoneOption("البرتغال", "PT", "لشبونة", "Europe/Lisbon"),
            TimeZoneOption("قطر", "QA", "الدوحة", "Asia/Qatar"),
            TimeZoneOption("رومانيا", "RO", "بوخارست", "Europe/Bucharest"),
            TimeZoneOption("روسيا", "RU", "موسكو", "Europe/Moscow"),
            TimeZoneOption("رواندا", "RW", "كيغالي", "Africa/Kigali"),
            TimeZoneOption("سانت كيتس ونيفيس", "KN", "باستير", "America/St_Kitts"),
            TimeZoneOption("سانت لوسيا", "LC", "كاستريس", "America/St_Lucia"),
            TimeZoneOption("سانت فنسنت والغرينادين", "VC", "كينغستاون", "America/St_Vincent"),
            TimeZoneOption("ساموا", "WS", "أبيا", "Pacific/Apia"),
            TimeZoneOption("سان مارينو", "SM", "سان مارينو", "Europe/San_Marino"),
            TimeZoneOption("ساو تومي وبرينسيبي", "ST", "ساو تومي", "Africa/Sao_Tome"),
            TimeZoneOption("السعودية", "SA", "الرياض", "Asia/Riyadh"),
            TimeZoneOption("السنغال", "SN", "داكار", "Africa/Dakar"),
            TimeZoneOption("صربيا", "RS", "بلغراد", "Europe/Belgrade"),
            TimeZoneOption("سيشل", "SC", "فيكتوريا", "Indian/Mahe"),
            TimeZoneOption("سيراليون", "SL", "فريتاون", "Africa/Freetown"),
            TimeZoneOption("سنغافورة", "SG", "سنغافورة", "Asia/Singapore"),
            TimeZoneOption("سلوفاكيا", "SK", "براتيسلافا", "Europe/Bratislava"),
            TimeZoneOption("سلوفينيا", "SI", "ليوبليانا", "Europe/Ljubljana"),
            TimeZoneOption("جزر سليمان", "SB", "هونيارا", "Pacific/Guadalcanal"),
            TimeZoneOption("الصومال", "SO", "مقديشو", "Africa/Mogadishu"),
            TimeZoneOption("جنوب أفريقيا", "ZA", "جوهانسبرغ", "Africa/Johannesburg"),
            TimeZoneOption("كوريا الجنوبية", "KR", "سيول", "Asia/Seoul"),
            TimeZoneOption("جنوب السودان", "SS", "جوبا", "Africa/Juba"),
            TimeZoneOption("إسبانيا", "ES", "مدريد", "Europe/Madrid"),
            TimeZoneOption("سريلانكا", "LK", "كولومبو", "Asia/Colombo"),
            TimeZoneOption("السودان", "SD", "الخرطوم", "Africa/Khartoum"),
            TimeZoneOption("سورينام", "SR", "باراماريبو", "America/Paramaribo"),
            TimeZoneOption("السويد", "SE", "ستوكهولم", "Europe/Stockholm"),
            TimeZoneOption("سويسرا", "CH", "زيورخ", "Europe/Zurich"),
            TimeZoneOption("سوريا", "SY", "دمشق", "Asia/Damascus"),
            TimeZoneOption("تايوان", "TW", "تايبيه", "Asia/Taipei"),
            TimeZoneOption("طاجيكستان", "TJ", "دوشنبه", "Asia/Dushanbe"),
            TimeZoneOption("تنزانيا", "TZ", "دار السلام", "Africa/Dar_es_Salaam"),
            TimeZoneOption("تايلاند", "TH", "بانكوك", "Asia/Bangkok"),
            TimeZoneOption("تيمور الشرقية", "TL", "ديلي", "Asia/Dili"),
            TimeZoneOption("توجو", "TG", "لومي", "Africa/Lome"),
            TimeZoneOption("تونغا", "TO", "نوكو ألوفا", "Pacific/Tongatapu"),
            TimeZoneOption("ترينيداد وتوباغو", "TT", "بورت أوف سبين", "America/Port_of_Spain"),
            TimeZoneOption("تونس", "TN", "تونس", "Africa/Tunis"),
            TimeZoneOption("تركيا", "TR", "إسطنبول", "Europe/Istanbul"),
            TimeZoneOption("تركمانستان", "TM", "عشق آباد", "Asia/Ashgabat"),
            TimeZoneOption("توفالو", "TV", "فونافوتي", "Pacific/Funafuti"),
            TimeZoneOption("أوغندا", "UG", "كمبالا", "Africa/Kampala"),
            TimeZoneOption("أوكرانيا", "UA", "كييف", "Europe/Kyiv"),
            TimeZoneOption("الإمارات", "AE", "دبي", "Asia/Dubai"),
            TimeZoneOption("المملكة المتحدة", "GB", "لندن", "Europe/London"),
            TimeZoneOption("الولايات المتحدة", "US", "نيويورك", "America/New_York"),
            TimeZoneOption("أوروغواي", "UY", "مونتيفيديو", "America/Montevideo"),
            TimeZoneOption("أوزبكستان", "UZ", "طشقند", "Asia/Tashkent"),
            TimeZoneOption("فانواتو", "VU", "بورت فيلا", "Pacific/Efate"),
            TimeZoneOption("الفاتيكان", "VA", "الفاتيكان", "Europe/Vatican"),
            TimeZoneOption("فنزويلا", "VE", "كاراكاس", "America/Caracas"),
            TimeZoneOption("فيتنام", "VN", "مدينة هو تشي منه", "Asia/Ho_Chi_Minh"),
            TimeZoneOption("اليمن", "YE", "صنعاء", "Asia/Aden"),
            TimeZoneOption("زامبيا", "ZM", "لوساكا", "Africa/Lusaka"),
            TimeZoneOption("زيمبابوي", "ZW", "هراري", "Africa/Harare"),
        ).sortedBy { it.city }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
        }

        val header = TextView(this).apply {
            text = "تحديد المنطقة الزمنية"
            textSize = 20f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(if (darkModeEnabled) Color.WHITE else Color.BLACK)
            setPadding(dp(16), dp(18), dp(16), dp(18))
        }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(68)))

        val searchBox = android.widget.EditText(this).apply {
            textSize = 16f
            setTextColor(if (darkModeEnabled) Color.WHITE else Color.BLACK)
            setHintTextColor(if (darkModeEnabled) Color.LTGRAY else Color.GRAY)
            hint = "بحث عن المنطقة الزمنية"
            setPadding(dp(14), 0, dp(14), 0)
            background = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.bg_address_bar)
            isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(searchBox, LinearLayout.LayoutParams(-1, dp(40)).apply {
            marginStart = dp(10)
            marginEnd = dp(10)
            bottomMargin = dp(10)
        })

        val list = android.widget.ListView(this).apply {
            divider = android.graphics.drawable.ColorDrawable(if (darkModeEnabled) Color.rgb(55, 55, 55) else Color.rgb(225, 225, 225))
            dividerHeight = dp(1)
            setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        val dialog = AlertDialog.Builder(this).setView(root).create()
        val filteredZones = zones.toMutableList()

        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = filteredZones.size
            override fun getItem(position: Int) = filteredZones[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val option = filteredZones[position]
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(18), dp(10), dp(18), dp(10))
                    setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
                }

                val arrow = TextView(this@MainActivity).apply {
                    text = "‹"
                    textSize = 34f
                    gravity = Gravity.CENTER
                    setTextColor(if (darkModeEnabled) Color.LTGRAY else Color.LTGRAY)
                }
                row.addView(arrow, LinearLayout.LayoutParams(dp(42), -1))

                val textBox = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val city = TextView(this@MainActivity).apply {
                    text = option.city
                    textSize = 17f
                    gravity = Gravity.END
                    setTextColor(if (darkModeEnabled) Color.WHITE else Color.BLACK)
                }
                val offset = TextView(this@MainActivity).apply {
                    text = "غرينتش ${formatGmtOffset(option.zoneId)}"
                    textSize = 14f
                    gravity = Gravity.END
                    setTextColor(if (darkModeEnabled) Color.LTGRAY else Color.DKGRAY)
                }
                textBox.addView(city, LinearLayout.LayoutParams(-1, dp(30)))
                textBox.addView(offset, LinearLayout.LayoutParams(-1, dp(25)))
                row.addView(textBox, LinearLayout.LayoutParams(0, -1, 1f))
                return row
            }
        }
        list.adapter = adapter

        searchBox.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString()?.trim()?.lowercase(java.util.Locale.ROOT).orEmpty()
                filteredZones.clear()
                if (query.isEmpty()) {
                    filteredZones.addAll(zones)
                } else {
                    filteredZones.addAll(zones.filter { option ->
                        option.country.lowercase(java.util.Locale.ROOT).contains(query) ||
                        option.city.lowercase(java.util.Locale.ROOT).contains(query) ||
                        option.zoneId.lowercase(java.util.Locale.ROOT).contains(query) ||
                        option.code.lowercase(java.util.Locale.ROOT).contains(query)
                    })
                }
                adapter.notifyDataSetChanged()
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        list.setOnItemClickListener { _, _, position, _ ->
            val selected = filteredZones[position]
            countryCode = selected.code
            countryName = selected.country
            timeZoneId = selected.zoneId
            timeZoneCity = selected.city
            timeZoneMenuItem.text = timeZoneMenuLabel()
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_COUNTRY_CODE, countryCode)
                .putString(KEY_COUNTRY_NAME, countryName)
                .putString(KEY_TIME_ZONE, timeZoneId)
                .putString(KEY_TIME_ZONE_CITY, timeZoneCity)
                .apply()
            dialog.dismiss()
            currentWebView()?.loadUrl(homeUrl())
        }

        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(),
            (resources.displayMetrics.heightPixels * 0.90f).toInt())
    }

    private fun timeZoneMenuLabel(): CharSequence {
        val city = timeZoneId.substringAfterLast('/').replace('_', ' ').lowercase(java.util.Locale.ENGLISH)
        val label = "Time Zone ($city)"
        val styled = SpannableString(label)
        val start = label.indexOf('(')
        if (start >= 0) {
            styled.setSpan(
                RelativeSizeSpan(0.82f),
                start,
                label.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        return styled
    }

    private fun formatGmtOffset(zoneId: String): String {
        val offsetMillis = TimeZone.getTimeZone(zoneId).getOffset(System.currentTimeMillis())
        val totalMinutes = offsetMillis / 60000
        val sign = if (totalMinutes >= 0) "+" else "-"
        val absoluteMinutes = kotlin.math.abs(totalMinutes)
        val hours = absoluteMinutes / 60
        val minutes = absoluteMinutes % 60
        return String.format(java.util.Locale.US, "%s%02d:%02d", sign, hours, minutes)
    }

    private fun homeUrl(): String = "https://accounts.google.com/?hl=ar&gl=$countryCode"

    private fun captureTabThumbnail(tab: BrowserTab): Bitmap? {
        val webView = tab.webView
        if (webView.width <= 0 || webView.height <= 0) return tab.thumbnail
        return try {
            // Keep enough resolution for the large Chrome-style tab cards.
            val maxWidth = dp(600)
            val ratio = maxWidth.toFloat() / webView.width.toFloat()
            val bitmap = Bitmap.createBitmap(
                maxWidth,
                (webView.height * ratio).toInt().coerceAtLeast(dp(180)),
                Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(bitmap)
            canvas.scale(ratio, ratio)
            webView.draw(canvas)
            bitmap
        } catch (_: Throwable) {
            tab.thumbnail
        }
    }

    private fun showTabSwitcher() {
        if (tabs.isNotEmpty()) {
            tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
        }

        // Match the reference: a light full-screen Chrome-style tab switcher,
        // with two large cards per row and generous outer/inner spacing.
        val backgroundColor = if (darkModeEnabled) Color.rgb(32, 33, 36) else Color.rgb(250, 250, 250)
        val cardColor = if (darkModeEnabled) Color.rgb(45, 46, 49) else Color.WHITE
        val textColor = if (darkModeEnabled) Color.WHITE else Color.rgb(45, 45, 45)
        val secondaryColor = if (darkModeEnabled) Color.LTGRAY else Color.rgb(80, 80, 80)
        val activeGreen = Color.rgb(17, 107, 55)

        val dialogRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(28), dp(8), dp(28), dp(14))
            setBackgroundColor(backgroundColor)
        }
        lateinit var dialog: AlertDialog

        // Chrome-like top controls.
        val topBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        val more = TextView(this).apply {
            text = "⋮"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(textColor)
            setPadding(0, 0, 0, dp(4))
            setOnClickListener { dialog.dismiss(); drawerLayout.openDrawer(Gravity.END) }
        }
        topBar.addView(more, LinearLayout.LayoutParams(dp(44), dp(58)))

        // Keep the tab counter visually centered in the top bar after removing
        // the extra grid button.
        val leftSpacer = View(this)
        topBar.addView(leftSpacer, LinearLayout.LayoutParams(0, dp(58), 1f))

        val countPill = TextView(this).apply {
            text = tabs.size.toString()
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(textColor)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(9).toFloat()
                setColor(if (darkModeEnabled) Color.rgb(58, 59, 62) else Color.WHITE)
                setStroke(dp(1), if (darkModeEnabled) Color.rgb(75, 76, 79) else Color.rgb(235, 235, 235))
            }
        }
        topBar.addView(countPill, LinearLayout.LayoutParams(dp(26), dp(26)).apply {
            gravity = Gravity.CENTER_VERTICAL
            leftMargin = dp(2)
        })

        val spacer = View(this)
        topBar.addView(spacer, LinearLayout.LayoutParams(0, dp(58), 1f))

        val add = TextView(this).apply {
            text = "+"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(Color.rgb(16, 123, 61))
            }
            setOnClickListener {
                dialog.dismiss()
                addTab(homeUrl())
            }
        }
        topBar.addView(add, LinearLayout.LayoutParams(dp(44), dp(44)))
        dialogRoot.addView(topBar, LinearLayout.LayoutParams(-1, dp(58)))

        val search = EditText(this).apply {
            hint = "البحث في علامات التبويب"
            textSize = 15f
            setSingleLine(true)
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            setTextColor(textColor)
            setHintTextColor(if (darkModeEnabled) Color.LTGRAY else Color.rgb(90, 90, 90))
            setPadding(dp(14), 0, dp(14), 0)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(35).toFloat()
                setColor(if (darkModeEnabled) Color.rgb(55, 56, 59) else Color.rgb(232, 232, 232))
            }
        }
        dialogRoot.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(2)
            leftMargin = dp(14)
            rightMargin = dp(14)
            bottomMargin = dp(12)
        })

        val grid = android.widget.GridLayout(this).apply {
            // Two columns so six tab cards (2 x 3) fit on the screen.
            columnCount = 2
            useDefaultMargins = false
            alignmentMode = android.widget.GridLayout.ALIGN_BOUNDS
        }
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(grid, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        dialogRoot.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun refreshGrid(filter: String = "") {
            grid.removeAllViews()
            val query = filter.trim().lowercase(java.util.Locale.getDefault())
            val visible = tabs.mapIndexedNotNull { index, tab ->
                val title = tab.title.ifBlank { "New tab" }
                if (query.isBlank() || title.lowercase(java.util.Locale.getDefault()).contains(query)) index to tab else null
            }

            // Six cards should be visible at once: 2 columns x 3 rows.
            // Keep compact gaps and let each card fill one half of the grid.
            val horizontalGap = dp(10)
            val verticalGap = dp(12)
            val availableWidth = resources.displayMetrics.widthPixels - dp(56)
            val cardWidth = ((availableWidth - horizontalGap) / 2).coerceAtLeast(dp(1))
            val cardHeight = dp(250)

            visible.forEachIndexed { position, pair ->
                val index = pair.first
                val tab = pair.second
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(0, 0, 0, 0)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(24).toFloat()
                        setColor(cardColor)
                        setStroke(
                            if (index == activeTab) dp(3) else dp(1),
                            if (index == activeTab) activeGreen
                            else if (darkModeEnabled) Color.rgb(75, 76, 79) else Color.rgb(225, 225, 225)
                        )
                    }
                    elevation = dp(1).toFloat()
                    clipToOutline = true
                    isClickable = true
                    isFocusable = true
                    setOnClickListener {
                        if (tabs.isNotEmpty()) tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
                        activeTab = index
                        dialog.dismiss()
                        showActiveWebView()
                    }
                }

                val topRow = LinearLayout(this).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_LTR
                    setPadding(dp(8), 0, dp(8), 0)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadii = floatArrayOf(
                            dp(21).toFloat(), dp(21).toFloat(),
                            dp(21).toFloat(), dp(21).toFloat(),
                            0f, 0f, 0f, 0f
                        )
                        setColor(if (index == activeTab) activeGreen else cardColor)
                    }
                }

                val close = TextView(this).apply {
                    text = "×"
                    textSize = 28f
                    gravity = Gravity.CENTER
                    setTextColor(if (index == activeTab) Color.WHITE else secondaryColor)
                    setOnClickListener {
                        closeTab(index)
                        if (tabs.isEmpty()) {
                            dialog.dismiss()
                        } else {
                            if (activeTab >= tabs.size) activeTab = tabs.lastIndex
                            refreshGrid(search.text?.toString() ?: "")
                        }
                    }
                }
                topRow.addView(close, LinearLayout.LayoutParams(dp(34), dp(46)))

                val tabTitle = TextView(this).apply {
                    text = tab.title.ifBlank { "New tab" }
                    textSize = 15.5f
                    setTextColor(if (index == activeTab) Color.WHITE else textColor)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER_VERTICAL
                }
                topRow.addView(tabTitle, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                    leftMargin = dp(4)
                    rightMargin = dp(4)
                })

                val favicon = ImageView(this).apply {
                    val icon = tab.webView.favicon
                    if (icon != null) {
                        setImageBitmap(icon)
                    } else {
                        setImageDrawable(ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.ic_em_browser))
                    }
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                }
                topRow.addView(favicon, LinearLayout.LayoutParams(dp(32), dp(46)))
                card.addView(topRow, LinearLayout.LayoutParams(-1, dp(46)))

                val thumbnail = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setBackgroundColor(if (darkModeEnabled) Color.rgb(35, 36, 39) else Color.WHITE)
                    clipToOutline = true
                    outlineProvider = object : android.view.ViewOutlineProvider() {
                        override fun getOutline(view: View, outline: android.graphics.Outline) {
                            outline.setRoundRect(0, 0, view.width, view.height, dp(18).toFloat())
                        }
                    }
                    tab.thumbnail?.let { setImageBitmap(it) }
                    if (drawable == null) {
                        setImageDrawable(ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.ic_em_browser))
                        scaleType = ImageView.ScaleType.CENTER_INSIDE
                    }
                }
                card.addView(thumbnail, LinearLayout.LayoutParams(-1, 0, 1f).apply {
                    leftMargin = dp(5)
                    rightMargin = dp(5)
                    bottomMargin = dp(5)
                })

                val lp = android.widget.GridLayout.LayoutParams().apply {
                    width = cardWidth
                    height = cardHeight
                    columnSpec = android.widget.GridLayout.spec(position % 2, 1)
                    rowSpec = android.widget.GridLayout.spec(position / 2)
                    setMargins(
                        if (position % 2 == 0) 0 else horizontalGap / 2,
                        verticalGap / 2,
                        if (position % 2 == 1) 0 else horizontalGap / 2,
                        verticalGap / 2
                    )
                }
                grid.addView(card, lp)
            }

            // New-tab card is part of the same two-column grid.
            val newTabCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(24).toFloat()
                    setColor(cardColor)
                    setStroke(dp(1), if (darkModeEnabled) Color.rgb(75, 76, 79) else Color.rgb(225, 225, 225))
                }
                setOnClickListener {
                    dialog.dismiss()
                    addTab(homeUrl())
                }
            }
            val newIcon = ImageView(this).apply {
                setImageDrawable(ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.ic_em_browser))
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(20), dp(20), dp(20), dp(8))
            }
            newTabCard.addView(newIcon, LinearLayout.LayoutParams(-1, 0, 1f))
            val newLabel = TextView(this).apply {
                text = "علامة تبويب جديدة"
                textSize = 15f
                gravity = Gravity.CENTER
                setTextColor(textColor)
            }
            newTabCard.addView(newLabel, LinearLayout.LayoutParams(-1, dp(46)))
            val newLp = android.widget.GridLayout.LayoutParams().apply {
                width = cardWidth
                height = cardHeight
                columnSpec = android.widget.GridLayout.spec(visible.size % 2, 1)
                rowSpec = android.widget.GridLayout.spec(visible.size / 2)
                setMargins(
                    if (visible.size % 2 == 0) 0 else horizontalGap / 2,
                    verticalGap / 2,
                    if (visible.size % 2 == 1) 0 else horizontalGap / 2,
                    verticalGap / 2
                )
            }
            if (query.isBlank()) grid.addView(newTabCard, newLp)
        }

        refreshGrid()
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = refreshGrid(s?.toString() ?: "")
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        dialog = AlertDialog.Builder(this)
            .setView(dialogRoot)
            .create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(backgroundColor)
            })
            dialog.window?.setStatusBarColor(backgroundColor)
            dialog.window?.setNavigationBarColor(backgroundColor)
            dialog.window?.decorView?.systemUiVisibility = if (darkModeEnabled) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(backgroundColor)
        })
        dialog.window?.setStatusBarColor(backgroundColor)
        dialog.window?.setNavigationBarColor(backgroundColor)
        dialog.window?.decorView?.systemUiVisibility = if (darkModeEnabled) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    }

    private fun loadAddress(raw: String) {
        val input = raw.trim()
        if (input.isBlank()) return
        val url = if (android.util.Patterns.WEB_URL.matcher(input).matches() &&
            (input.startsWith("http://") || input.startsWith("https://"))) {
            input
        } else if (input.contains(".") && !input.contains(" ")) {
            "https://$input"
        } else {
            "https://www.google.com/search?q=" + android.net.Uri.encode(input)
        }
        progressAnimator?.cancel()
        pageProgress.progress = 0
        pageProgress.visibility = View.VISIBLE
        currentWebView()?.loadUrl(withArabicLanguage(url))
        addressBar.clearFocus()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun addTab(url: String, restoredProfileName: String? = null, loadPage: Boolean = true) {
        if (tabs.isNotEmpty()) {
            tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
        }

        val profileName = restoredProfileName ?: if (tabs.isEmpty()) {
            // Keep the first tab on WebView's default profile so an existing
            // Google Account session remains available there.
            Profile.DEFAULT_PROFILE_NAME
        } else {
            // Every new tab gets its own persistent WebView profile. Cookies,
            // local storage and other site data are therefore not shared with
            // the first tab or with any other tab.
            "em_tab_${System.currentTimeMillis()}_${tabs.size}"
        }

        val webView = WebView(this)
        applyProfile(webView, profileName)
        val tab = BrowserTab(webView = webView, profileName = profileName)
        tabs.add(tab)
        // A new tab is a new automation run. Settings remain enabled, but the
        // master Automation switch controls whether execution starts automatically
        // once this tab reaches Google/Gmail.
        automationCompletedForCurrentAccount = false
        automationHasRunInCurrentGoogleSession = false
        completedAccountKey = ""
        currentAccountKey = ""
        passwordAutomationActive = false
        passwordFlowStartedForCurrentAutomation = false
        passwordChangeSubmitted = false
        recoveryEmailAutomationActive = false
        recoveryRemovalAwaitingVerification = false
        combinedAutomationWaitingForPassword = false
        recoveryDirectRetryCount = 0
        configureWebView(webView)
        activeTab = tabs.lastIndex
        showActiveWebView()
        progressAnimator?.cancel()
        pageProgress.progress = 0
        pageProgress.visibility = View.VISIBLE
        if (loadPage) {
            webView.loadUrl(withArabicLanguage(url))
        }
        updateChromeBar()
        saveTabsState()
    }

    private fun saveTabsState() {
        if (incognitoEnabled || tabs.isEmpty()) return

        val array = JSONArray()
        tabs.forEach { tab ->
            val url = tab.webView.url?.takeIf { it.isNotBlank() } ?: HOME_URL
            array.put(JSONObject().apply {
                put("url", url)
                put("title", tab.title)
                put("profile", tab.profileName)
            })
        }

        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_TABS_STATE, array.toString())
            .putInt(KEY_ACTIVE_TAB, activeTab.coerceIn(0, tabs.lastIndex))
            .apply()
    }

    private fun restoreTabsState(): Boolean {
        if (incognitoEnabled) return false

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val raw = prefs.getString(KEY_TABS_STATE, null) ?: return false
        return runCatching {
            val array = JSONArray(raw)
            if (array.length() == 0) return false

            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val url = item.optString("url", HOME_URL).ifBlank { HOME_URL }
                val title = item.optString("title", "New tab").ifBlank { "New tab" }
                val profile = item.optString("profile", Profile.DEFAULT_PROFILE_NAME)
                    .ifBlank { Profile.DEFAULT_PROFILE_NAME }
                addTab(url, profile, loadPage = true)
                tabs.last().title = title
            }

            activeTab = prefs.getInt(KEY_ACTIVE_TAB, 0).coerceIn(0, tabs.lastIndex)
            showActiveWebView()
            updateChromeBar()
            true
        }.getOrElse {
            prefs.edit().remove(KEY_TABS_STATE).remove(KEY_ACTIVE_TAB).apply()
            false
        }
    }

    private fun applyProfile(webView: WebView, profileName: String) {
        if (profileName == Profile.DEFAULT_PROFILE_NAME) return
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            WebViewCompat.setProfile(webView, profileName)
        }
    }

    private fun detectGoogleAccountKey(view: WebView, onDetected: (String) -> Unit) {
        val script = """
            (function() {
              const emailRe = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig;
              const priority = Array.from(document.querySelectorAll('[data-email],[aria-label],[title]'))
                .map(el => [el.getAttribute('data-email'), el.getAttribute('aria-label'), el.getAttribute('title')].filter(Boolean).join(' '))
                .filter(v => /google account|حساب google|حساب Google|account/.test(v.toLowerCase()));
              const matches = priority.join('\n').match(emailRe);
              if (matches && matches.length) return matches[0].toLowerCase();

              const dataEmail = Array.from(document.querySelectorAll('[data-email]'))
                .map(el => el.getAttribute('data-email') || '').find(v => emailRe.test(v));
              if (dataEmail) return dataEmail.toLowerCase();

              // Fallback for Gmail pages where the account menu exposes the email only in its label.
              const labels = Array.from(document.querySelectorAll('[aria-label],[title]'))
                .map(el => [el.getAttribute('aria-label'), el.getAttribute('title')].filter(Boolean).join(' '));
              const fallback = labels.join('\n').match(emailRe);
              return fallback && fallback.length ? fallback[0].toLowerCase() : '';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            val key = result?.trim('"')?.replace("\\\"", "\"")?.trim().orEmpty()
            onDetected(key)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(webView: WebView) {
        webView.settings.apply {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            builtInZoomControls = false
            displayZoomControls = false
            domStorageEnabled = !incognitoEnabled
            databaseEnabled = !incognitoEnabled
            cacheMode = if (incognitoEnabled) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false
            allowContentAccess = false
            textZoom = zoomPercent
            userAgentString = "${WebSettings.getDefaultUserAgent(this@MainActivity)} eM-browser/2.0 (ar-EG)"
        }

        webView.setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (::pageProgress.isInitialized && view === currentWebView()) {
                    val target = newProgress.coerceIn(0, 100)
                    if (target < 100) {
                        pageProgress.visibility = View.VISIBLE
                    }
                    progressAnimator?.cancel()
                    progressAnimator = ObjectAnimator.ofInt(pageProgress, "progress", pageProgress.progress, target).apply {
                        duration = if (target >= 100) 220L else 260L
                        start()
                    }
                    if (target >= 100) {
                        pageProgress.postDelayed({
                            if (pageProgress.progress >= 100) pageProgress.visibility = View.GONE
                        }, 240L)
                    }
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                view.loadUrl(withArabicLanguage(request.url.toString()))
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.settings.textZoom = zoomPercent
                val index = tabs.indexOfFirst { it.webView === view }
                if (index >= 0) {
                    tabs[index].title = view.title?.ifBlank { "eM gmail" } ?: "eM gmail"
                    if (index == activeTab) {
                        updateChromeBar()
                        addressBar.setText(url ?: view.url ?: "")
                    }
                }
                val pageUrl = url.orEmpty()
                // Recovery automation must stay on Google's dedicated Recovery Email page.
                // If Google lands on the recovery-phone page, never start Password from there;
                // return once to the direct Recovery Email destination instead.
                if (recoveryEmailAutomationActive &&
                    pageUrl.contains("myaccount.google.com/recovery/phone")) {
                    if (recoveryDirectRetryCount < 2) {
                        recoveryDirectRetryCount++
                        view.postDelayed({
                            if (recoveryEmailAutomationActive) view.loadUrl(RECOVERY_EMAIL_URL)
                        }, 250L)
                    }
                    return
                }
                val isGoogleAccountPage = pageUrl.contains("myaccount.google.com") || pageUrl.contains("accounts.google.com")
                val isGmailPage = pageUrl.contains("mail.google.com")
                if (isGoogleAccountPage || isGmailPage) {
                    lastAutomationUrl = pageUrl
                    detectGoogleAccountKey(view) { detectedKey ->
                        if (detectedKey.isNotBlank()) {
                            val accountChanged = currentAccountKey.isNotBlank() && currentAccountKey != detectedKey
                            currentAccountKey = detectedKey
                            if (accountChanged) {
                                automationCompletedForCurrentAccount = false
                                automationHasRunInCurrentGoogleSession = false
                                completedAccountKey = ""
                            }
                        }

                        if (automationCompletedForCurrentAccount && completedAccountKey.isNotBlank() && currentAccountKey.isNotBlank() && completedAccountKey != currentAccountKey) {
                            automationCompletedForCurrentAccount = false
                            automationHasRunInCurrentGoogleSession = false
                        }

                        if (passwordAutomationActive) {
                            view.postDelayed({ injectPasswordChangeScript(view) }, 500L)
                        }
                        if (recoveryEmailAutomationActive) {
                            view.postDelayed({ injectRecoveryEmailRemovalScript(view) }, 700L)
                        }
                        if (automationMasterEnabled && !passwordAutomationActive && !recoveryEmailAutomationActive && !automationCompletedForCurrentAccount) {
                            view.postDelayed({ startConfiguredAutomationForCurrentAccount() }, 250L)
                        }
                    }
                }
                saveTabsState()
            }

            override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                // Recover from a WebView renderer crash without taking down the
                // whole browser. This is important when several tabs are open.
                val index = tabs.indexOfFirst { it.webView === view }
                if (index < 0) return true

                val urlToRestore = view.url ?: HOME_URL
                (view.parent as? ViewGroup)?.removeView(view)
                view.stopLoading()
                view.destroy()

                val replacement = WebView(this@MainActivity)
                val oldTitle = tabs[index].title
                val profileName = tabs[index].profileName
                tabs[index].webView = replacement
                tabs[index].title = oldTitle
                applyProfile(replacement, profileName)
                configureWebView(replacement)

                if (index == activeTab) {
                    showActiveWebView()
                    replacement.loadUrl(withArabicLanguage(urlToRestore))
                } else {
                    replacement.loadUrl(withArabicLanguage(urlToRestore))
                }
                return true
            }
        }
    }

    private fun showActiveWebView() {
        // A WebView can only have one parent. The previous implementation left
        // an inactive WebView attached to its old SwipeRefreshLayout after the
        // tab container was removed, which could crash when switching between
        // multiple tabs (especially when the same page was opened more than once).
        val webView = tabs.getOrNull(activeTab)?.webView ?: return
        (webView.parent as? ViewGroup)?.removeView(webView)
        contentFrame.removeAllViews()

        val refresh = SwipeRefreshLayout(this).apply {
            setColorSchemeColors(ContextCompat.getColor(this@MainActivity, R.color.page_progress_blue))
            addView(webView, ViewGroup.LayoutParams(-1, -1))
            setOnRefreshListener {
                webView.reload()
                postDelayed({ isRefreshing = false }, 800)
            }
        }
        contentFrame.addView(refresh, LinearLayout.LayoutParams(-1, -1))
        updateChromeBar()
    }

    private fun updateChromeBar() {
        if (::tabCountView.isInitialized) tabCountView.text = tabs.size.toString()
        if (::addressBar.isInitialized) {
            currentWebView()?.url?.let { addressBar.setText(it) }
        }
    }

    private fun closeTab(index: Int) {
        if (tabs.size == 1) {
            tabs[0].webView.loadUrl(HOME_URL)
            tabs[0].title = "New tab"
            updateChromeBar()
            saveTabsState()
            return
        }
        val tab = tabs.removeAt(index)
        tab.webView.stopLoading()
        tab.webView.destroy()
        // Remove the tab's private profile after its WebView is gone.
        // The default profile belongs to the first tab and is intentionally kept.
        if (tab.profileName != Profile.DEFAULT_PROFILE_NAME &&
            WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            runCatching { ProfileStore.getInstance().deleteProfile(tab.profileName) }
        }
        activeTab = when {
            activeTab >= tabs.size -> tabs.lastIndex
            index < activeTab -> activeTab - 1
            else -> activeTab
        }
        showActiveWebView()
        saveTabsState()
    }

    private fun showClearAllDataDialog() {
        val dialog = AlertDialog.Builder(this)
            .setMessage("هل تريد مسح جميع البيانات؟")
            .setNegativeButton("لا", null)
            .setPositiveButton("نعم") { _, _ ->
                clearAllBrowserData()
            }
            .create()

        dialog.setOnShowListener {
            val isDark = darkModeEnabled
            val dialogBackground = if (isDark) Color.BLACK else Color.WHITE
            val dialogText = if (isDark) Color.WHITE else Color.BLACK

            dialog.window?.setBackgroundDrawable(
                android.graphics.drawable.ColorDrawable(dialogBackground)
            )
            dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(dialogText)
        }

        dialog.show()
    }

    /**
     * Resets eM browser to a first-install state without uninstalling the APK.
     * All browser/site data and all app preferences created by the browser are removed.
     */
    private fun clearAllBrowserData() {
        // Destroy every WebView first so no page can recreate data while we are clearing it.
        tabs.forEach { tab ->
            tab.webView.stopLoading()
            tab.webView.clearHistory()
            tab.webView.clearCache(true)
            tab.webView.clearFormData()
            tab.webView.clearSslPreferences()
            tab.webView.clearMatches()
            tab.webView.destroy()
        }
        tabs.clear()
        activeTab = 0

        // Clear every tab profile as well as the default profile. Profiles keep
        // separate cookies/storage, so clearing only CookieManager.getInstance()
        // would leave login data behind in other tabs.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            runCatching {
                val store = ProfileStore.getInstance()
                store.getAllProfileNames().forEach { name ->
                    if (name != Profile.DEFAULT_PROFILE_NAME) {
                        store.getProfile(name)?.let { profile ->
                            profile.getCookieManager().removeAllCookies(null)
                            profile.getWebStorage().deleteAllData()
                        }
                    }
                }
            }
        }

        // Clear WebView's default-profile browser stores.
        WebStorage.getInstance().deleteAllData()
        val webViewDatabase = WebViewDatabase.getInstance(this)
        webViewDatabase.clearHttpAuthUsernamePassword()
        webViewDatabase.clearFormData()
        webViewDatabase.clearUsernamePassword()

        // Cookie deletion is asynchronous; finish the reset only after it completes.
        val cookieManager = CookieManager.getInstance()
        cookieManager.removeAllCookies {
            cookieManager.removeSessionCookies {
                cookieManager.flush()
                finishFullBrowserReset()
            }
        }
        cookieManager.flush()
    }

    private fun finishFullBrowserReset() {
        // Remove all preferences saved by eM browser, including appearance and zoom settings.
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().commit()
        incognitoEnabled = false
        darkModeEnabled = false
        zoomPercent = 100

        // Remove app-private files, databases, caches, and preferences created at runtime.
        deleteDirectoryContents(filesDir)
        deleteDirectoryContents(cacheDir)
        deleteDirectoryContents(noBackupFilesDir)
        deleteDirectoryContents(File(applicationInfo.dataDir, "shared_prefs"))
        databaseList().forEach { name -> deleteDatabase(name) }
        externalCacheDir?.let { deleteDirectoryContents(it) }

        // WebView can keep additional runtime data under app_webview/code_cache.
        File(applicationInfo.dataDir, "app_webview").let { if (it.exists()) it.deleteRecursively() }
        File(applicationInfo.dataDir, "code_cache").let { if (it.exists()) it.deleteRecursively() }

        // Re-read the same defaults used by a brand-new installation.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        // Recreate the activity so a completely fresh WebView and UI are constructed.
        recreate()
    }

    private fun deleteDirectoryContents(directory: File) {
        directory.listFiles()?.forEach { file ->
            if (file.isDirectory) file.deleteRecursively() else file.delete()
        }
    }

    private fun showZoomDialog() {
        val appTextColor = if (darkModeEnabled) Color.WHITE else Color.BLACK
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), dp(8))
        }
        val label = TextView(this).apply {
            text = "حجم النص والواجهة: $zoomPercent%"
            textSize = 17f
            setTextColor(appTextColor)
        }
        val seek = SeekBar(this).apply {
            min = MIN_ZOOM
            max = MAX_ZOOM
            progress = zoomPercent
            progressTintList = android.content.res.ColorStateList.valueOf(appTextColor)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(
                if (darkModeEnabled) Color.DKGRAY else Color.LTGRAY
            )
            thumbTintList = android.content.res.ColorStateList.valueOf(appTextColor)
        }
        box.addView(label)
        box.addView(seek)

        val dialog = AlertDialog.Builder(this)
            .setTitle("حجم النص والواجهة")
            .setView(box)
            .setPositiveButton("تم", null)
            .create()

        dialog.setOnShowListener {
            val dialogBackground = if (darkModeEnabled) Color.BLACK else Color.WHITE
            val dialogText = if (darkModeEnabled) Color.WHITE else Color.BLACK
            dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(dialogBackground))
            dialog.findViewById<TextView>(androidx.appcompat.R.id.alertTitle)?.setTextColor(dialogText)
            dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(dialogText)
        }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                zoomPercent = value.coerceIn(MIN_ZOOM, MAX_ZOOM)
                label.text = "حجم النص والواجهة: $zoomPercent%"
                tabs.forEach { it.webView.settings.textZoom = zoomPercent }
                updateChromeBar()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        dialog.setOnDismissListener {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_ZOOM, zoomPercent).apply()
        }
        dialog.show()
    }

    private fun setIncognitoMode(enabled: Boolean) {
        incognitoEnabled = enabled
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_INCOGNITO, enabled).apply()
        if (enabled) clearPrivateData()
        tabs.forEach {
            it.webView.settings.domStorageEnabled = !enabled
            it.webView.settings.databaseEnabled = !enabled
            it.webView.settings.cacheMode = if (enabled) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        }
    }

    private fun clearPrivateData() {
        tabs.forEach {
            it.webView.clearHistory()
            it.webView.clearCache(true)
            it.webView.clearFormData()
            it.webView.clearSslPreferences()
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            tabs.forEach { tab ->
                runCatching {
                    WebViewCompat.getProfile(tab.webView).getCookieManager().removeAllCookies(null)
                    WebViewCompat.getProfile(tab.webView).getWebStorage().deleteAllData()
                }
            }
        } else {
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
        }
        CookieManager.getInstance().flush()
    }

    private fun setDarkMode(enabled: Boolean) {
        darkModeEnabled = enabled
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_DARK, enabled).apply()
        AppCompatDelegate.setDefaultNightMode(
            if (enabled) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !enabled
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !enabled
    }

    private fun currentWebView(): WebView? = tabs.getOrNull(activeTab)?.webView

    private fun withArabicLanguage(url: String): String {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return url
        if (url.contains("hl=", ignoreCase = true)) return url
        return url + if (url.contains("?")) "&hl=ar" else "?hl=ar"
    }

    private fun resolveColor(attr: Int): Int {
        val value = android.util.TypedValue()
        theme.resolveAttribute(attr, value, true)
        return if (value.resourceId != 0) ContextCompat.getColor(this, value.resourceId) else value.data
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onStop() {
        // Persist open tabs and WebView site state before Android may stop the activity/process.
        saveTabsState()
        // Persist WebView cookies/site state before Android may stop the activity/process.
        runCatching { CookieManager.getInstance().flush() }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            tabs.forEach { tab ->
                runCatching { WebViewCompat.getProfile(tab.webView).getCookieManager().flush() }
            }
        }
        super.onStop()
    }

    override fun onDestroy() {
        // Never clear browser/site data automatically when the activity is destroyed.
        // Browsing data is removed only through the user's explicit Clear Browsing Data action.
        tabs.forEach { it.webView.stopLoading(); it.webView.destroy() }
        super.onDestroy()
    }
}
