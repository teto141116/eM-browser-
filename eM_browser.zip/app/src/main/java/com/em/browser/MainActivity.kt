package com.em.browser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject
import android.text.Spannable
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebChromeClient
import android.webkit.WebStorage
import android.webkit.WebViewDatabase
import java.io.File
import java.nio.ByteBuffer
import java.util.Locale
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import java.util.TimeZone
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.animation.ObjectAnimator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Button
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.core.content.ContextCompat
import androidx.webkit.Profile
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.NotFoundException
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.BarcodeFormat

class MainActivity : AppCompatActivity() {


    private data class BrowserTab(
        var webView: WebView,
        var profileName: String = Profile.DEFAULT_PROFILE_NAME,
        var title: String = "New tab",
        var thumbnail: Bitmap? = null
    )

    private inner class InspectBridge {
        @JavascriptInterface
        fun report(payload: String) {
            runOnUiThread { showInspectDetails(payload) }
        }
    }

    private val inspectBridge = InspectBridge()

    private val tabs = mutableListOf<BrowserTab>()
    private var activeTab = 0
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var rootLayout: LinearLayout
    private lateinit var chromeBar: LinearLayout
    private lateinit var addressBar: android.widget.EditText
    private lateinit var tabCountView: TextView
    private lateinit var contentFrame: LinearLayout
    private lateinit var pageProgress: ProgressBar
    private lateinit var sideMenu: LinearLayout
    private lateinit var timeZoneMenuItem: TextView
    private lateinit var languageMenuItem: TextView
    private lateinit var systemBottomSpacer: View
    private var progressAnimator: ObjectAnimator? = null

    private var incognitoEnabled = false
    private var darkModeEnabled = false
    private var zoomPercent = 100
    private var countryCode = "EG"
    private var countryName = "Egypt"
    private var timeZoneId = "Africa/Cairo"
    private var timeZoneCity = "القاهرة"
    private var browserLanguage = "ar"
    private var automationMasterEnabled = false
    private var supervisionAutomationEnabled = false
    private var supervisionAutomationActive = false
    private var supervisionAutomationStage = "idle"
    private var supervisionAutomationClickIssued = false
    private var supervisionAgreeWasIssued = false
    private var supervisionPreAgreeUrl = ""
    private var supervisionPreAgreeBody = ""
    private var outAutomationEnabled = false
    private var outAutomationActive = false
    private var outAutomationStage = "idle"
    private var outAutomationClickIssued = false
    private var inspectModeEnabled = false
    private var passwordAutomationEnabled = false
    private var passwordAutomationActive = false
    private var passwordAutomationCurrent = ""
    private var passwordAutomationNew = ""
    private var passwordChangeSubmitted = false
    private var passwordReauthSubmitted = false
    // Hard guard for the entire password stage. This stays true across WebView
    // reloads/navigation and is cleared only after Google reports success or an
    // explicit password-change error.
    private var passwordFlowStartedForCurrentAutomation = false
    private var recoveryDirectRetryCount = 0
    private var recoveryEmailAutomationEnabled = false
    private var recoveryEmailAutomationActive = false
    private var combinedAutomationWaitingForPassword = false
    private var automationCompletedForCurrentAccount = false
    private var automationHasRunInCurrentGoogleSession = false
    private var lastAutomationUrl = ""
    private var recoveryRemovalAwaitingVerification = false
    private var recoveryEmailPageOpened = false
    private var recoveryTrashClicked = false
    private var recoverySuccessNotificationSeen = false
    private var completedAccountKey = ""
    private var currentAccountKey = ""
    // Account identity is tracked per tab/WebView so Authenticator records from
    // different tabs are always written to the same app-wide log without mixing accounts.
    private val accountKeyByWebView = java.util.WeakHashMap<WebView, String>()
    private var authenticatorSecret = ""
    private var authenticatorLabel = ""
    private var authenticatorAlgorithm = "SHA1"
    private var authenticatorDigits = 6
    private var authenticatorPeriod = 30L
    private var authenticatorOtpauthUri = ""
    private var authenticatorTimer: android.os.CountDownTimer? = null
    private var authenticatorAutomationEnabled = false
    private var authenticatorAutomationActive = false
    private var authenticatorAutomationStage = "idle"
    private var authenticatorAutomationQrScanned = false
    private var authenticatorAutomationCodeSubmitted = false
    private var authenticatorAutomationTurnOnClicked = false
    private var authenticatorAutomationFinalTurnOnClicked = false
    private var authenticatorAutomationFinalRefreshDone = false
    private var authenticatorAutomationSuccessSeen = false
    private var authenticatorAutomationLoadStarted = false
    private var authenticatorAutomationTrashClickIssued = false
    private var authenticatorAutomationRemoveAnywayClickIssued = false
    private var authenticatorAutomationQrScanInFlight = false
    private var twoStepAutomationEnabled = false
    private var twoStepAutomationActive = false
    private var twoStepAutomationStage = "idle"
    private var twoStepAutomationRefreshDone = false
    private var twoStepAutomationTurnOnClicked = false
    private var twoStepAutomationSkipClicked = false
    private var twoStepAutomationFallbackRefreshDone = false
    // Google may require the account password again between Auto stages. This
    // verifier pauses the current stage, submits the saved Current Password,
    // and resumes only after the verification page has been left.
    private var googleVerificationActive = false
    private var googleVerificationSubmitIssued = false
    private var googleVerificationNoticeShown = false
    private var googleVerificationCheckPending = false

    companion object {
        private const val HOME_URL = "https://accounts.google.com/?hl=en"
        private const val RECOVERY_EMAIL_URL = "https://myaccount.google.com/recovery/email"
        private const val PREFS = "browser_prefs"
        private const val KEY_INCOGNITO = "incognito"
        private const val KEY_DARK = "dark"
        private const val KEY_ZOOM = "zoom"
        private const val KEY_COUNTRY_CODE = "country_code"
        private const val KEY_COUNTRY_NAME = "country_name"
        private const val KEY_TIME_ZONE = "time_zone"
        private const val KEY_TIME_ZONE_CITY = "time_zone_city"
        private const val KEY_LANGUAGE = "browser_language"
        private const val KEY_TABS_STATE = "tabs_state"
        private const val KEY_ACTIVE_TAB = "active_tab"
        private const val KEY_AUTOMATION_MASTER_ENABLED = "automation_master_enabled"
        private const val KEY_SUPERVISION_AUTOMATION_ENABLED = "supervision_automation_enabled"
        private const val KEY_OUT_AUTOMATION_ENABLED = "out_automation_enabled"
        private const val OUT_LEAVE_FAMILY_URL = "https://myaccount.google.com/family/leave"
        private const val KEY_INSPECT_MODE_ENABLED = "inspect_mode_enabled"
        private const val SUPERVISION_GRADUATION_URL = "https://families.google.com/lifecycle/steps/teengraduation/intro?TL=ADG-GRSfdjyxrq5obKViBDEXnlrn3VyKBZ8LiGBgG90zfCO6MjyicjrCFJVosKi1&utm_source=google-account&utm_medium=web&hl=en&theme=mn&ss_mode=0"
        private const val KEY_PASSWORD_AUTOMATION_ENABLED = "password_automation_enabled"
        private const val KEY_PASSWORD_CURRENT = "password_automation_current"
        private const val KEY_PASSWORD_NEW = "password_automation_new"
        private const val KEY_RECOVERY_EMAIL_AUTOMATION_ENABLED = "recovery_email_automation_enabled"
        private const val KEY_AUTHENTICATOR_AUTOMATION_ENABLED = "authenticator_automation_enabled"
        private const val KEY_TWO_STEP_AUTOMATION_ENABLED = "two_step_automation_enabled"
        private const val TWO_STEP_VERIFICATION_URL = "https://myaccount.google.com/signinoptions/twosv"
        private const val AUTHENTICATOR_SETUP_URL = "https://myaccount.google.com/two-step-verification/authenticator"
        private const val KEY_TOTP_SECRET = "totp_secret"
        private const val KEY_TOTP_LABEL = "totp_label"
        private const val KEY_TOTP_ALGORITHM = "totp_algorithm"
        private const val KEY_TOTP_DIGITS = "totp_digits"
        private const val KEY_TOTP_PERIOD = "totp_period"
        private const val KEY_TOTP_ACCOUNTS = "totp_accounts"
        private const val MIN_ZOOM = 50
        private const val MAX_ZOOM = 120
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        incognitoEnabled = prefs.getBoolean(KEY_INCOGNITO, false)
        darkModeEnabled = prefs.getBoolean(KEY_DARK, false)
        zoomPercent = prefs.getInt(KEY_ZOOM, 100).coerceIn(MIN_ZOOM, MAX_ZOOM)
        countryCode = prefs.getString(KEY_COUNTRY_CODE, "EG") ?: "EG"
        countryName = prefs.getString(KEY_COUNTRY_NAME, "Egypt") ?: "Egypt"
        timeZoneId = prefs.getString(KEY_TIME_ZONE, "Africa/Cairo") ?: "Africa/Cairo"
        timeZoneCity = prefs.getString(KEY_TIME_ZONE_CITY, "القاهرة") ?: "القاهرة"
        browserLanguage = prefs.getString(KEY_LANGUAGE, "ar")?.lowercase(Locale.US)?.let { if (it == "en") "en" else "ar" } ?: "ar"
        automationMasterEnabled = prefs.getBoolean(KEY_AUTOMATION_MASTER_ENABLED, false)
        supervisionAutomationEnabled = prefs.getBoolean(KEY_SUPERVISION_AUTOMATION_ENABLED, false)
        outAutomationEnabled = prefs.getBoolean(KEY_OUT_AUTOMATION_ENABLED, false)
        inspectModeEnabled = prefs.getBoolean(KEY_INSPECT_MODE_ENABLED, false)
        // Each child switch is a real persisted setting. Never force a child
        // automation back to ON when the activity is recreated.
        passwordAutomationEnabled = prefs.getBoolean(KEY_PASSWORD_AUTOMATION_ENABLED, false)
        passwordAutomationCurrent = prefs.getString(KEY_PASSWORD_CURRENT, "") ?: ""
        passwordAutomationNew = prefs.getString(KEY_PASSWORD_NEW, "") ?: ""
        recoveryEmailAutomationEnabled = prefs.getBoolean(KEY_RECOVERY_EMAIL_AUTOMATION_ENABLED, false)
        authenticatorAutomationEnabled = prefs.getBoolean(KEY_AUTHENTICATOR_AUTOMATION_ENABLED, false)
        twoStepAutomationEnabled = prefs.getBoolean(KEY_TWO_STEP_AUTOMATION_ENABLED, false)
        authenticatorSecret = prefs.getString(KEY_TOTP_SECRET, "") ?: ""
        authenticatorLabel = prefs.getString(KEY_TOTP_LABEL, "") ?: ""
        authenticatorAlgorithm = prefs.getString(KEY_TOTP_ALGORITHM, "SHA1") ?: "SHA1"
        authenticatorDigits = prefs.getInt(KEY_TOTP_DIGITS, 6).coerceIn(6, 8)
        authenticatorPeriod = prefs.getLong(KEY_TOTP_PERIOD, 30L).coerceIn(15L, 120L)
        authenticatorOtpauthUri = prefs.getString("totp_uri", "") ?: ""

        AppCompatDelegate.setDefaultNightMode(
            if (darkModeEnabled) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )

        buildInterface()
        if (!restoreTabsState()) {
            addTab(homeUrl())
        }

        var lastBackPressedAt = 0L
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Close the side menu first if it is open.
                if (::drawerLayout.isInitialized && drawerLayout.isDrawerOpen(Gravity.START)) {
                    drawerLayout.closeDrawer(Gravity.START)
                    lastBackPressedAt = 0L
                    return
                }

                // Keep normal browser navigation working.
                val webView = currentWebView()
                if (webView?.canGoBack() == true) {
                    webView.goBack()
                    lastBackPressedAt = 0L
                    return
                }

                val now = System.currentTimeMillis()
                if (now - lastBackPressedAt <= 2000L) {
                    lastBackPressedAt = 0L
                    finish()
                } else {
                    lastBackPressedAt = now
                    Snackbar.make(
                        drawerLayout,
                        "دوس رجوع مرة أخرى للخروج",
                        1200
                    ).apply {
                        setDuration(1200)
                    }.show()
                }
            }
        })
    }

    private fun buildInterface() {
        // Keep the Android status/navigation areas visible instead of drawing the browser UI over them.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = resolveColor(com.google.android.material.R.attr.colorSurface)
        window.navigationBarColor = resolveColor(com.google.android.material.R.attr.colorSurface)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !darkModeEnabled
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !darkModeEnabled

        drawerLayout = DrawerLayout(this).apply {
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        // Android 15 can enforce edge-to-edge for targetSdk 35. Explicitly reserve the system-bar space.
        // Keep browser content below the Android status bar and, importantly,
        // reserve the full navigation-bar area at the bottom. Some Android
        // devices use an overlay/gesture navigation bar, so relying only on
        // WebView scrolling can leave website footer links (Privacy, Terms,
        // Language, etc.) underneath the phone's navigation controls.
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, bars.top, 0, 0)
            if (::systemBottomSpacer.isInitialized) {
                systemBottomSpacer.layoutParams = systemBottomSpacer.layoutParams.apply {
                    height = bars.bottom
                }
                systemBottomSpacer.requestLayout()
            }
            insets
        }

        chromeBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(4), dp(5), dp(4), dp(5))
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
            elevation = dp(2).toFloat()
        }

        fun chromeButton(label: String, size: Float = 24f): TextView = TextView(this).apply {
            text = label
            textSize = size
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            isClickable = true
            isFocusable = true
            background = null
        }

        val menuButton = chromeButton("⋮", 30f).apply {
            contentDescription = "القائمة"
            setOnClickListener { drawerLayout.openDrawer(Gravity.END) }
        }
        chromeBar.addView(menuButton, LinearLayout.LayoutParams(dp(44), dp(48)))

        tabCountView = chromeButton("1", 12f).apply {
            contentDescription = "علامات التبويب"
            setPadding(dp(5), dp(3), dp(5), dp(3))
            background = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.bg_tab_count)
            setOnClickListener { showTabSwitcher() }
        }
        chromeBar.addView(tabCountView, LinearLayout.LayoutParams(dp(22), dp(24)).apply { gravity = Gravity.CENTER_VERTICAL })

        val addButton = chromeButton("+", 30f).apply {
            contentDescription = "تبويب جديد"
            setOnClickListener { addTab(homeUrl()) }
        }
        chromeBar.addView(addButton, LinearLayout.LayoutParams(dp(44), dp(48)))

        addressBar = android.widget.EditText(this).apply {
            textSize = 16f
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setHintTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            hint = "بحث أو إدخال عنوان"
            setPadding(dp(14), 0, dp(14), 0)
            background = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.bg_address_bar)
            isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setOnEditorActionListener { v, _, _ ->
                loadAddress(v.text?.toString().orEmpty())
                true
            }
        }
        chromeBar.addView(addressBar, LinearLayout.LayoutParams(0, dp(40), 1f).apply {
            gravity = Gravity.CENTER_VERTICAL
            marginStart = dp(7)
            marginEnd = dp(7)
        })

        val homeButton = chromeButton("⌂", 28f).apply {
            contentDescription = "الصفحة الرئيسية"
            setOnClickListener { currentWebView()?.loadUrl(homeUrl()) }
        }
        chromeBar.addView(homeButton, LinearLayout.LayoutParams(dp(48), dp(48)))

        // Standard browser-style page loading indicator: a thin, natural blue line
        // directly below the tab/address bar. It does not consume the status-bar area.
        pageProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            isIndeterminate = false
            visibility = View.GONE
            progressDrawable = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.progress_page)
            setPadding(0, 0, 0, 0)
        }

        contentFrame = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // A dedicated inset spacer guarantees that the bottom of every WebView
        // stays above the phone's system navigation/gesture area.
        systemBottomSpacer = View(this).apply {
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        rootLayout.addView(chromeBar, LinearLayout.LayoutParams(-1, dp(58)))
        rootLayout.addView(pageProgress, LinearLayout.LayoutParams(-1, dp(3)))
        rootLayout.addView(contentFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        rootLayout.addView(systemBottomSpacer, LinearLayout.LayoutParams(-1, 0))

        drawerLayout.addView(rootLayout, DrawerLayout.LayoutParams(-1, -1))
        buildSideMenu()
        drawerLayout.addView(sideMenu, DrawerLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.END
            topMargin = dp(12)
            bottomMargin = dp(12)
        })
        ViewCompat.setOnApplyWindowInsetsListener(drawerLayout) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val lp = sideMenu.layoutParams as DrawerLayout.LayoutParams
            lp.topMargin = bars.top + dp(12)
            lp.bottomMargin = bars.bottom + dp(12)
            sideMenu.layoutParams = lp
            insets
        }

        // Keep the DrawerLayout's normal touch routing. A child view must receive
        // its own clicks/switch gestures, while the scrim outside the drawer
        // consumes the touch and closes the drawer instead of letting it reach
        // the WebView underneath. Do NOT put an OnTouchListener on sideMenu: a
        // consuming parent listener prevents Switches/Buttons inside it from
        // receiving their normal touch events.
        sideMenu.isClickable = true
        sideMenu.isFocusable = true
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, Gravity.END)

        setContentView(drawerLayout)
    }

    private fun buildSideMenu() {
        sideMenu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Menu content is English, so keep the menu itself LTR.
            // The DrawerLayout position remains unchanged.
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(0, dp(16), 0, dp(10))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(28).toFloat()
                setColor(resolveColor(com.google.android.material.R.attr.colorSurface))
            }
            elevation = dp(8).toFloat()
            clipToOutline = true
            isClickable = true
            isFocusable = true
        }

        val title = TextView(this).apply {
            text = "eM gmail"
            textSize = 20f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(dp(28), dp(6), dp(28), dp(12))
        }
        sideMenu.addView(title)

        fun menuItem(label: CharSequence, onClick: () -> Unit): TextView = TextView(this).apply {
            text = label
            textSize = 15.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(dp(28), 0, dp(28), 0)
            // No pressed/selected highlight color: keep the app monochrome.
            background = null
            setOnClickListener { onClick() }
        }

        sideMenu.addView(menuItem("Incognito") { setIncognitoMode(!incognitoEnabled); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Dark Mode") { setDarkMode(!darkModeEnabled); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Text Size") { drawerLayout.closeDrawer(Gravity.END); showZoomDialog() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        timeZoneMenuItem = menuItem(timeZoneMenuLabel()) { drawerLayout.closeDrawer(Gravity.END); showTimeZoneDialog() }
        sideMenu.addView(timeZoneMenuItem, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        languageMenuItem = menuItem("Language") { drawerLayout.closeDrawer(Gravity.END); showLanguageDialog() }
        sideMenu.addView(languageMenuItem, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("2FA Link") { drawerLayout.closeDrawer(Gravity.END); showTwoFaLinkDialog() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        addAutomationMasterMenuItem()
        sideMenu.addView(menuItem("Clear Browsing Data") { drawerLayout.closeDrawer(Gravity.END); showClearAllDataDialog() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
    }

    /**
     * Compact automation toggle matching the supplied reference: a clean pill
     * track, white circular thumb, green ON state and gray OFF state. The
     * thumb intentionally sits on the left when ON and on the right when OFF,
     * matching the reference image.
     */
    private fun createAutomationToggle(initialChecked: Boolean, onChanged: (Boolean) -> Unit): FrameLayout {
        val trackWidth = dp(46)
        val trackHeight = dp(28)
        val thumbSize = dp(20)
        val horizontalInset = dp(4)
        val onColor = Color.rgb(20, 198, 100) // #14C664 from the supplied reference
        val offColor = Color.rgb(204, 204, 204) // #CCCCCC from the supplied reference

        var checked = initialChecked
        val container = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(trackWidth, trackHeight)
            isClickable = true
            isFocusable = true
            contentDescription = if (checked) "ON" else "OFF"
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }

        val track = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = trackHeight / 2f
            }
        }
        container.addView(track, FrameLayout.LayoutParams(trackWidth, trackHeight))

        val thumb = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
            }
            elevation = dp(1).toFloat()
        }
        val thumbParams = FrameLayout.LayoutParams(thumbSize, thumbSize).apply {
            topMargin = (trackHeight - thumbSize) / 2
            leftMargin = horizontalInset
        }
        container.addView(thumb, thumbParams)

        fun render(animated: Boolean) {
            track.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = trackHeight / 2f
                setColor(if (checked) onColor else offColor)
            }
            val targetX = if (checked) 0 else trackWidth - (horizontalInset * 2) - thumbSize
            if (animated) {
                thumb.animate().translationX(targetX.toFloat()).setDuration(120L).start()
            } else {
                thumb.translationX = targetX.toFloat()
            }
            container.contentDescription = if (checked) "ON" else "OFF"
        }

        render(false)
        container.setOnClickListener {
            checked = !checked
            render(true)
            onChanged(checked)
        }
        return container
    }

    private fun addAutomationMasterMenuItem() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val settingsLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            // Child automation labels use the exact same left inset as the
            // main drawer items, so English starts at one clean vertical edge.
            setPadding(0, 0, 0, 0)
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), 0, dp(16), 0)
        }

        val label = TextView(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            text = "Auto"
            textSize = 15.5f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, 0, dp(12), 0)
            setOnClickListener {
                // Auto is both the master execution control and the parent
                // of the three automation settings. Tapping the label only
                // expands/collapses the settings; it never changes Auto.
                settingsLayout.visibility =
                    if (settingsLayout.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        }

        val switch = createAutomationToggle(automationMasterEnabled) { checked ->
            automationMasterEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_AUTOMATION_MASTER_ENABLED, checked).apply()
            if (checked) {
                // Password/Recovery/Authenticator are independent settings.
                // Auto is the only switch allowed to start execution.
                automationCompletedForCurrentAccount = false
                automationHasRunInCurrentGoogleSession = false
                val currentUrl = currentWebView()?.url.orEmpty()
                if (currentUrl.contains("google.com")) {
                    startConfiguredAutomationForCurrentAccount()
                }
            } else {
                supervisionAutomationActive = false
                supervisionAutomationStage = "idle"
                supervisionAutomationClickIssued = false
                outAutomationActive = false
                outAutomationStage = "idle"
                outAutomationClickIssued = false
                passwordAutomationActive = false
                passwordChangeSubmitted = false
                passwordReauthSubmitted = false
                passwordFlowStartedForCurrentAutomation = false
                recoveryEmailAutomationActive = false
                combinedAutomationWaitingForPassword = false
                googleVerificationActive = false
                googleVerificationSubmitIssued = false
                googleVerificationNoticeShown = false
                googleVerificationCheckPending = false
                stopAuthenticatorAutomation()
                stopTwoStepAutomation()
            }
        }

        row.addView(label, LinearLayout.LayoutParams(0, dp(46), 1f))
        row.addView(switch, LinearLayout.LayoutParams(dp(46), dp(28)))
        container.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))

        fun addSettingRow(title: String, enabled: Boolean, onSettingClick: () -> Unit, onChanged: (Boolean) -> Unit) {
            val settingRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                gravity = Gravity.CENTER_VERTICAL
                // Match every other drawer label: English starts at the same
                // left edge instead of being pushed inward by an extra indent.
                setPadding(dp(28), 0, dp(16), 0)
            }
            val settingLabel = TextView(this).apply {
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                text = title
                textSize = 14.5f
                gravity = Gravity.CENTER_VERTICAL
                setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
                setOnClickListener { onSettingClick() }
            }
            val settingSwitch = createAutomationToggle(enabled, onChanged)
            settingRow.addView(settingLabel, LinearLayout.LayoutParams(0, dp(40), 1f))
            settingRow.addView(settingSwitch, LinearLayout.LayoutParams(dp(46), dp(28)))
            settingsLayout.addView(settingRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
        }

        fun restartConfiguredAutomationIfMasterIsAlreadyOn() {
            if (!automationMasterEnabled) return
            val currentUrl = currentWebView()?.url.orEmpty()
            if (!currentUrl.contains("google.com")) return
            if (supervisionAutomationActive || outAutomationActive || passwordAutomationActive || recoveryEmailAutomationActive || authenticatorAutomationActive || twoStepAutomationActive) return
            automationCompletedForCurrentAccount = false
            automationHasRunInCurrentGoogleSession = false
            completedAccountKey = ""
            currentWebView()?.let { view ->
                view.postDelayed({
                    if (automationMasterEnabled && !supervisionAutomationActive && !outAutomationActive && !passwordAutomationActive &&
                        !recoveryEmailAutomationActive && !authenticatorAutomationActive && !twoStepAutomationActive) {
                        startConfiguredAutomationForCurrentAccount()
                    }
                }, 100L)
            }
        }

        addSettingRow("Supervision", supervisionAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END) }) { checked ->
            supervisionAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_SUPERVISION_AUTOMATION_ENABLED, checked).apply()
            if (!checked) {
                val wasActive = supervisionAutomationActive
                supervisionAutomationActive = false
                supervisionAutomationStage = "idle"
                supervisionAutomationClickIssued = false
                if (wasActive && automationMasterEnabled) continueAfterDisabledStage()
            } else {
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        // Out: leave the current Google Family group using the current WebView session.
        addSettingRow("Out", outAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END) }) { checked ->
            outAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_OUT_AUTOMATION_ENABLED, checked).apply()
            if (!checked) {
                val wasActive = outAutomationActive
                outAutomationActive = false
                outAutomationStage = "idle"
                outAutomationClickIssued = false
                if (wasActive && automationMasterEnabled) continueAfterDisabledStage()
            } else {
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        addSettingRow("Inspect", inspectModeEnabled,
            { drawerLayout.closeDrawer(Gravity.END) }) { checked ->
            inspectModeEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_INSPECT_MODE_ENABLED, checked).apply()
            currentWebView()?.let { view ->
                if (checked) {
                    installInspectMode(view)
                } else {
                    removeInspectMode(view)
                }
            }
        }

        addSettingRow("Password", passwordAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END); showPasswordChangeDialog() }) { checked ->
            passwordAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_PASSWORD_AUTOMATION_ENABLED, checked).apply()
            if (!checked) {
                val wasActive = passwordAutomationActive || passwordFlowStartedForCurrentAutomation
                clearPasswordAutomationState()
                passwordFlowStartedForCurrentAutomation = false
                if (wasActive && automationMasterEnabled) {
                    continueAfterDisabledStage()
                } else if (!automationMasterEnabled) {
                    passwordChangeSubmitted = false
                }
            } else {
                // If Auto is already ON, changing this setting must take effect
                // immediately; the user must never have to toggle Auto twice.
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        addSettingRow("Recovery", recoveryEmailAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END); showRecoveryEmailInfoDialog() }) { checked ->
            recoveryEmailAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RECOVERY_EMAIL_AUTOMATION_ENABLED, checked).apply()
            if (!checked) {
                val wasActive = recoveryEmailAutomationActive || recoveryRemovalAwaitingVerification
                recoveryEmailAutomationActive = false
                recoveryRemovalAwaitingVerification = false
                if (wasActive && automationMasterEnabled) {
                    continueAfterDisabledStage()
                }
            } else {
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        addSettingRow("Authenticator", authenticatorAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END); showAuthenticatorDialog() }) { checked ->
            authenticatorAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_AUTHENTICATOR_AUTOMATION_ENABLED, checked).apply()
            if (!checked) {
                val wasActive = authenticatorAutomationActive
                stopAuthenticatorAutomation()
                if (wasActive && automationMasterEnabled) {
                    continueAfterDisabledStage()
                }
            } else {
                // Same rule for Authenticator: if Auto is already enabled, the
                // new setting starts the configured stage without any off/on trick.
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        addSettingRow("2-Step", twoStepAutomationEnabled,
            { drawerLayout.closeDrawer(Gravity.END) }) { checked ->
            twoStepAutomationEnabled = checked
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_TWO_STEP_AUTOMATION_ENABLED, checked).apply()
            if (!checked) {
                val wasActive = twoStepAutomationActive
                stopTwoStepAutomation()
                if (wasActive && automationMasterEnabled) {
                    continueAfterDisabledStage()
                }
            } else {
                // This is the fourth child setting. It is controlled by Auto like
                // the other three; enabling it alone never starts automation while
                // Auto is OFF. If Auto is already ON, start the selected pipeline.
                restartConfiguredAutomationIfMasterIsAlreadyOn()
            }
        }

        container.addView(settingsLayout, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        sideMenu.addView(container, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun addPasswordChangeMenuItem() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), 0, dp(16), 0)
        }

        val label = TextView(this).apply {
            text = "Password"
            textSize = 15.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, 0, dp(12), 0)
            setOnClickListener {
                drawerLayout.closeDrawer(Gravity.END)
                showPasswordChangeDialog()
            }
        }

        val switch = MaterialSwitch(this).apply {
            isChecked = passwordAutomationEnabled
            text = ""
            showText = false
            // Compact switch: no On/Off text, blue when enabled, neutral when disabled.
            minWidth = dp(32)
            minimumWidth = dp(32)
            minimumHeight = dp(24)
            scaleX = 0.62f
            scaleY = 0.62f
            val primaryBlue = resolveColor(com.google.android.material.R.attr.colorPrimary)
            val surfaceVariant = resolveColor(com.google.android.material.R.attr.colorSurfaceVariant)
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(primaryBlue, resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.argb(90, Color.red(primaryBlue), Color.green(primaryBlue), Color.blue(primaryBlue)), surfaceVariant)
            )
            setOnCheckedChangeListener { _, checked ->
                passwordAutomationEnabled = checked
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean(KEY_PASSWORD_AUTOMATION_ENABLED, checked)
                    .apply()
                if (!checked) {
                    clearPasswordAutomationState()
                    if (!automationMasterEnabled) passwordChangeSubmitted = false
                }
            }
        }

        row.addView(label, LinearLayout.LayoutParams(0, dp(46), 1f))
        row.addView(switch, LinearLayout.LayoutParams(dp(44), dp(30)))
        sideMenu.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
    }

    private fun addRecoveryEmailMenuItem() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), 0, dp(16), 0)
        }

        val label = TextView(this).apply {
            text = "Recovery"
            textSize = 15.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, 0, dp(12), 0)
            setOnClickListener {
                drawerLayout.closeDrawer(Gravity.END)
                showRecoveryEmailInfoDialog()
            }
        }

        val switch = MaterialSwitch(this).apply {
            isChecked = recoveryEmailAutomationEnabled
            text = ""
            showText = false
            // Compact switch: no On/Off text, blue when enabled, neutral when disabled.
            minWidth = dp(32)
            minimumWidth = dp(32)
            minimumHeight = dp(24)
            scaleX = 0.62f
            scaleY = 0.62f
            val primaryBlue = resolveColor(com.google.android.material.R.attr.colorPrimary)
            val surfaceVariant = resolveColor(com.google.android.material.R.attr.colorSurfaceVariant)
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(primaryBlue, resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.argb(90, Color.red(primaryBlue), Color.green(primaryBlue), Color.blue(primaryBlue)), surfaceVariant)
            )
            setOnCheckedChangeListener { _, checked ->
                recoveryEmailAutomationEnabled = checked
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean(KEY_RECOVERY_EMAIL_AUTOMATION_ENABLED, checked)
                    .apply()
                if (!checked) {
                    recoveryEmailAutomationActive = false
                    recoveryRemovalAwaitingVerification = false
                }
            }
        }

        row.addView(label, LinearLayout.LayoutParams(0, dp(46), 1f))
        row.addView(switch, LinearLayout.LayoutParams(dp(44), dp(30)))
        sideMenu.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
    }

    private fun addAuthenticatorAutomationMenuItem() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), 0, dp(16), 0)
        }
        val label = TextView(this).apply {
            text = "Authenticator"
            textSize = 15.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, 0, dp(12), 0)
            setOnClickListener {
                drawerLayout.closeDrawer(Gravity.END)
                showAuthenticatorDialog()
            }
        }
        val switch = MaterialSwitch(this).apply {
            isChecked = authenticatorAutomationEnabled
            text = ""
            showText = false
            minWidth = dp(32)
            minimumWidth = dp(32)
            minimumHeight = dp(24)
            scaleX = 0.62f
            scaleY = 0.62f
            val primaryBlue = resolveColor(com.google.android.material.R.attr.colorPrimary)
            val surfaceVariant = resolveColor(com.google.android.material.R.attr.colorSurfaceVariant)
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(primaryBlue, resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.argb(90, Color.red(primaryBlue), Color.green(primaryBlue), Color.blue(primaryBlue)), surfaceVariant)
            )
            setOnCheckedChangeListener { _, checked ->
                authenticatorAutomationEnabled = checked
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean(KEY_AUTHENTICATOR_AUTOMATION_ENABLED, checked)
                    .apply()
                if (!checked) {
                    stopAuthenticatorAutomation()
                }
            }
        }
        row.addView(label, LinearLayout.LayoutParams(0, dp(46), 1f))
        row.addView(switch, LinearLayout.LayoutParams(dp(44), dp(30)))
        sideMenu.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
    }

    private fun showAuthenticatorDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val status = TextView(this).apply {
            textSize = 14f
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
        }
        val code = TextView(this).apply {
            textSize = 34f
            typeface = android.graphics.Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
        }
        val countdown = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
        }
        val copyCode = Button(this).apply {
            text = "نسخ الرمز"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, dp(8), 0, dp(8))
            setOnClickListener {
                val value = code.text?.toString().orEmpty()
                if (value.matches(Regex("\\d{6,8}"))) {
                    copyToClipboard("Authenticator code", value)
                    Snackbar.make(drawerLayout, "تم نسخ رمز المصادقة", Snackbar.LENGTH_SHORT).show()
                }
            }
        }
        val copyLink = Button(this).apply {
            text = "نسخ مفتاح المصادقة"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, dp(4), 0, dp(8))
            setOnClickListener {
                val key = formatAuthenticatorKey(authenticatorSecret)
                if (key.isNotBlank()) {
                    copyToClipboard("Authenticator key", key)
                    Snackbar.make(drawerLayout, "تم نسخ مفتاح المصادقة", Snackbar.LENGTH_SHORT).show()
                }
            }
        }
        val savedListButton = Button(this).apply {
            text = "الحسابات المحفوظة"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(0, dp(8), 0, dp(8))
            setOnClickListener { showSavedAuthenticatorAccountsDialog() }
        }
        container.addView(status)
        container.addView(code)
        container.addView(countdown)
        container.addView(copyCode)
        container.addView(copyLink)
        container.addView(savedListButton)

        fun refreshToken() {
            if (authenticatorSecret.isBlank()) {
                status.text = "لا يوجد حساب مصادقة محفوظ."
                code.text = "------"
                countdown.text = ""
                return
            }
            runCatching {
                val value = generateTotp(authenticatorSecret, System.currentTimeMillis(), authenticatorAlgorithm, authenticatorDigits, authenticatorPeriod)
                code.text = value
                status.text = if (authenticatorLabel.isBlank()) "Authenticator code" else authenticatorLabel
                val remaining = authenticatorPeriod - ((System.currentTimeMillis() / 1000L) % authenticatorPeriod)
                countdown.text = "يتجدد خلال ${remaining} ثانية"
            }.onFailure {
                code.text = "ERROR"
                status.text = "تعذر توليد رمز المصادقة"
                countdown.text = ""
            }
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Authenticator")
            .setView(container)
            .setPositiveButton("Scan QR from current page") { _, _ ->
                val qrView = currentWebView()
                if (qrView == null) {
                    Snackbar.make(drawerLayout, "لا يوجد تبويب مفتوح", Snackbar.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                scanQrFromCurrentPage(qrView) { raw ->
                    if (raw != null) {
                        val parsed = parseOtpAuth(raw)
                        if (parsed != null) {
                            saveAuthenticator(parsed)
                            showAuthenticatorDialog()
                        } else {
                            AlertDialog.Builder(this).setTitle("Authenticator").setMessage("The QR code was read, but it is not a valid otpauth:// TOTP link.").setPositiveButton("OK", null).show()
                        }
                    } else {
                        AlertDialog.Builder(this).setTitle("Authenticator").setMessage("No readable QR code was found on the current page.").setPositiveButton("OK", null).show()
                    }
                }
            }
            .setNeutralButton("Clear") { _, _ -> clearAuthenticator() }
            .create()

        authenticatorTimer?.cancel()
        authenticatorTimer = object : android.os.CountDownTimer(24L * 60L * 60L * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) { refreshToken() }
            override fun onFinish() { }
        }.start()
        dialog.setOnDismissListener { authenticatorTimer?.cancel(); authenticatorTimer = null }
        dialog.show()
        refreshToken()
    }

    private data class TotpConfig(
        val secret: String,
        val label: String,
        val issuer: String,
        val algorithm: String,
        val digits: Int,
        val period: Long,
        val uri: String
    )

    private fun parseOtpAuth(raw: String): TotpConfig? {
        val uri = raw.trim().let { if (it.startsWith("otpauth://", true)) it else return null }
        val parsed = android.net.Uri.parse(uri)
        if (!parsed.scheme.equals("otpauth", true) || !parsed.host.equals("totp", true)) return null
        val secret = parsed.getQueryParameter("secret")?.replace(" ", "")?.uppercase(Locale.US) ?: return null
        if (secret.length < 8) return null
        val label = parsed.path.orEmpty().removePrefix("/").let { java.net.URLDecoder.decode(it, "UTF-8") }
        val issuer = parsed.getQueryParameter("issuer").orEmpty()
        val algorithm = parsed.getQueryParameter("algorithm")?.uppercase(Locale.US)?.takeIf { it in setOf("SHA1", "SHA256", "SHA512") } ?: "SHA1"
        val digits = parsed.getQueryParameter("digits")?.toIntOrNull()?.takeIf { it == 6 || it == 8 } ?: 6
        val period = parsed.getQueryParameter("period")?.toLongOrNull()?.takeIf { it in 15L..120L } ?: 30L
        return TotpConfig(secret, label, issuer, algorithm, digits, period, uri)
    }

    private fun applyAuthenticatorRuntimeConfig(config: TotpConfig) {
        authenticatorSecret = config.secret
        authenticatorLabel = if (config.issuer.isBlank()) config.label else "${config.issuer}: ${config.label}"
        authenticatorAlgorithm = config.algorithm
        authenticatorDigits = config.digits
        authenticatorPeriod = config.period
        authenticatorOtpauthUri = config.uri
    }

    private fun saveAuthenticator(config: TotpConfig) {
        applyAuthenticatorRuntimeConfig(config)

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_TOTP_SECRET, authenticatorSecret)
            .putString(KEY_TOTP_LABEL, authenticatorLabel)
            .putString(KEY_TOTP_ALGORITHM, authenticatorAlgorithm)
            .putInt(KEY_TOTP_DIGITS, authenticatorDigits)
            .putLong(KEY_TOTP_PERIOD, authenticatorPeriod)
            .putString("totp_uri", authenticatorOtpauthUri)
            .apply()

        // Prefer the Google account currently open in the WebView. The QR label can
        // contain an issuer/name instead of the actual Gmail, so using currentAccountKey
        // keeps the saved log explicitly mapped to the account being configured.
        val account = accountKeyByWebView[currentWebView()]?.takeIf { it.isNotBlank() }
            ?: currentAccountKey.ifBlank {
                extractEmailFromText(config.label).ifBlank {
                    extractEmailFromText(config.issuer)
                }
            }
        val array = loadAuthenticatorAccounts()
        val obj = JSONObject().apply {
            put("account", account)
            put("label", if (config.issuer.isBlank()) config.label else "${config.issuer}: ${config.label}")
            put("uri", config.uri)
            put("secret", config.secret)
            put("algorithm", config.algorithm)
            put("digits", config.digits)
            put("period", config.period)
            put("savedAt", System.currentTimeMillis())
        }
        val key = config.uri
        var replaced = false
        for (i in 0 until array.length()) {
            val existing = array.optJSONObject(i) ?: continue
            if (existing.optString("uri") == key || (account.isNotBlank() && existing.optString("account") == account)) {
                array.put(i, obj)
                replaced = true
                break
            }
        }
        if (!replaced) array.put(obj)
        saveAuthenticatorAccounts(array)
        saveAuthenticatorLogFile(array)
    }

    /**
     * Keeps a real local log file in the app's private files directory in addition
     * to the in-app JSON list. Each row is: Gmail, Base32 authenticator key, saved timestamp.
     * The otpauth link contains the TOTP secret, so this file is intentionally kept
     * private to the app rather than uploaded anywhere.
     */
    private fun saveAuthenticatorLogFile(array: JSONArray = loadAuthenticatorAccounts()) {
        runCatching {
            val file = File(filesDir, "authenticator_accounts.csv")
            val out = StringBuilder()
            out.append("Gmail,Authenticator Key,Saved At\n")
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val account = item.optString("account")
                val uri = item.optString("uri")
                val secret = item.optString("secret").ifBlank { parseOtpAuth(uri)?.secret.orEmpty() }
                val key = formatAuthenticatorKey(secret)
                val savedAt = item.optLong("savedAt", 0L)
                out.append(csvField(account)).append(',')
                    .append(csvField(key)).append(',')
                    .append(csvField(if (savedAt > 0L) java.text.DateFormat.getDateTimeInstance().format(java.util.Date(savedAt)) else ""))
                    .append('\n')
            }
            file.writeText(out.toString(), Charsets.UTF_8)
        }
    }

    private fun csvField(value: String): String =
        "\"" + value.replace("\"", "\"\"") + "\""

    private fun clearAuthenticator() {
        authenticatorTimer?.cancel()
        authenticatorTimer = null
        authenticatorSecret = ""
        authenticatorLabel = ""
        authenticatorOtpauthUri = ""
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .remove(KEY_TOTP_SECRET).remove(KEY_TOTP_LABEL).remove(KEY_TOTP_ALGORITHM)
            .remove(KEY_TOTP_DIGITS).remove(KEY_TOTP_PERIOD).remove("totp_uri").apply()
    }

    private fun showTwoFaLinkDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }

        val input = EditText(this).apply {
            hint = "Enter 2FA key"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setHintTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
        }

        val code = TextView(this).apply {
            text = "------"
            textSize = 34f
            typeface = android.graphics.Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(2))
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
        }

        val timerText = TextView(this).apply {
            text = ""
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
        }

        val copyCode = Button(this).apply {
            text = "Copy Code"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setOnClickListener {
                val value = code.text?.toString().orEmpty()
                if (value.matches(Regex("\\d{6,8}"))) {
                    copyToClipboard("2FA code", value)
                    Snackbar.make(drawerLayout, "Code copied", Snackbar.LENGTH_SHORT).show()
                }
            }
        }

        // The code is generated automatically as soon as a valid 2FA key is pasted/typed.
        // No separate Generate button is used. The countdown is aligned to the TOTP period
        // so the displayed code and remaining seconds stay synchronized.
        var activeConfig: TotpConfig? = null
        var refreshTimer: android.os.CountDownTimer? = null

        fun renderCode(config: TotpConfig) {
            activeConfig = config
            refreshTimer?.cancel()
            val now = System.currentTimeMillis()
            runCatching {
                generateTotp(config.secret, now, config.algorithm, config.digits, config.period)
            }.onSuccess { value ->
                code.text = value
                val periodMillis = config.period * 1000L
                val elapsed = now % periodMillis
                val remaining = (periodMillis - elapsed).coerceAtLeast(1000L)
                refreshTimer = object : android.os.CountDownTimer(remaining, 1000L) {
                    override fun onTick(millisUntilFinished: Long) {
                        val seconds = ((millisUntilFinished + 999L) / 1000L).toInt()
                        timerText.text = "${seconds}s"
                    }

                    override fun onFinish() {
                        activeConfig?.let { renderCode(it) }
                    }
                }.start()
            }.onFailure {
                code.text = "ERROR"
                timerText.text = ""
            }
        }

        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val raw = s?.toString().orEmpty().trim()
                if (raw.isBlank()) {
                    activeConfig = null
                    refreshTimer?.cancel()
                    code.text = "------"
                    timerText.text = ""
                    return
                }

                val config = parseOtpAuth(raw) ?: run {
                    val secret = raw
                        .replace(Regex("[^A-Za-z2-7]"), "")
                        .uppercase(Locale.US)
                    if (secret.length >= 8 && secret.all { it in "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567" }) {
                        TotpConfig(secret, "2FA", "", "SHA1", 6, 30L, "")
                    } else null
                }

                if (config != null) {
                    renderCode(config)
                } else {
                    activeConfig = null
                    refreshTimer?.cancel()
                    code.text = "------"
                    timerText.text = ""
                }
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        container.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        container.addView(code, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62)))
        container.addView(timerText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)))
        container.addView(copyCode, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val dialog = AlertDialog.Builder(this)
            .setTitle("2FA Link")
            .setView(container)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.setOnDismissListener {
            refreshTimer?.cancel()
            refreshTimer = null
            activeConfig = null
        }
        dialog.show()
    }

    private fun showOtpAuthInputDialog() {
        val input = EditText(this).apply {
            hint = "otpauth://totp/..."
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Authenticator link")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val parsed = parseOtpAuth(input.text.toString())
                if (parsed == null) {
                    AlertDialog.Builder(this).setMessage("Invalid otpauth:// TOTP link.").setPositiveButton("OK", null).show()
                } else {
                    saveAuthenticator(parsed)
                    showAuthenticatorDialog()
                }
            }.show()
    }

    private fun copyToClipboard(label: String, value: String) {
        val clipboard = getSystemService(android.content.ClipboardManager::class.java)
        clipboard?.setPrimaryClip(android.content.ClipData.newPlainText(label, value))
    }

    private fun extractEmailFromText(value: String): String {
        val match = Regex("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", RegexOption.IGNORE_CASE).find(value)
        return match?.value?.lowercase(Locale.US).orEmpty()
    }

    private fun loadAuthenticatorAccounts(): JSONArray {
        val raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TOTP_ACCOUNTS, "[]") ?: "[]"
        return runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
    }

    private fun saveAuthenticatorAccounts(array: JSONArray) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_TOTP_ACCOUNTS, array.toString())
            .apply()
    }

    /**
     * Displays only the Base32 secret extracted from the otpauth QR payload.
     * The otpauth:// scheme, totp path and query parameters are intentionally
     * hidden from the user. Groups are four characters wide to match the
     * human-readable setup key Google commonly displays.
     */
    private fun formatAuthenticatorKey(secret: String): String {
        val clean = secret.replace("\\s".toRegex(), "").uppercase(Locale.US)
        if (clean.isBlank()) return ""
        return clean.chunked(4).joinToString(" ")
    }

    private fun showSavedAuthenticatorAccountsDialog() {
        val accounts = loadAuthenticatorAccounts()
        if (accounts.length() == 0) {
            AlertDialog.Builder(this)
                .setTitle("الحسابات المحفوظة")
                .setMessage("لا توجد حسابات مصادقة محفوظة.")
                .setPositiveButton("موافق", null)
                .show()
            return
        }

        val scroll = android.widget.ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        for (i in 0 until accounts.length()) {
            val item = accounts.optJSONObject(i) ?: continue
            val account = item.optString("account").ifBlank { item.optString("label") }
            val uri = item.optString("uri")
            val config = parseOtpAuth(uri)
            val key = formatAuthenticatorKey(item.optString("secret").ifBlank { config?.secret.orEmpty() })
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            val title = TextView(this).apply {
                text = account
                textSize = 15.5f
                setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            }
            val link = TextView(this).apply {
                text = key
                textSize = 13f
                maxLines = 2
                setTextIsSelectable(true)
                setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            }
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val copyLink = Button(this).apply {
                text = "نسخ الحساب"
                setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
                setPadding(0, dp(8), dp(18), dp(8))
                setOnClickListener {
                    if (account.isNotBlank() || key.isNotBlank()) {
                        val accountRow = account + "\t" + key
                        copyToClipboard("Authenticator account", accountRow)
                        Snackbar.make(drawerLayout, "تم نسخ الحساب", Snackbar.LENGTH_SHORT).show()
                    }
                }
            }
            // The saved-account list intentionally keeps only the secret-key copy action.
            // TOTP codes are generated live and are not needed in the saved-account log.
            actions.addView(copyLink)
            row.addView(title)
            row.addView(link)
            row.addView(actions)
            list.addView(row, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
            if (i < accounts.length() - 1) {
                val divider = View(this).apply { setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorOutlineVariant)) }
                list.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
        scroll.addView(list)
        // Build one clipboard entry per account: Gmail + its authenticator key.
        // Keep the order exactly as displayed in the saved-account list.
        val allAccountsText = buildString {
            for (i in 0 until accounts.length()) {
                val item = accounts.optJSONObject(i) ?: continue
                val account = item.optString("account").ifBlank { item.optString("label") }
                val uri = item.optString("uri")
                val config = parseOtpAuth(uri)
                val key = formatAuthenticatorKey(item.optString("secret").ifBlank { config?.secret.orEmpty() })
                if (account.isNotBlank() || key.isNotBlank()) {
                    append(account).append("\t").append(key).append('\n')
                }
            }
        }.trimEnd()

        val footerActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val updateLogButton = Button(this).apply {
            text = "تحديث ملف السجل"
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setOnClickListener {
                saveAuthenticatorLogFile()
                Snackbar.make(drawerLayout, "تم تحديث ملف سجل المصادقات", Snackbar.LENGTH_SHORT).show()
            }
        }
        val copyAllButton = Button(this).apply {
            text = "نسخ جميع الحسابات"
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setOnClickListener {
                if (allAccountsText.isNotBlank()) {
                    copyToClipboard("Saved authenticator accounts", allAccountsText)
                    Snackbar.make(drawerLayout, "تم نسخ جميع الحسابات", Snackbar.LENGTH_SHORT).show()
                }
            }
        }
        footerActions.addView(updateLogButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        footerActions.addView(copyAllButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        list.addView(footerActions, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        AlertDialog.Builder(this)
            .setTitle("الحسابات المحفوظة")
            .setView(scroll)
            .setPositiveButton("موافق", null)
            .create().also { dialog ->
                dialog.show()
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                    ?.setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            }
    }

    private fun showRecoveryEmailInfoDialog() {
        AlertDialog.Builder(this)
            .setTitle("Recovery")
            .setMessage("اضغط On لإزالة بريد الاسترداد من حساب Google المفتوح حاليًا. إذا طلب Google تحققًا إضافيًا، أكمله يدويًا.")
            .setPositiveButton("موافق", null)
            .show()
    }

    private fun showPasswordChangeDialog() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val savedCurrent = prefs.getString(KEY_PASSWORD_CURRENT, passwordAutomationCurrent) ?: ""
        val savedNew = prefs.getString(KEY_PASSWORD_NEW, passwordAutomationNew) ?: ""

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), 0, dp(8), 0)
        }

        fun passwordField(hint: String, value: String): EditText = EditText(this).apply {
            this.hint = hint
            setText(value)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            isSingleLine = true
        }

        val current = passwordField("كلمة المرور الحالية", savedCurrent)
        val newPassword = passwordField("كلمة المرور الجديدة", savedNew)
        val confirm = passwordField("تأكيد كلمة المرور الجديدة", savedNew)
        container.addView(current, LinearLayout.LayoutParams(-1, dp(56)))
        container.addView(newPassword, LinearLayout.LayoutParams(-1, dp(56)))
        container.addView(confirm, LinearLayout.LayoutParams(-1, dp(56)))

        val dialog = AlertDialog.Builder(this)
            .setTitle("Password")
            .setView(container)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val oldPassword = current.text?.toString().orEmpty()
                val newValue = newPassword.text?.toString().orEmpty()
                val confirmation = confirm.text?.toString().orEmpty()

                if (oldPassword.isBlank() || newValue.isBlank() || confirmation.isBlank()) {
                    Snackbar.make(drawerLayout, "اكتب كلمات المرور الثلاثة أولًا", Snackbar.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (newValue != confirmation) {
                    Snackbar.make(drawerLayout, "كلمة المرور الجديدة والتأكيد غير متطابقين", Snackbar.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                passwordAutomationCurrent = oldPassword
                passwordAutomationNew = newValue
                prefs.edit()
                    .putString(KEY_PASSWORD_CURRENT, oldPassword)
                    .putString(KEY_PASSWORD_NEW, newValue)
                    .apply()

                dialog.dismiss()
                Snackbar.make(drawerLayout, "تم حفظ بيانات Password", Snackbar.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun startPasswordChange() {
        // A password flow may only be started once for the current cycle.
        // onPageFinished and recovery callbacks can arrive close together.
        if (passwordAutomationActive || passwordFlowStartedForCurrentAutomation) return
        if (passwordAutomationCurrent.isBlank() || passwordAutomationNew.isBlank()) {
            Snackbar.make(drawerLayout, "افتح Password واحفظ بيانات الباسورد أولًا", Snackbar.LENGTH_LONG).show()
            return
        }

        passwordAutomationActive = true
        passwordFlowStartedForCurrentAutomation = true
        passwordChangeSubmitted = false
        passwordReauthSubmitted = false
        recoveryEmailAutomationActive = false
        combinedAutomationWaitingForPassword = false
        val webView = currentWebView()
        if (webView == null) {
            passwordAutomationActive = false
            Snackbar.make(drawerLayout, "لا يوجد تبويب مفتوح", Snackbar.LENGTH_SHORT).show()
            return
        }

        // Clear only the previous password-flow lock before opening a fresh flow.
        // The lock itself is stored in sessionStorage by the page script so it
        // survives Google's navigation/reload between the submit and its result.
        webView.evaluateJavascript("try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); sessionStorage.removeItem('__emPasswordFlowReauth'); } catch(e) {}", null)
        webView.loadUrl("https://myaccount.google.com/signinoptions/password?hl=ar")
    }

    private fun startRecoveryEmailRemoval() {
        val webView = currentWebView()
        if (webView == null) {
            recoveryEmailAutomationActive = false
            Snackbar.make(drawerLayout, "لا يوجد تبويب مفتوح", Snackbar.LENGTH_SHORT).show()
            return
        }
        recoveryEmailAutomationActive = true
        recoveryRemovalAwaitingVerification = false
        recoveryDirectRetryCount = 0
        recoveryEmailPageOpened = false
        recoveryTrashClicked = false
        recoverySuccessNotificationSeen = false
        passwordAutomationActive = false
        combinedAutomationWaitingForPassword = passwordAutomationEnabled
        // Open Google's dedicated Recovery Email page directly. The rapt/continue
        // parameters are session-specific, so do not hard-code the user's temporary token;
        // Google will use the currently signed-in WebView session.
        webView.loadUrl(withSelectedLanguage(RECOVERY_EMAIL_URL))
    }

    /**
     * Continue the current Auto pipeline after a child automation switch is
     * turned OFF while that stage is active.  A disabled stage must never run
     * again, and disabling it must not require toggling Auto OFF/ON.
     */
    private fun continueAfterDisabledStage(view: WebView? = currentWebView()) {
        if (!automationMasterEnabled || automationCompletedForCurrentAccount) return
        val target = view ?: currentWebView() ?: return

        supervisionAutomationActive = false
        supervisionAutomationStage = "idle"
        supervisionAutomationClickIssued = false
        supervisionAgreeWasIssued = false
        supervisionPreAgreeUrl = ""
        supervisionPreAgreeBody = ""
        outAutomationActive = false
        outAutomationStage = "idle"
        outAutomationClickIssued = false
        passwordAutomationActive = false
        recoveryEmailAutomationActive = false
        recoveryRemovalAwaitingVerification = false
        combinedAutomationWaitingForPassword = false
        googleVerificationActive = false
        googleVerificationSubmitIssued = false
        googleVerificationNoticeShown = false
        googleVerificationCheckPending = false
        passwordChangeSubmitted = false
        passwordReauthSubmitted = false
        passwordFlowStartedForCurrentAutomation = false
        authenticatorAutomationActive = false
        authenticatorAutomationStage = "idle"
        twoStepAutomationActive = false
        twoStepAutomationStage = "idle"

        // Continue strictly in the configured order, considering ONLY switches
        // that are currently ON.  OFF means skip completely.
        // Password is intentionally the FINAL stage.
        when {
            recoveryEmailAutomationEnabled -> startRecoveryEmailRemoval()
            authenticatorAutomationEnabled -> startAuthenticatorAutomation(target)
            twoStepAutomationEnabled -> startTwoStepAutomation(target)
            passwordAutomationEnabled -> startPasswordChange()
            else -> {
                automationCompletedForCurrentAccount = true
                automationHasRunInCurrentGoogleSession = true
                completedAccountKey = currentAccountKey
            }
        }
    }

    private fun startConfiguredAutomationForCurrentAccount() {
        if (!automationMasterEnabled) return
        if (automationCompletedForCurrentAccount || automationHasRunInCurrentGoogleSession) return
        if (combinedAutomationWaitingForPassword || supervisionAutomationActive || outAutomationActive || passwordAutomationActive ||
            passwordFlowStartedForCurrentAutomation || recoveryEmailAutomationActive ||
            authenticatorAutomationActive || twoStepAutomationActive) return

        // The child switches are the actual stage permissions. Auto only starts
        // the selected stages; it must never implicitly enable Recovery/Password.
        // Fixed order among enabled stages: Supervision -> Out -> Recovery -> Authenticator -> 2-Step Verification -> Password.
        automationHasRunInCurrentGoogleSession = true
        val view = currentWebView() ?: run {
            automationHasRunInCurrentGoogleSession = false
            return
        }

        when {
            supervisionAutomationEnabled -> startSupervisionAutomation(view)
            outAutomationEnabled -> startOutAutomation(view)
            recoveryEmailAutomationEnabled -> startRecoveryEmailRemoval()
            authenticatorAutomationEnabled -> startAuthenticatorAutomation(view)
            twoStepAutomationEnabled -> startTwoStepAutomation(view)
            passwordAutomationEnabled -> startPasswordChange()
            else -> {
                // Nothing is selected: Auto has nothing to execute.
                automationCompletedForCurrentAccount = true
                completedAccountKey = currentAccountKey
            }
        }
    }

    // Single hand-off point for the Auto pipeline.  This method only connects
    // stages; it does not change the implementation of any stage itself.
    // Order is fixed: Supervision -> Out -> Recovery -> Authenticator -> 2-Step -> Password.
    // Any stage whose switch is OFF is skipped automatically.
    private fun startNextConfiguredStage(view: WebView, completedStage: String) {
        if (!automationMasterEnabled || automationCompletedForCurrentAccount) return

        val next = when (completedStage) {
            "supervision" -> when {
                outAutomationEnabled -> { startOutAutomation(view); true }
                recoveryEmailAutomationEnabled -> { startRecoveryEmailRemoval(); true }
                authenticatorAutomationEnabled -> { startAuthenticatorAutomation(view); true }
                twoStepAutomationEnabled -> { startTwoStepAutomation(view); true }
                passwordAutomationEnabled -> { startPasswordChange(); true }
                else -> false
            }
            "out" -> when {
                recoveryEmailAutomationEnabled -> { startRecoveryEmailRemoval(); true }
                authenticatorAutomationEnabled -> { startAuthenticatorAutomation(view); true }
                twoStepAutomationEnabled -> { startTwoStepAutomation(view); true }
                passwordAutomationEnabled -> { startPasswordChange(); true }
                else -> false
            }
            "recovery" -> when {
                authenticatorAutomationEnabled -> { startAuthenticatorAutomation(view); true }
                twoStepAutomationEnabled -> { startTwoStepAutomation(view); true }
                passwordAutomationEnabled -> { startPasswordChange(); true }
                else -> false
            }
            "authenticator" -> when {
                twoStepAutomationEnabled -> { startTwoStepAutomation(view); true }
                passwordAutomationEnabled -> { startPasswordChange(); true }
                else -> false
            }
            "two_step" -> when {
                passwordAutomationEnabled -> { startPasswordChange(); true }
                else -> false
            }
            else -> false
        }

        if (!next) {
            automationCompletedForCurrentAccount = true
            automationHasRunInCurrentGoogleSession = true
            completedAccountKey = currentAccountKey
        }
    }

    /**
     * Detect Google's "To continue, first verify it's you" interstitial that can
     * appear between Auto stages. It uses ONLY the Current Password already saved
     * in the Password automation settings. No new password is stored here.
     *
     * Returns asynchronously. While the verification page is active, stage
     * injectors are gated by googleVerificationActive. After Google navigates away
     * from the verification page, the currently active stage is resumed.
     */
    private fun injectGoogleVerification(view: WebView) {
        if (!automationMasterEnabled) return
        val current = JSONObject.quote(passwordAutomationCurrent)
        val script = """
            (function() {
              const currentPassword = $current;
              const visible = el => {
                if (!el) return false;
                const r = el.getBoundingClientRect();
                const s = getComputedStyle(el);
                return r.width > 1 && r.height > 1 && s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
              };
              const textOf = el => String(el?.innerText || el?.textContent || '').replace(/\s+/g,' ').trim();
              const bodyText = textOf(document.body);
              const verificationText = /to continue,? first verify it'?s you|first verify it'?s you|تحقق من هويتك|للتمكن من المتابعة.*تحقق/i.test(bodyText);
              const input = Array.from(document.querySelectorAll('input[type="password"], input[name="Passwd"]')).find(el =>
                visible(el) && ((el.getAttribute('aria-label') || '').toLowerCase().includes('enter your password') || el.name === 'Passwd')
              );
              if (!verificationText && !input) return 'none';
              if (!input) return 'waiting';
              if (!currentPassword) return 'missing_password';

              const setValue = (el, value) => {
                const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
                if (setter) setter.call(el, value); else el.value = value;
                el.dispatchEvent(new Event('input', {bubbles:true}));
                el.dispatchEvent(new Event('change', {bubbles:true}));
              };
              const buttonText = el => String(el?.innerText || el?.value || el?.getAttribute('aria-label') || '').trim().toLowerCase();
              const buttons = Array.from(document.querySelectorAll('button, input[type="submit"]')).filter(visible);
              const next = buttons.find(el => /^next$/i.test(buttonText(el))) ||
                           buttons.find(el => /^(next|continue|verify|التالي|متابعة|تأكيد)$/i.test(buttonText(el)));
              if (!next || next.disabled) return 'waiting';
              let submitLocked = false;
              try { submitLocked = sessionStorage.getItem('__emGoogleVerificationSubmitted') === '1'; } catch(e) {}
              if (submitLocked) return 'waiting';
              setValue(input, currentPassword);
              try { sessionStorage.setItem('__emGoogleVerificationSubmitted','1'); } catch(e) {}
              try { input.focus({preventScroll:true}); } catch(e) {}
              try { next.click(); return 'submitted'; } catch(e) {
                try {
                  for (const type of ['pointerdown','mousedown','pointerup','mouseup','click']) {
                    next.dispatchEvent(new MouseEvent(type,{bubbles:true,cancelable:true,view:window}));
                  }
                  return 'submitted';
                } catch(e2) { return 'waiting'; }
              }
            })();
        """.trimIndent()

        view.evaluateJavascript(script) { result ->
            googleVerificationCheckPending = false
            when (result?.trim('"')) {
                "submitted" -> {
                    googleVerificationActive = true
                    googleVerificationSubmitIssued = true
                    googleVerificationNoticeShown = false
                    view.postDelayed({
                        if (googleVerificationActive) injectGoogleVerification(view)
                    }, 1200L)
                }
                "waiting" -> {
                    googleVerificationActive = true
                    googleVerificationSubmitIssued = false
                    view.postDelayed({
                        if (googleVerificationActive) injectGoogleVerification(view)
                    }, 700L)
                }
                "missing_password" -> {
                    googleVerificationActive = true
                    if (!googleVerificationNoticeShown) {
                        googleVerificationNoticeShown = true
                        Snackbar.make(drawerLayout, "أدخل كلمة المرور الحالية في Password أولًا", Snackbar.LENGTH_LONG).show()
                    }
                }
                "none" -> {
                    googleVerificationActive = false
                    googleVerificationSubmitIssued = false
                    googleVerificationNoticeShown = false
                    view.evaluateJavascript("try { sessionStorage.removeItem('__emGoogleVerificationSubmitted'); } catch(e) {}", null)
                    // Resume only the automation stage that is actually active.
                    view.postDelayed({
                        when {
                            supervisionAutomationActive -> injectSupervisionAutomation(view)
                            outAutomationActive -> injectOutAutomation(view)
                            passwordAutomationActive -> injectPasswordChangeScript(view)
                            recoveryEmailAutomationActive -> injectRecoveryEmailRemovalScript(view)
                            authenticatorAutomationActive -> injectAuthenticatorAutomation(view)
                            twoStepAutomationActive -> injectTwoStepAutomation(view)
                        }
                    }, 350L)
                }
            }
        }
    }

    private fun startOutAutomation(view: WebView? = currentWebView()) {
        if (!automationMasterEnabled || !outAutomationEnabled || outAutomationActive) return
        val target = view ?: return
        outAutomationActive = true
        // Out is intentionally a two-step flow only:
        // open the leave-family URL, wait for it to load, then press the visible
        // final "Leave" button.  There is NO "Leave Family Group" click and NO scroll.
        outAutomationStage = "leave"
        outAutomationClickIssued = false
        target.loadUrl(OUT_LEAVE_FAMILY_URL)
    }

    private fun finishOutAutomation(view: WebView, success: Boolean) {
        if (!outAutomationActive) return
        outAutomationActive = false
        outAutomationStage = "idle"
        outAutomationClickIssued = false
        if (success) {
            Snackbar.make(drawerLayout, "تم مغادرة مجموعة العائلة", Snackbar.LENGTH_LONG).show()
            if (automationMasterEnabled && !automationCompletedForCurrentAccount) {
                startNextConfiguredStage(view, "out")
            }
        }
    }

    private fun injectOutAutomation(view: WebView) {
        if (googleVerificationActive || googleVerificationCheckPending) return
        if (!outAutomationActive || !outAutomationEnabled || !automationMasterEnabled) return
        if (outAutomationClickIssued) return

        // Out intentionally does not scroll and does not click "Leave Family Group".
        // It waits for the final visible Leave button on the loaded page and presses it.
        val script = """
            (function() {
              const visible = e => {
                if (!e) return false;
                const r=e.getBoundingClientRect(), st=getComputedStyle(e);
                return r.width>1 && r.height>1 && st.display!=='none' && st.visibility!=='hidden' && st.opacity!=='0';
              };
              const norm = s => String(s || '').replace(/\s+/g,' ').trim().toLowerCase();
              const roots=[document];
              for(let i=0;i<roots.length;i++){
                let els=[]; try{els=Array.from(roots[i].querySelectorAll('*'));}catch(e){}
                for(const el of els) if(el.shadowRoot) roots.push(el.shadowRoot);
              }

              let target=null;
              for(const root of roots){
                let buttons=[]; try{buttons=Array.from(root.querySelectorAll('button'));}catch(e){}
                for(const el of buttons){
                  if(!visible(el)) continue;
                  const text=norm(el.innerText || el.textContent || '');
                  const aria=norm(el.getAttribute('aria-label') || '');
                  const jsname=el.getAttribute('jsname') || '';
                  const type=(el.getAttribute('type') || '').toLowerCase();
                  const cls=String(el.className || '');
                  if(text === 'leave' && type === 'submit' &&
                     (jsname === 'Pr7Yme' || cls.includes('UywwFc-LgbsSe'))){
                    target=el; break;
                  }
                  if(text === 'leave' && type === 'submit'){ target=el; break; }
                  if(aria === 'leave' && type === 'submit'){ target=el; break; }
                }
                if(target) break;
              }

              const body=norm(document.body && document.body.innerText);
              const peopleSharing = /\bpeople & sharing\b/.test(body) &&
                                    /\bcontacts\b/.test(body) &&
                                    /\bcontact info saved from interactions\b/.test(body);
              const success=peopleSharing ||
                            /you left (the )?(family )?group/.test(body) ||
                            /left the (family )?group/.test(body) ||
                            /you('ve| have) left/.test(body);
              if(success) return 'success';
              if(!target) return 'none';

              const r=target.getBoundingClientRect();
              const point={
                x:r.left+r.width/2,
                y:r.top+r.height/2,
                cssWidth:window.innerWidth || document.documentElement.clientWidth || 1,
                cssHeight:window.innerHeight || document.documentElement.clientHeight || 1
              };

              // First try the button's own DOM activation.  Google uses jsaction on
              // this button, so the native button click is the most direct trigger.
              try { target.focus({preventScroll:true}); } catch(e) {}
              try { target.click(); } catch(e) {
                try {
                  for(const type of ['pointerdown','mousedown','pointerup','mouseup','click']){
                    target.dispatchEvent(new MouseEvent(type,{bubbles:true,cancelable:true,view:window}));
                  }
                } catch(e2) {}
              }

              return 'tap:' + JSON.stringify(point);
            })();
        """.trimIndent()

        view.evaluateJavascript(script) { result ->
            val state = result.trim().removeSurrounding("\"").replace("\\\"", "\"")
            when {
                state == "success" -> finishOutAutomation(view, true)
                state.startsWith("tap:") -> {
                    // The JS button activation above is the primary action.  A native
                    // touch at the inspected button center is the fallback in case the
                    // page ignores programmatic activation.  No scrolling is performed.
                    val json = state.removePrefix("tap:")
                    try {
                        val point = JSONObject(json)
                        val xCss = point.optDouble("x", -1.0).toFloat()
                        val yCss = point.optDouble("y", -1.0).toFloat()
                        val cssWidth = point.optDouble("cssWidth", -1.0).toFloat()
                        val cssHeight = point.optDouble("cssHeight", -1.0).toFloat()
                        if (xCss >= 0f && yCss >= 0f && cssWidth > 0f && cssHeight > 0f) {
                            outAutomationClickIssued = true
                            val x = xCss * view.width / cssWidth
                            val y = yCss * view.height / cssHeight
                            view.postDelayed({
                                if (outAutomationActive) performNativeWebClick(view, x, y)
                            }, 250L)
                            outAutomationStage = "waiting_success"
                            outAutomationClickIssued = false
                            view.postDelayed({ if (outAutomationActive) injectOutAutomation(view) }, 1400L)
                        } else {
                            view.postDelayed({ if (outAutomationActive) injectOutAutomation(view) }, 500L)
                        }
                    } catch (_: Exception) {
                        view.postDelayed({ if (outAutomationActive) injectOutAutomation(view) }, 500L)
                    }
                }
                else -> if (outAutomationActive) {
                    // The URL may still be loading.  Keep checking the already-visible
                    // page; never scroll and never press the intermediate group button.
                    view.postDelayed({ injectOutAutomation(view) }, 450L)
                }
            }
        }
    }

    private fun startSupervisionAutomation(view: WebView? = currentWebView()) {
        if (!automationMasterEnabled || !supervisionAutomationEnabled || supervisionAutomationActive) return
        val target = view ?: return
        supervisionAutomationActive = true
        supervisionAutomationStage = "next"
        supervisionAutomationClickIssued = false
        supervisionAgreeWasIssued = false
        supervisionPreAgreeUrl = ""
        supervisionPreAgreeBody = ""
        target.loadUrl(SUPERVISION_GRADUATION_URL)
    }

    private fun finishSupervisionAutomation(view: WebView, success: Boolean) {
        if (!supervisionAutomationActive) return
        supervisionAutomationActive = false
        supervisionAutomationStage = "idle"
        supervisionAutomationClickIssued = false
        supervisionAgreeWasIssued = false
        supervisionPreAgreeUrl = ""
        supervisionPreAgreeBody = ""
        if (success) {
            Snackbar.make(drawerLayout, "تم تنفيذ إيقاف الإشراف", Snackbar.LENGTH_LONG).show()
            if (automationMasterEnabled && !automationCompletedForCurrentAccount) {
                view.postDelayed({
                    if (automationMasterEnabled && !automationCompletedForCurrentAccount) {
                        startNextConfiguredStage(view, "supervision")
                    }
                }, 900L)
            }
        }
    }

    private fun injectSupervisionAutomation(view: WebView) {
        if (googleVerificationActive || googleVerificationCheckPending) return
        if (!supervisionAutomationActive || !supervisionAutomationEnabled || !automationMasterEnabled) return

        // New Supervision flow: do NOT scroll at all.  Google renders the action
        // button for the current step; as soon as that page is ready, click the
        // action belonging to that step.  This avoids the WebView scroll/gesture
        // lock that could happen when Scroll down and a page action competed.
        val stage = supervisionAutomationStage
        // The eligibility/error page is also a valid terminal state for Supervision.
        // If Google shows this message, consider the Supervision stage complete and
        // continue to the next enabled automation stage.
        val eligibilityScript = """
            (function() {
              try {
                const body = String((document.body && document.body.innerText) || '').replace(/\s+/g,' ').trim().toLowerCase();
                const hasUnavailable = body.indexOf('this page is not available') !== -1;
                const hasEligibility = body.indexOf("you don't meet the eligibility requirements to access this page") !== -1;
                return (hasUnavailable && hasEligibility) ? 'eligibility' : 'wait';
              } catch(e) { return 'wait'; }
            })();
        """.trimIndent()
        view.evaluateJavascript(eligibilityScript) { result ->
            val terminal = result?.trim()?.removeSurrounding("\"") == "eligibility"
            if (terminal && supervisionAutomationActive) {
                finishSupervisionAutomation(view, true)
            } else if (supervisionAutomationActive) {
                continueSupervisionAutomationAfterEligibilityCheck(view, stage)
            }
        }
        return
    }

    private fun continueSupervisionAutomationAfterEligibilityCheck(view: WebView, stage: String) {
        if (!supervisionAutomationActive || !supervisionAutomationEnabled || !automationMasterEnabled) return
        if (stage == "waiting_page4") {
            val page4Script = """
                (function() {
                  try {
                    const body = String((document.body && document.body.innerText) || '').replace(/\s+/g,' ').trim();
                    const lower = body.toLowerCase();
                    const privacy = /privacy (and|&) terms/.test(lower);
                    const agree = Array.from(document.querySelectorAll('button')).some(b =>
                      String(b.innerText || b.textContent || '').replace(/\s+/g,' ').trim().toLowerCase() === 'i agree'
                    );
                    return (!privacy && !agree && body.length > 40) ? 'success' : 'wait';
                  } catch(e) { return 'wait'; }
                })();
            """.trimIndent()
            view.evaluateJavascript(page4Script) { result ->
                if (result?.trim()?.removeSurrounding("\"") == "success" && supervisionAutomationActive) {
                    finishSupervisionAutomation(view, true)
                } else if (supervisionAutomationActive) {
                    view.postDelayed({ if (supervisionAutomationActive) injectSupervisionAutomation(view) }, 600L)
                }
            }
            return
        }

        val script = """
            (function() {
              try {
                const stage = ${JSONObject.quote(stage)};
                const visible = el => {
                  if (!el) return false;
                  const r = el.getBoundingClientRect(), st = getComputedStyle(el);
                  return r.width > 1 && r.height > 1 && st.display !== 'none' &&
                         st.visibility !== 'hidden' && st.opacity !== '0' && !el.disabled;
                };
                // Stop supervision / I agree may exist in the DOM below the viewport.
                // For those two stages, do not require viewport visibility: if Google has
                // created the real button, issue a DOM click directly.
                const forceStage = stage === 'stop' || stage === 'agree';
                const norm = s => String(s || '').replace(/\\s+/g,' ').trim().toLowerCase();
                const roots = [document];
                for (let i=0; i<roots.length; i++) {
                  let els=[];
                  try { els=Array.from(roots[i].querySelectorAll('*')); } catch(e) {}
                  for (const el of els) if (el.shadowRoot) roots.push(el.shadowRoot);
                }
                let target = null;
                for (const root of roots) {
                  let buttons=[];
                  try { buttons=Array.from(root.querySelectorAll('button')); } catch(e) {}
                  for (const b of buttons) {
                    if (!forceStage && !visible(b)) continue;
                    if (forceStage && (b.disabled || b.getAttribute('aria-disabled') === 'true')) continue;
                    const text = norm(b.innerText || b.textContent || '');
                    const aria = norm(b.getAttribute('aria-label') || '');
                    const jsname = b.getAttribute('jsname') || '';
                    const cls = String(b.className || '');
                    if (stage === 'next' && text === 'next') { target=b; break; }
                    if (stage === 'stop' && text === 'stop supervision' && jsname === 'LgbsSe') { target=b; break; }
                    if (stage === 'agree' && text === 'i agree' && jsname === 'LgbsSe') { target=b; break; }
                  }
                  if (target) break;
                }
                if (!target) return 'none';
                const text = norm(target.innerText || target.textContent || '');
                try {
                  target.click();
                  return 'clicked:' + JSON.stringify({text:text, url:String(location.href||'')});
                } catch(e) {
                  try {
                    target.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));
                    return 'clicked:' + JSON.stringify({text:text, url:String(location.href||'')});
                  } catch(e2) { return 'none'; }
                }
              } catch(e) { return 'none'; }
            })();
        """.trimIndent()

        view.evaluateJavascript(script) { result ->
            if (!supervisionAutomationActive) return@evaluateJavascript
            val state = result?.trim()?.removeSurrounding("\"")?.replace("\\\"", "\"") ?: "none"
            if (!supervisionAutomationActive) return@evaluateJavascript
            if (!state.startsWith("clicked:")) {
                // Keep polling the current page. No scroll, swipe, or coordinate tap is sent.
                view.postDelayed({ if (supervisionAutomationActive) injectSupervisionAutomation(view) }, 450L)
                return@evaluateJavascript
            }

            try {
                val point = JSONObject(state.removePrefix("clicked:"))
                if (stage == "agree") {
                    supervisionAgreeWasIssued = true
                    supervisionAutomationStage = "waiting_page4"
                    supervisionAutomationClickIssued = false
                    supervisionPreAgreeUrl = point.optString("url", view.url.orEmpty())
                    view.postDelayed({ if (supervisionAutomationActive) injectSupervisionAutomation(view) }, 900L)
                } else if (stage == "next") {
                    supervisionAutomationStage = "stop"
                    supervisionAutomationClickIssued = false
                    view.postDelayed({ if (supervisionAutomationActive) injectSupervisionAutomation(view) }, 900L)
                } else if (stage == "stop") {
                    supervisionAutomationStage = "agree"
                    supervisionAutomationClickIssued = false
                    view.postDelayed({ if (supervisionAutomationActive) injectSupervisionAutomation(view) }, 900L)
                }
            } catch (_: Exception) {
                supervisionAutomationClickIssued = false
                view.postDelayed({ if (supervisionAutomationActive) injectSupervisionAutomation(view) }, 500L)
            }
        }
    }

    private fun injectSupervisionAutomationStage(view: WebView, stage: String) {
        if (!supervisionAutomationActive || !supervisionAutomationEnabled || !automationMasterEnabled) return
        // Kept as a compatibility entry point for existing callbacks. The new flow
        // intentionally ignores Scroll down stages and uses only direct page actions.
        if (stage == "next" || stage == "stop" || stage == "agree" || stage == "waiting_page4") {
            injectSupervisionAutomation(view)
        } else {
            supervisionAutomationStage = when (stage) {
                "down1", "down1_wait" -> "stop"
                "down2", "down2_wait" -> "agree"
                else -> stage
            }
            injectSupervisionAutomation(view)
        }
    }

    private fun injectSupervisionAutomationStageAfterCheck(view: WebView, stage: String) {
        // Compatibility wrapper for older callers. No scrolling is performed.
        if (!supervisionAutomationActive) return
        supervisionAutomationStage = when (stage) {
            "down1", "down1_wait" -> "stop"
            "down2", "down2_wait" -> "agree"
            else -> stage
        }
        injectSupervisionAutomation(view)
    }

    private fun installInspectMode(view: WebView) {
        if (!inspectModeEnabled) return
        val script = """
            (function() {
              try {
                if (window.__emInspectInstalled) return true;
                window.__emInspectInstalled = true;

                const esc = s => String(s || '').replace(/\s+/g,' ').trim();
                const visible = x => {
                  if (!x || x.nodeType !== 1) return false;
                  const r=x.getBoundingClientRect(), st=getComputedStyle(x);
                  return r.width>0 && r.height>0 && st.display!=='none' && st.visibility!=='hidden' && st.opacity!=='0';
                };
                const interactive = x => !!(x && x.nodeType===1 && (
                  x.matches?.('button,a,[role="button"],input,select,textarea,[tabindex]') ||
                  typeof x.onclick === 'function'
                ));
                const closestInteractive = x => {
                  let n=x;
                  for(let i=0;n&&i<12;i++,n=n.parentElement) if(interactive(n)) return n;
                  return x;
                };
                const cssSelector = x => {
                  if (!x || x.nodeType!==1) return '';
                  try {
                    if (x.id) return '#'+CSS.escape(x.id);
                  } catch(_) {}
                  const parts=[]; let cur=x;
                  while(cur && cur.nodeType===1 && cur !== document.body && parts.length<8){
                    let part=cur.tagName.toLowerCase();
                    try {
                      if(cur.classList?.length) part += '.'+Array.from(cur.classList).slice(0,3).map(CSS.escape).join('.');
                    } catch(_) {}
                    let n=1, sib=cur.previousElementSibling;
                    while(sib){ if(sib.tagName===cur.tagName) n++; sib=sib.previousElementSibling; }
                    if(n>1) part += ':nth-of-type('+n+')';
                    parts.unshift(part); cur=cur.parentElement;
                  }
                  return parts.join(' > ');
                };
                const xpath = x => {
                  if(!x || x.nodeType!==1) return '';
                  if(x.id) return '//*[@id='+JSON.stringify(x.id)+']';
                  const parts=[]; let cur=x;
                  while(cur && cur.nodeType===1){
                    let i=1, sib=cur.previousElementSibling;
                    while(sib){ if(sib.tagName===cur.tagName) i++; sib=sib.previousElementSibling; }
                    parts.unshift(cur.tagName.toLowerCase()+'['+i+']');
                    cur=cur.parentElement;
                  }
                  return '/'+parts.join('/');
                };
                const shadowPath = x => {
                  const path=[]; let cur=x;
                  while(cur){
                    const root=cur.getRootNode?.();
                    if(root && root.host){
                      path.unshift(cssSelector(cur));
                      cur=root.host;
                    } else {
                      path.unshift(cssSelector(cur)); break;
                    }
                  }
                  return path.filter(Boolean).join(' >>> ');
                };
                const attrs = x => {
                  const out={};
                  try { for(const a of Array.from(x.attributes||[])) out[a.name]=a.value; } catch(_) {}
                  return out;
                };
                const handler = function(e) {
                  if(!e || !e.isTrusted) return;
                  let el=(e.composedPath && e.composedPath()[0]) || e.target;
                  if(!el || el.nodeType!==1) return;
                  el=closestInteractive(el);
                  if(!visible(el)) return;
                  const r=el.getBoundingClientRect();
                  const data={
                    tag: el.tagName.toLowerCase(),
                    text: esc(el.innerText || el.textContent || '').slice(0,1000),
                    aria: esc(el.getAttribute('aria-label')),
                    ariaLabelledby: esc(el.getAttribute('aria-labelledby')),
                    title: esc(el.getAttribute('title')),
                    id: el.id || '',
                    classes: typeof el.className==='string' ? el.className : '',
                    href: el.href || el.getAttribute('href') || '',
                    value: el.value || '',
                    type: el.getAttribute('type') || '',
                    role: el.getAttribute('role') || '',
                    name: el.getAttribute('name') || '',
                    disabled: !!el.disabled || el.getAttribute('aria-disabled')==='true',
                    selector: cssSelector(el),
                    xpath: xpath(el),
                    shadowPath: shadowPath(el),
                    rect: {left:Math.round(r.left),top:Math.round(r.top),width:Math.round(r.width),height:Math.round(r.height)},
                    attributes: attrs(el),
                    outerHTML: String(el.outerHTML||'').slice(0,8000)
                  };
                  e.preventDefault(); e.stopPropagation();
                  try { window.EMInspect.report(JSON.stringify(data)); } catch(ignore) {}
                };
                window.__emInspectHandler=handler;
                document.addEventListener('click', handler, true);
                return true;
              } catch(err) { return false; }
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }

    private fun removeInspectMode(view: WebView) {
        view.evaluateJavascript("""
            (function(){
              try {
                if(window.__emInspectHandler) document.removeEventListener('click', window.__emInspectHandler, true);
                window.__emInspectHandler=null;
                window.__emInspectInstalled=false;
              } catch(e) {}
            })();
        """.trimIndent(), null)
    }

    private fun showInspectDetails(payload: String) {
        if (!inspectModeEnabled) return
        val obj = try { JSONObject(payload) } catch (_: Exception) { return }
        val tag=obj.optString("tag")
        val text=obj.optString("text")
        val aria=obj.optString("aria")
        val ariaLabelledby=obj.optString("ariaLabelledby")
        val title=obj.optString("title")
        val id=obj.optString("id")
        val classes=obj.optString("classes")
        val href=obj.optString("href")
        val value=obj.optString("value")
        val type=obj.optString("type")
        val role=obj.optString("role")
        val name=obj.optString("name")
        val selector=obj.optString("selector")
        val xpath=obj.optString("xpath")
        val shadowPath=obj.optString("shadowPath")
        val outer=obj.optString("outerHTML")
        val rect=obj.optJSONObject("rect")
        val attrs=obj.optJSONObject("attributes")
        val details=buildString {
            append("TAG: ").append(tag).append('\n')
            if(text.isNotBlank()) append("TEXT: ").append(text).append('\n')
            if(aria.isNotBlank()) append("ARIA: ").append(aria).append('\n')
            if(ariaLabelledby.isNotBlank()) append("ARIA-LABELLEDBY: ").append(ariaLabelledby).append('\n')
            if(title.isNotBlank()) append("TITLE: ").append(title).append('\n')
            if(id.isNotBlank()) append("ID: ").append(id).append('\n')
            if(classes.isNotBlank()) append("CLASS: ").append(classes).append('\n')
            if(role.isNotBlank()) append("ROLE: ").append(role).append('\n')
            if(type.isNotBlank()) append("TYPE: ").append(type).append('\n')
            if(name.isNotBlank()) append("NAME: ").append(name).append('\n')
            if(value.isNotBlank()) append("VALUE: ").append(value).append('\n')
            if(href.isNotBlank()) append("HREF: ").append(href).append('\n')
            if(selector.isNotBlank()) append("CSS SELECTOR: ").append(selector).append('\n')
            if(xpath.isNotBlank()) append("XPATH: ").append(xpath).append('\n')
            if(shadowPath.isNotBlank()) append("SHADOW PATH: ").append(shadowPath).append('\n')
            if(rect!=null) append("RECT: ").append(rect.toString()).append('\n')
            if(attrs!=null) append("ATTRIBUTES: ").append(attrs.toString()).append('\n')
            if(outer.isNotBlank()) append("\nOUTER HTML:\n").append(outer)
        }
        val body=TextView(this).apply { setText(details); textSize=12f; setTextIsSelectable(true); setPadding(dp(20),dp(8),dp(20),dp(8)) }
        val dialog=AlertDialog.Builder(this).setTitle("Inspect Element").setView(body)
            .setPositiveButton("Copy all", null).setNegativeButton("Close", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val cm=getSystemService(android.content.ClipboardManager::class.java)
                cm?.setPrimaryClip(android.content.ClipData.newPlainText("Inspect Element", details))
            }
        }
        dialog.show()
    }

    private fun startAuthenticatorAutomation(view: WebView? = currentWebView()) {
        if (!automationMasterEnabled || !authenticatorAutomationEnabled) return
        if (authenticatorAutomationActive) return
        val targetView = view ?: return
        if (authenticatorSecret.isBlank() && authenticatorOtpauthUri.isNotBlank()) {
            parseOtpAuth(authenticatorOtpauthUri)?.let { saveAuthenticator(it) }
        }
        authenticatorAutomationActive = true
        authenticatorAutomationStage = "open_setup"
        authenticatorAutomationQrScanned = false
        authenticatorAutomationCodeSubmitted = false
        authenticatorAutomationTurnOnClicked = false
        authenticatorAutomationFinalTurnOnClicked = false
        authenticatorAutomationFinalRefreshDone = false
        authenticatorAutomationSuccessSeen = false
        authenticatorAutomationLoadStarted = true
        authenticatorAutomationTrashClickIssued = false
        authenticatorAutomationRemoveAnywayClickIssued = false
        authenticatorAutomationQrScanInFlight = false
        // Continue on the exact WebView that just reported Password success.
        // Do not resolve currentWebView() again here: another tab becoming active
        // between the success callback and this hand-off must never steal the
        // Authenticator step.
        targetView.loadUrl(withSelectedLanguage(AUTHENTICATOR_SETUP_URL))
    }

    private fun stopAuthenticatorAutomation() {
        authenticatorAutomationActive = false
        authenticatorAutomationStage = "idle"
        authenticatorAutomationQrScanned = false
        authenticatorAutomationCodeSubmitted = false
        authenticatorAutomationTurnOnClicked = false
        authenticatorAutomationFinalTurnOnClicked = false
        authenticatorAutomationFinalRefreshDone = false
        authenticatorAutomationSuccessSeen = false
        authenticatorAutomationLoadStarted = false
        authenticatorAutomationQrScanInFlight = false
    }

    private fun startTwoStepAutomation(view: WebView? = currentWebView()) {
        if (!twoStepAutomationEnabled) return
        if (twoStepAutomationActive) return
        val target = view ?: return
        twoStepAutomationActive = true
        // Do NOT refresh/reload the Google 2-Step page.  Go directly to the page
        // and click the visible "Turn on 2-Step Verification" action as soon as
        // the page is ready.  Reloading was the source of the stuck state seen
        // on the user's device.
        twoStepAutomationStage = "direct_click"
        twoStepAutomationRefreshDone = false
        twoStepAutomationTurnOnClicked = false
        twoStepAutomationSkipClicked = false
        twoStepAutomationFallbackRefreshDone = false
        target.loadUrl(withSelectedLanguage(TWO_STEP_VERIFICATION_URL))
    }

    private fun stopTwoStepAutomation() {
        twoStepAutomationActive = false
        twoStepAutomationStage = "idle"
        twoStepAutomationRefreshDone = false
        twoStepAutomationTurnOnClicked = false
        twoStepAutomationSkipClicked = false
        twoStepAutomationFallbackRefreshDone = false
    }

    private fun finishTwoStepAutomation(view: WebView, success: Boolean) {
        if (!twoStepAutomationActive) return
        stopTwoStepAutomation()
        if (success) {
            Snackbar.make(drawerLayout, "تم تفعيل التحقق بخطوتين — الانتقال للمرحلة التالية", Snackbar.LENGTH_SHORT).show()
            view.postDelayed({
                if (automationMasterEnabled && !automationCompletedForCurrentAccount) {
                    startNextConfiguredStage(view, "two_step")
                }
            }, 250L)
        }
    }

    private fun injectTwoStepAutomation(view: WebView) {
        if (googleVerificationActive || googleVerificationCheckPending) return
        if (!twoStepAutomationActive || !twoStepAutomationEnabled || !automationMasterEnabled) return

        val script = """
            (function() {
              const norm = s => ((s || '') + '')
                .replace(/[«»\"“”‘’'`]/g, ' ')
                .replace(/[：:؛;،,!?؟()\[\]{}]/g, ' ')
                .replace(/\s+/g, ' ').trim().toLowerCase();
              const visible = e => {
                if (!e) return false;
                const r = e.getBoundingClientRect();
                const st = window.getComputedStyle(e);
                return r.width > 1 && r.height > 1 &&
                       st.visibility !== 'hidden' && st.display !== 'none' &&
                       st.opacity !== '0';
              };
              const text = e => norm([
                e.innerText, e.textContent, e.value,
                e.getAttribute('aria-label'), e.getAttribute('title'),
                e.getAttribute('data-tooltip'), e.getAttribute('data-tooltip-text')
              ].filter(Boolean).join(' '));
              const page = norm(document.body ? document.body.innerText : '');
              const isTwoStepPage = (() => {
                try {
                  const h1 = document.querySelector('h1.cdaFgf') ||
                             Array.from(document.querySelectorAll('h1')).find(e => norm(e.textContent) === '2-step verification');
                  return !!h1 && norm(h1.textContent) === '2-step verification';
                } catch (_) {
                  return /(^|\s)2[- ]?step verification(\s|$)/i.test(page);
                }
              })();

              // Google is forced to English by the Android app. Keep the matching
              // English-first and only retain Arabic as a harmless fallback.
              const turnOnRe = /(turn\s+on(?:\s+2[- ]?step\s+verification)?|enable\s+2[- ]?step(?:\s+verification)?|turn\s+on\s+2[- ]?step\s+verification|تفعيل\s+(?:ميزة\s+)?التحقق\s+بخطوتين)/i;
              const skipRe = /^(skip|not\s+now|later|تخطي|تخطى|تخطّي|التخطي|لاحقًا|لاحقا|ليس الآن|ليس الان)$/i;
              const successRe = /(2[- ]?step verification (?:is|has been) (?:on|enabled)|two[- ]?step verification (?:is|has been) (?:on|enabled)|2[- ]?step verification turned on|turned on successfully|turn off 2[- ]?step verification|disable 2[- ]?step verification|تم تفعيل التحقق بخطوتين|تم تفعيل ميزة التحقق بخطوتين)/i;

              if (successRe.test(page)) return 'success';

              // Prefer real controls. Do NOT treat a generic tabindex/container as
              // the button itself: Google's confirmation dialog can wrap BOTH
              // Cancel and Skip in one focusable container. Using that container's
              // center was the reason the old code could touch Cancel.
              const realControlSelector = 'button,a,[role="button"],input[type="button"],input[type="submit"]';
              const clickableSelector = realControlSelector + ',[tabindex]';
              const clickable = Array.from(document.querySelectorAll(clickableSelector)).filter(e => {
                return e.getAttribute('aria-disabled') !== 'true' && e.disabled !== true;
              });

              const nearestClickable = (e, forceDom) => {
                let n = e;
                for (let i = 0; n && i < 10; i++, n = n.parentElement) {
                  if (n.matches && n.matches(realControlSelector) && (forceDom || visible(n))) return n;
                }
                // Only use a generic tabindex element if there is no real button
                // ancestor at all.
                n = e;
                for (let i = 0; n && i < 10; i++, n = n.parentElement) {
                  if (n.matches && n.matches('[tabindex]') && (forceDom || visible(n))) return n;
                }
                return e;
              };

              const matchesTurnOn = e => turnOnRe.test(text(e));
              const matchesSkip = e => skipRe.test(text(e));

              // 1) First use the exact Google selector supplied by Inspect.
              // This is intentionally independent of viewport visibility: the
              // element only needs to exist in the DOM.
              let turnOn = null;
              let turnOnIssued = false;
              try { turnOnIssued = window.__emTwoStepTurnOnIssued === true; } catch (_) {}
              try {
                turnOn = document.querySelector('button[aria-label="Turn on 2-Step Verification"]');
                if (!turnOn) {
                  turnOn = document.querySelector('div:nth-of-type(2) > div:nth-of-type(3) > c-wiz > div > div.Hm1X5.JH1xTd > div.qsqhnc:nth-of-type(5) > div.VfPpkd-dgl2Hf-ppHlrf-sM5MNb > button.UywwFc-LgbsSe.UywwFc-LgbsSe-OWXEXe-dgl2Hf.UywwFc-StrnGf-YYd4I-VtOx3e');
                }
              } catch (_) {}
              if (!turnOn || !matchesTurnOn(turnOn)) turnOn = clickable.find(e => matchesTurnOn(e));

              // 2) Google sometimes puts the visible label in a nested span/div
              // without putting the label on the button itself. Find the exact
              // text node/element, then climb to its real clickable ancestor.
              if (!turnOn) {
                const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
                let node;
                while ((node = walker.nextNode())) {
                  const owner = node.parentElement;
                  if (!owner) continue;
                  if (turnOnRe.test(norm(node.nodeValue))) {
                    const candidate = nearestClickable(owner, true);
                    if (candidate) { turnOn = candidate; break; }
                  }
                }
              }

              // 3) Last DOM fallback: any visible element containing the exact
              // English phrase, then climb to its clickable ancestor.
              if (!turnOn) {
                const nodes = Array.from(document.querySelectorAll('body *'));
                for (const e of nodes) {
                  const t = text(e);
                  if (turnOnRe.test(t) && t.length < 180) {
                    const candidate = nearestClickable(e, true);
                    if (candidate) { turnOn = candidate; break; }
                  }
                }
              }

              const fireDomClick = e => {
                if (!e) return false;
                try { e.focus({preventScroll:true}); } catch (_) {}
                // Exactly one activation. Do not synthesize pointer/mouse events in
                // addition to click: Google's jsaction layer can treat those as
                // separate activations and reopen/close the same dialog.
                try { HTMLElement.prototype.click.call(e); return true; } catch (_) {
                  try { if (typeof e.click === 'function') { e.click(); return true; } } catch (_) {}
                }
                return false;
              };

              // The flow is deliberately stage-aware. Once Turn On has been
              // clicked, NEVER click it again while waiting for Google's sheet.
              // This prevents the automation from looping on the same page.
              // Confirmation sheet/dialog: only search for Skip after the real
              // Turn On click has happened. This keeps the two actions separate.
              const stage = "${twoStepAutomationStage}";
              const hasSkipControl = clickable.some(e => matchesSkip(e));
              if (stage === "confirm" || stage === "waiting_success") {
                let skip = clickable.find(e => matchesSkip(e));
                if (!skip) {
                  const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
                  let node;
                  while ((node = walker.nextNode())) {
                    const owner = node.parentElement;
                    if (!owner || !visible(owner)) continue;
                    if (skipRe.test(norm(node.nodeValue))) {
                      const candidate = nearestClickable(owner);
                      if (candidate && visible(candidate)) { skip = candidate; break; }
                    }
                  }
                }

                // The inspected Google dialog has a real button with aria-label="Skip"
                // and data-mdc-dialog-action="d7k1Xe". Prefer that exact button and
                // issue ONE DOM activation only. This avoids coordinate/touch races on
                // the dialog and, importantly, prevents a second activation while the
                // dialog is transitioning away.
                if (stage === "confirm") {
                  let skipIssued = false;
                  try { skipIssued = window.__emTwoStepSkipIssued === true; } catch (_) {}
                  if (skipIssued) return 'wait';
                  let exactSkip = null;
                  try {
                    exactSkip = document.querySelector('div.uW2Fw-Sx9Kwc.uW2Fw-Sx9Kwc-OWXEXe-n2to0e.uW2Fw-qON5Qe-FoKg4d-Sx9Kwc-fZiSAe:nth-of-type(13) > div.uW2Fw-wzTsW:nth-of-type(2) > div.uW2Fw-P5QLlc > div.uW2Fw-T0kwCb:nth-of-type(2) > div.VfPpkd-dgl2Hf-ppHlrf-sM5MNb:nth-of-type(3) > button.UywwFc-LgbsSe.UywwFc-LgbsSe-OWXEXe-dgl2Hf.UywwFc-StrnGf-YYd4I-VtOx3e');
                  } catch (_) {}
                  if (exactSkip && matchesSkip(exactSkip)) {
                    return 'skip_dom_exact';
                  }
                  if (skip) {
                    return 'skip_dom';
                  }
                }
                return 'wait';
              }

              // Turn On can sit below the current viewport on Google's 2-Step page.
              // First bring the real control into view, then try a native touch; if
              // Google still ignores it, the next poll also performs the forced DOM click.
              if (stage === "direct_click" && turnOn && !turnOnIssued) {
                try {
                  const r = turnOn.getBoundingClientRect();
                  const inside = r.width > 1 && r.height > 1 &&
                                 r.bottom >= 0 && r.top <= window.innerHeight &&
                                 r.right >= 0 && r.left <= window.innerWidth;
                  if (!inside) {
                    try { turnOn.scrollIntoView({behavior:'auto', block:'center', inline:'nearest'}); } catch (_) {
                      try { turnOn.scrollIntoView(false); } catch (_) {}
                    }
                    return 'scroll_to_turn_on';
                  }
                } catch (_) {}

                // Use ONE DOM activation for Turn On. Do not combine it with a native
                // touch: Google can treat the two events as two separate activations,
                // which makes the confirmation sheet flash and disappear.
                try {
                  turnOn.scrollIntoView({behavior:'auto', block:'center', inline:'nearest'});
                } catch (_) {}
                try {
                  window.__emTwoStepTurnOnIssued = true;
                  const activated = fireDomClick(turnOn);
                  if (!activated) { try { window.__emTwoStepTurnOnIssued = false; } catch (_) {} }
                  return activated ? 'turn_on_dom' : 'wait';
                } catch (_) {
                  try { window.__emTwoStepTurnOnIssued = false; } catch (_) {}
                  return 'wait';
                }
              }

              return 'wait';
            })();
        """.trimIndent()

        view.evaluateJavascript(script) { result ->
            val value = result?.trim('"')?.replace("\\\"", "\"") ?: ""
            when {
                value == "success" -> finishTwoStepAutomation(view, true)
                value == "scroll_to_turn_on" -> {
                    // Let scrollIntoView settle, then look up the same button again
                    // and perform the native touch on its now-visible center.
                    twoStepAutomationStage = "direct_click"
                    view.postDelayed({
                        if (twoStepAutomationActive && !twoStepAutomationTurnOnClicked) {
                            injectTwoStepAutomation(view)
                        }
                    }, 450L)
                }
                value == "turn_on_dom" -> {
                    // The DOM activation above is the only Turn On activation. Lock the
                    // stage immediately and give Google time to open the phone-number
                    // confirmation sheet containing Skip. Never re-click Turn On here.
                    twoStepAutomationTurnOnClicked = true
                    twoStepAutomationStage = "confirm"
                    view.postDelayed({ if (twoStepAutomationActive) injectTwoStepAutomation(view) }, 1400L)
                }
                value == "skip_dom_exact" || value == "skip_dom" -> {
                    // Exactly ONE Skip activation. The flag is set before the click so
                    // a fast JS/DOM mutation cannot cause the polling loop to issue it
                    // again. Do not send a native touch as a second activation.
                    twoStepAutomationSkipClicked = true
                    twoStepAutomationStage = "waiting_success"
                    val skipClickScript = """
                        (function(){
                          try {
                            const selector = 'div.uW2Fw-Sx9Kwc.uW2Fw-Sx9Kwc-OWXEXe-n2to0e.uW2Fw-qON5Qe-FoKg4d-Sx9Kwc-fZiSAe:nth-of-type(13) > div.uW2Fw-wzTsW:nth-of-type(2) > div.uW2Fw-P5QLlc > div.uW2Fw-T0kwCb:nth-of-type(2) > div.VfPpkd-dgl2Hf-ppHlrf-sM5MNb:nth-of-type(3) > button.UywwFc-LgbsSe.UywwFc-LgbsSe-OWXEXe-dgl2Hf.UywwFc-StrnGf-YYd4I-VtOx3e';
                            let el = document.querySelector(selector);
                            if (!el) el = Array.from(document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit]')).find(e => ((e.getAttribute('aria-label') || e.textContent || '').trim() === 'Skip'));
                            if (el) { window.__emTwoStepSkipIssued = true; HTMLElement.prototype.click.call(el); return 'clicked'; }
                          } catch (_) {}
                          return 'missing';
                        })();
                    """.trimIndent()
                    view.evaluateJavascript(skipClickScript, null)
                    view.postDelayed({ if (twoStepAutomationActive) injectTwoStepAutomation(view) }, 1400L)
                }
                else -> view.postDelayed({ if (twoStepAutomationActive) injectTwoStepAutomation(view) }, 900L)
            }
        }
    }

    /** Send a short real touch sequence to the WebView. */
    private fun performNativeWebClick(view: WebView, x: Float, y: Float) {
        if (view.width <= 1 || view.height <= 1) return
        val safeX = x.coerceIn(1f, view.width - 1f)
        val safeY = y.coerceIn(1f, view.height - 1f)
        val downTime = android.os.SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, safeX, safeY, 0).apply {
            source = android.view.InputDevice.SOURCE_TOUCHSCREEN
        }
        view.dispatchTouchEvent(down)
        down.recycle()
        view.postDelayed({
            if (!view.isAttachedToWindow) return@postDelayed
            val upTime = android.os.SystemClock.uptimeMillis()
            val up = MotionEvent.obtain(downTime, upTime, MotionEvent.ACTION_UP, safeX, safeY, 0).apply {
                source = android.view.InputDevice.SOURCE_TOUCHSCREEN
            }
            view.dispatchTouchEvent(up)
            up.recycle()
        }, 80L)
    }

    private fun finishAuthenticatorAutomation(view: WebView, success: Boolean) {
        if (!authenticatorAutomationActive) return
        if (success && authenticatorOtpauthUri.isNotBlank()) {
            parseOtpAuth(authenticatorOtpauthUri)?.let { config -> saveAuthenticator(config) }
        }
        stopAuthenticatorAutomation()
        if (success) {
            Snackbar.make(drawerLayout, "تم إعداد المصادقة — الانتقال للمرحلة التالية", Snackbar.LENGTH_SHORT).show()
            view.postDelayed({
                if (automationMasterEnabled && !automationCompletedForCurrentAccount) {
                    startNextConfiguredStage(view, "authenticator")
                }
            }, 250L)
        }
    }

    private fun injectAuthenticatorAutomation(view: WebView) {
        if (googleVerificationActive || googleVerificationCheckPending) return
        if (!automationMasterEnabled || !authenticatorAutomationActive || !authenticatorAutomationEnabled) return

        // The final Google page is dynamic.  Do not depend on one Snackbar or on
        // one exact Arabic/English sentence.  We keep polling the actual visible
        // page and handle the final confirmation controls ourselves.
        if (authenticatorAutomationStage == "waiting_success") {
            val successScript = """
                (function() {
                  const norm = s => ((s || '') + '').replace(/\s+/g, ' ').trim().toLowerCase();
                  const visible = el => !!el && el.offsetParent !== null;
                  const text = el => norm((el.innerText || el.textContent || el.value || el.getAttribute('aria-label') || el.getAttribute('title') || ''));
                  const allText = norm((document.body && document.body.innerText) || '');
                  const liveText = Array.from(document.querySelectorAll('[role=alert],[role=status],[aria-live],.snackbar,.toast'))
                    .filter(visible).map(text).join(' ');
                  const dialogs = Array.from(document.querySelectorAll('[role=dialog],dialog,[aria-modal=true]')).filter(visible);
                  const dialogText = dialogs.map(text).join(' ');
                  const combined = allText + ' ' + liveText + ' ' + dialogText;

                  // Google can put a final "Skip"/"Done" action in a confirmation
                  // dialog after the last Turn On.  Handle Skip first, then verify
                  // the green success state on the page.
                  const skip = Array.from(document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit]'))
                    .filter(visible)
                    .find(el => /^(skip|تخطى|تخطي|تخطّي|لاحقًا|ليس الآن|not now)$/i.test(text(el)));
                  if (skip && !skip.disabled) {
                    skip.click();
                    return 'skip';
                  }

                  const successText = /(2-step verification is on|two-step verification is on|2-step verification turned on|2-step verification enabled|authenticator app (is )?on|authenticator app added successfully|تم تفعيل التحقق بخطوتين|تم تفعيل المصادقة الثنائية|تم تفعيل المصادقة|تم إعداد تطبيق المصادقة بنجاح|تم التفعيل بنجاح|تم التفعيل)/i.test(combined);
                  const doneText = /(^|\s)(done|تم|حسنًا|موافق|إغلاق)(\s|$)/i.test(combined);
                  const greenSuccess = Array.from(document.querySelectorAll('[role=img],img,svg,[aria-label],[data-tooltip],[title],div,span'))
                    .filter(visible)
                    .some(el => {
                      const attrs = norm([el.getAttribute('aria-label'), el.getAttribute('data-tooltip'), el.getAttribute('title'), el.className].filter(Boolean).join(' '));
                      return /check[_ -]?circle|checkmark|success|green.*check|check.*green/.test(attrs);
                    });

                  return (successText || (greenSuccess && doneText)) ? 'success' : 'wait';
                })();
            """.trimIndent()
            view.evaluateJavascript(successScript) { result ->
                when (result?.trim('"')) {
                    "success" -> finishAuthenticatorAutomation(view, true)
                    "skip" -> view.postDelayed({
                        if (authenticatorAutomationActive) injectAuthenticatorAutomation(view)
                    }, 250L)
                    else -> view.postDelayed({
                        if (authenticatorAutomationActive) injectAuthenticatorAutomation(view)
                    }, 300L)
                }
            }
            return
        }

        when (authenticatorAutomationStage) {
            "open_setup" -> clickAuthenticatorSetupButton(view)
            "remove_authenticator_confirm" -> clickAuthenticatorRemoveAnyway(view)
            "qr" -> {
                if (!authenticatorAutomationQrScanned && !authenticatorAutomationQrScanInFlight) {
                    authenticatorAutomationQrScanInFlight = true
                    waitForAuthenticatorQrReady(view) { ready ->
                        if (!authenticatorAutomationActive) {
                            authenticatorAutomationQrScanInFlight = false
                            return@waitForAuthenticatorQrReady
                        }
                        if (!ready) {
                            authenticatorAutomationQrScanInFlight = false
                            view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 1200L)
                            return@waitForAuthenticatorQrReady
                        }
                        scanQrFromCurrentPage(view) { raw ->
                            authenticatorAutomationQrScanInFlight = false
                            if (!authenticatorAutomationActive) return@scanQrFromCurrentPage
                            val parsed = raw?.let { parseOtpAuth(it) }
                            if (parsed == null) {
                                view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 1500L)
                                return@scanQrFromCurrentPage
                            }
                            applyAuthenticatorRuntimeConfig(parsed)
                            authenticatorAutomationQrScanned = true
                            clickAuthenticatorNext(view)
                        }
                    }
                } else if (authenticatorAutomationQrScanned) {
                    clickAuthenticatorNext(view)
                }
            }
            "code" -> if (!authenticatorAutomationCodeSubmitted) fillAndSubmitAuthenticatorCode(view)
            "turn_on" -> clickAuthenticatorTurnOn(view)
            "final_refresh" -> {
                if (authenticatorAutomationFinalRefreshDone) {
                    authenticatorAutomationStage = "final_turn_on"
                    view.postDelayed({ if (authenticatorAutomationActive) clickAuthenticatorFinalTurnOn(view) }, 250L)
                } else {
                    // Give Google's first Turn On navigation time to settle, then
                    // perform the requested refresh exactly once. onPageFinished()
                    // will re-enter this stage after the refreshed page is ready.
                    view.postDelayed({
                        if (authenticatorAutomationActive && !authenticatorAutomationFinalRefreshDone) {
                            authenticatorAutomationFinalRefreshDone = true
                            view.reload()
                        }
                    }, 1200L)
                }
            }
            "final_turn_on" -> clickAuthenticatorFinalTurnOn(view)
            else -> view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 300L)
        }
    }

    private fun clickAuthenticatorSetupButton(view: WebView) {
        val script = """
            (function() {
              const TRASH_CLICK_ALREADY_ISSUED = ${authenticatorAutomationTrashClickIssued};
              let domTrashIssued = false;
              try { domTrashIssued = window.__emAuthenticatorTrashIssued === true; } catch (_) {}
              const visible = el => !!el && el.offsetParent !== null;
              const text = el => ((el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '') + '').replace(/\s+/g,' ').trim().toLowerCase();

              // Optional branch: if an existing Google Authenticator is already
              // present on the Authenticator page, remove it first. This branch
              // must never block the normal setup flow when the trash button is
              // absent. Use the exact selector supplied by Inspect and DOM click
              // so the element does not have to be in the viewport.
              let trash = null;
              try {
                trash = document.querySelector('div.OZ7tnf > div.edUmvf.iUwXVd > ul.u7hyyf > li.K6ZZTd.iUwXVd.bs2km > div.iAwpk.lY6Rwe > div.kvjuQc.biRLo:nth-of-type(3) > div.qsqhnc > button.pYTkkf-Bz112c-LgbsSe.wMI9H.Qd9OXe');
              } catch (_) {}
              // The trash action is a one-shot action for this automation run.
              // After Remove anyway closes the dialog, Google can leave the same
              // trash button in the DOM; never click it again.
              if (!TRASH_CLICK_ALREADY_ISSUED && !domTrashIssued && trash && /remove google authenticator/i.test(text(trash))) {
                if (!trash.disabled && trash.getAttribute('aria-disabled') !== 'true') {
                  try { window.__emAuthenticatorTrashIssued = true; trash.click(); return 'trash_clicked'; } catch (_) { try { window.__emAuthenticatorTrashIssued = false; } catch (_) {} }
                }
              }

              let domRemoveIssued = false;
              try { domRemoveIssued = window.__emAuthenticatorRemoveAnywayIssued === true; } catch (_) {}
              if (domRemoveIssued) return 'wait';
              const dialogs = Array.from(document.querySelectorAll('[role="dialog"], [aria-modal="true"]'));
              const removeDialog = dialogs.find(d => /you may lose access to your account/i.test(text(d)));
              if (removeDialog) return 'remove_confirm';

              const els = Array.from(document.querySelectorAll('button,a,[role=button]')).filter(visible);
              const target = els.find(el => /إعداد تطبيق المصادقة|إعداد المصادقة|set up authenticator|set up authenticator app|setup authenticator/i.test(text(el)));
              if (target) { target.click(); return 'clicked'; }
              const body = ((document.body && document.body.innerText) || '').replace(/\s+/g,' ');
              if (/QR|رمز QR|مسح رمز مصادقة/i.test(body)) return 'qr';
              return 'wait';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "trash_clicked" -> {
                    // Issue the trash click only once, then give Google's dialog
                    // enough time to animate/open before checking it.
                    authenticatorAutomationTrashClickIssued = true
                    authenticatorAutomationStage = "remove_authenticator_confirm"
                    view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 700L)
                }
                "remove_confirm" -> {
                    authenticatorAutomationStage = "remove_authenticator_confirm"
                    view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 450L)
                }
                "clicked" -> {
                    authenticatorAutomationStage = "qr"
                    view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 2000L)
                }
                "qr" -> {
                    authenticatorAutomationStage = "qr"
                    view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 1500L)
                }
                else -> view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 700L)
            }
        }
    }

    private fun clickAuthenticatorRemoveAnyway(view: WebView) {
        if (authenticatorAutomationRemoveAnywayClickIssued) {
            view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 700L)
            return
        }
        val script = """
            (function() {
              const norm = s => ((s || '') + '').replace(/\s+/g,' ').trim().toLowerCase();
              let domRemoveIssued = false;
              try { domRemoveIssued = window.__emAuthenticatorRemoveAnywayIssued === true; } catch (_) {}
              if (domRemoveIssued) return 'wait';
              const dialogs = Array.from(document.querySelectorAll('[role="dialog"], [aria-modal="true"]'));
              const dialog = dialogs.find(d => /you may lose access to your account/i.test(norm(d.innerText || d.textContent || '')));
              if (!dialog) return 'wait';
              let target = null;
              try {
                target = dialog.querySelector('button.mUIrbf-LgbsSe.mUIrbf-LgbsSe-OWXEXe-dgl2Hf.mUIrbf-kSE8rc-StrnGf-pvxB9-WPi0i[data-mdc-dialog-action="ok"]');
              } catch (_) {}
              if (!target) {
                target = Array.from(dialog.querySelectorAll('button,a,[role=button]')).find(el => /^remove anyway$/i.test(norm(el.innerText || el.textContent || el.getAttribute('aria-label') || '')));
              }
              if (!target || target.disabled || target.getAttribute('aria-disabled') === 'true') return 'wait';
              try { window.__emAuthenticatorRemoveAnywayIssued = true; target.click(); return 'removed'; } catch (_) {
                try { window.__emAuthenticatorRemoveAnywayIssued = false; } catch (_) {}
                try {
                  target.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));
                  return 'removed';
                } catch (__) { return 'wait'; }
              }
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "removed" -> {
                    // One confirmation click only. Let the Authenticator page
                    // settle before reopening setup so QR rendering/scanning
                    // is not raced by the automation loop.
                    authenticatorAutomationRemoveAnywayClickIssued = true
                    // Keep the trash latch set for the rest of this automation run.
                    // The same trash element may still exist after the dialog closes.
                    authenticatorAutomationStage = "open_setup"
                    view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 1500L)
                }
                else -> view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 1200L)
            }
        }
    }

    private fun clickAuthenticatorNext(view: WebView) {
        val script = """
            (function() {
              const visible = el => !!el && el.offsetParent !== null;
              const text = el => ((el.innerText || el.value || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '') + '').replace(/\s+/g,' ').trim().toLowerCase();
              const els = Array.from(document.querySelectorAll('button,a,input[type=submit],[role=button]')).filter(visible);
              const target = els.find(el => /^(التالي|next|continue|متابعة)$/i.test(text(el)) || /^(التالي|next|continue|متابعة)\\b/i.test(text(el)));
              if (target && !target.disabled) { target.click(); return 'clicked'; }
              const body = ((document.body && document.body.innerText) || '').replace(/\s+/g,' ');
              if (/إدخال الرمز|ادخل الرمز|enter the 6-digit|enter the code|6 digits/i.test(body)) return 'code';
              return 'wait';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "clicked" -> {
                    authenticatorAutomationStage = "code"
                    view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 1200L)
                }
                "code" -> {
                    authenticatorAutomationStage = "code"
                    view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 700L)
                }
                else -> view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 700L)
            }
        }
    }

    private fun fillAndSubmitAuthenticatorCode(view: WebView) {
        val code = runCatching {
            generateTotp(authenticatorSecret, System.currentTimeMillis(), authenticatorAlgorithm, authenticatorDigits, authenticatorPeriod)
        }.getOrNull() ?: return
        val codeJson = JSONObject.quote(code)
        val script = """
            (function() {
              const code = $codeJson;
              const visible = el => !!el && el.offsetParent !== null;
              const inputs = Array.from(document.querySelectorAll('input')).filter(visible);
              const candidates = inputs.filter(el => {
                const t = ((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('name') || '') + ' ' + (el.type || '')).toLowerCase();
                return /code|رمز|verification|otp|totp|authenticator/.test(t) || el.maxLength === 6;
              });
              const input = candidates[0] || inputs.find(el => el.type !== 'hidden');
              if (!input) return 'wait';
              const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set;
              if (setter) setter.call(input, code); else input.value = code;
              input.dispatchEvent(new Event('input',{bubbles:true}));
              input.dispatchEvent(new Event('change',{bubbles:true}));
              const buttons = Array.from(document.querySelectorAll('button,input[type=submit],[role=button]')).filter(visible);
              const text = el => ((el.innerText || el.value || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '') + '').replace(/\s+/g,' ').trim().toLowerCase();
              const target = buttons.find(el => /^(تأكيد|التالي|next|confirm|continue|متابعة|verify)$/i.test(text(el))) || buttons.find(el => /تأكيد|confirm|verify|next|التالي/.test(text(el)));
              if (target && !target.disabled) { target.click(); return 'submitted'; }
              return 'filled';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "submitted" -> {
                    authenticatorAutomationCodeSubmitted = true
                    authenticatorAutomationStage = "turn_on"
                    view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 1200L)
                }
                "filled" -> {
                    authenticatorAutomationCodeSubmitted = true
                    authenticatorAutomationStage = "turn_on"
                    view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 1200L)
                }
                else -> view.postDelayed({ if (authenticatorAutomationActive) fillAndSubmitAuthenticatorCode(view) }, 700L)
            }
        }
    }

    private fun clickAuthenticatorTurnOn(view: WebView) {
        val script = """
            (function() {
              const visible = el => !!el && el.offsetParent !== null;
              const text = el => ((el.innerText || el.value || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '') + '').replace(/\s+/g,' ').trim().toLowerCase();
              const els = Array.from(document.querySelectorAll('button,a,input[type=submit],[role=button]')).filter(visible);
              const target = els.find(el => /^(turn on|تشغيل ميزة التحقق بخطوتين|تفعيل ميزة التحقق بخطوتين|تفعيل التحقق بخطوتين|تفعيل المصادقة الثنائية)$/i.test(text(el))) ||
                             els.find(el => /(turn on|تفعيل ميزة التحقق بخطوتين|تشغيل ميزة التحقق بخطوتين|تفعيل التحقق بخطوتين|تفعيل المصادقة الثنائية)/i.test(text(el)) && !/(turn off|إيقاف|إيقاف التحقق)/i.test(text(el)));
              if (target && !target.disabled) { target.click(); return 'clicked'; }
              const body = ((document.body && document.body.innerText) || '').replace(/\s+/g,' ');
              if (/تخطي|skip|لاحقًا|not now|إلغاء|cancel|رجوع|back/i.test(body) && /التحقق بخطوتين|2-step verification|two-step verification/i.test(body)) return 'final';
              return 'wait';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "clicked" -> {
                    authenticatorAutomationTurnOnClicked = true
                    // Authenticator setup ends here. Do not perform the final
                    // 2-Step Verification enablement in this stage anymore.
                    // That operation is owned by the separate fourth switch.
                    view.postDelayed({
                        if (authenticatorAutomationActive) finishAuthenticatorAutomation(view, true)
                    }, 1200L)
                }
                "final" -> {
                    // If Google is already on the post-authenticator page, treat
                    // the Authenticator step as complete and let the separate
                    // 2-Step switch decide whether to continue.
                    finishAuthenticatorAutomation(view, true)
                }
                else -> view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 800L)
            }
        }
    }

    private fun clickAuthenticatorFinalTurnOn(view: WebView) {
        val script = """
            (function() {
              const visible = el => !!el && el.offsetParent !== null;
              const text = el => ((el.innerText || el.value || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '') + '').replace(/\s+/g,' ').trim().toLowerCase();
              const body = ((document.body && document.body.innerText) || '').replace(/\s+/g,' ').trim();
              try { window.scrollTo({top: document.documentElement.scrollHeight || document.body.scrollHeight, behavior: 'instant'}); } catch(e) { try { window.scrollTo(0, document.body.scrollHeight); } catch(_) {} }
              const els = Array.from(document.querySelectorAll('button,a,input[type=submit],[role=button]')).filter(visible);
              const candidates = els.filter(el => {
                  const t = text(el);
                  return /(turn on|تفعيل ميزة التحقق بخطوتين|تشغيل ميزة التحقق بخطوتين|تفعيل التحقق بخطوتين|تفعيل المصادقة الثنائية|تفعيل المصادقة)/i.test(t) &&
                         !/(turn off|إيقاف|إزالة|remove|delete)/i.test(t);
              });
              const target = candidates[0];
              if (target && !target.disabled) {
                  try { target.scrollIntoView({block:'center', behavior:'instant'}); } catch(e) {}
                  target.click();
                  return 'clicked';
              }
              // If Google already moved to the final confirmation state, let the
              // success poller detect it instead of clicking an unrelated control.
              if (/(2-step verification is on|two-step verification is on|تم تفعيل التحقق بخطوتين|تم تفعيل المصادقة الثنائية|تم التفعيل بنجاح)/i.test(body)) return 'success';
              return 'wait';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "clicked", "success" -> {
                    if (result?.trim('"') == "success") {
                        finishAuthenticatorAutomation(view, true)
                    } else {
                        authenticatorAutomationFinalTurnOnClicked = true
                        authenticatorAutomationStage = "waiting_success"
                        view.postDelayed({ if (authenticatorAutomationActive) injectAuthenticatorAutomation(view) }, 350L)
                    }
                }
                else -> view.postDelayed({ if (authenticatorAutomationActive) clickAuthenticatorFinalTurnOn(view) }, 300L)
            }
        }
    }

    /**
     * Generates a RFC 6238 TOTP code from a Base32 secret.
     * This is local-only: the secret never leaves the app.
     */
    private fun generateTotp(
        secret: String,
        timestampMillis: Long,
        algorithm: String = "SHA1",
        digits: Int = 6,
        period: Long = 30L
    ): String {
        require(digits == 6 || digits == 8) { "Unsupported TOTP digits" }
        require(period > 0L) { "Invalid TOTP period" }

        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
        val normalized = secret
            .replace("\\s".toRegex(), "")
            .replace("=", "")
            .uppercase(Locale.US)
        require(normalized.isNotEmpty()) { "Empty TOTP secret" }

        val bits = StringBuilder(normalized.length * 5)
        for (ch in normalized) {
            val value = alphabet.indexOf(ch)
            require(value >= 0) { "Invalid Base32 TOTP secret" }
            for (bit in 4 downTo 0) {
                bits.append(if ((value and (1 shl bit)) != 0) '1' else '0')
            }
        }
        val byteCount = bits.length / 8
        require(byteCount > 0) { "Invalid TOTP secret" }
        val key = ByteArray(byteCount)
        for (i in 0 until byteCount) {
            var value = 0
            for (bit in 0 until 8) {
                value = (value shl 1) or if (bits[i * 8 + bit] == '1') 1 else 0
            }
            key[i] = value.toByte()
        }

        val counter = timestampMillis / 1000L / period
        val data = ByteArray(8)
        var counterValue = counter
        for (i in 7 downTo 0) {
            data[i] = (counterValue and 0xFFL).toByte()
            counterValue = counterValue ushr 8
        }

        val macAlgorithm = when (algorithm.uppercase(Locale.US)) {
            "SHA256" -> "HmacSHA256"
            "SHA512" -> "HmacSHA512"
            else -> "HmacSHA1"
        }
        val mac = Mac.getInstance(macAlgorithm)
        mac.init(SecretKeySpec(key, macAlgorithm))
        val hash = mac.doFinal(data)
        val offset = hash[hash.lastIndex].toInt() and 0x0F
        val binary = ((hash[offset].toInt() and 0x7F) shl 24) or
            ((hash[offset + 1].toInt() and 0xFF) shl 16) or
            ((hash[offset + 2].toInt() and 0xFF) shl 8) or
            (hash[offset + 3].toInt() and 0xFF)
        val modulus = if (digits == 8) 100_000_000 else 1_000_000
        val otp = binary % modulus
        return otp.toString().padStart(digits, '0')
    }

    /**
     * Decode the QR that Google renders inside the WebView.
     *
     * A single WebView.draw() + one ZXing pass is not reliable on some Android
     * devices: the QR can be rendered at a small scale, anti-aliased, or with
     * a different luminance distribution than the rest of the page.  The old
     * implementation therefore worked on some screens and reported "no QR" on
     * others even though the QR was visibly present.
     *
     * We now use several inexpensive decode passes: full page, a centered crop,
     * 2x upscaled versions, and both Hybrid/Global binarizers.  We also first ask
     * the page DOM whether Google has exposed an otpauth:// payload directly.
     * No coordinates are hard-coded, so this keeps working if Google moves the QR.
     */
    private fun waitForAuthenticatorQrReady(view: WebView, onReady: (Boolean) -> Unit) {
        val script = """
            (function() {
              const visible = el => {
                if (!el) return false;
                const r = el.getBoundingClientRect();
                const s = getComputedStyle(el);
                return r.width > 80 && r.height > 80 && r.width < window.innerWidth * 0.98 && r.height < window.innerHeight * 0.98 &&
                       s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0 &&
                       r.right > 0 && r.bottom > 0 && r.left < window.innerWidth && r.top < window.innerHeight;
              };
              const media = Array.from(document.querySelectorAll('canvas,img,svg')).some(el => {
                if (!visible(el)) return false;
                const r = el.getBoundingClientRect();
                return Math.max(r.width,r.height) / Math.max(1,Math.min(r.width,r.height)) < 1.45;
              });
              const body = ((document.body && document.body.innerText) || '').replace(/\s+/g,' ').toLowerCase();
              const qrWords = /scan a qr code|set up authenticator app|choose scan a qr code|رمز qr|تطبيق المصادقة/.test(body);
              return media && qrWords ? 'ready' : 'wait';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            if (result?.trim('"') == "ready") {
                onReady(true)
            } else {
                onReady(false)
            }
        }
    }

    private fun scanQrFromCurrentPage(view: WebView, onDecoded: (String?) -> Unit) {
        view.post {
            var callbackCalled = false
            fun finish(value: String?) {
                if (callbackCalled) return
                callbackCalled = true
                onDecoded(value)
            }

            // IMPORTANT: never trust an arbitrary "otpauth://" string found in
            // Google's HTML. The page can contain stale/hidden values that are
            // not the QR currently shown to the user. Decode the QR that is
            // actually rendered on screen first, then use DOM data only as a
            // fallback when it belongs to a visible QR element.
            try {
                val width = view.width.coerceAtLeast(1)
                val height = view.height.coerceAtLeast(1)
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                view.draw(canvas)

                val hints = mapOf(
                    DecodeHintType.TRY_HARDER to true,
                    DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
                    DecodeHintType.CHARACTER_SET to "UTF-8"
                )

                fun decodeOne(sourceBitmap: Bitmap, pure: Boolean = false): String? {
                    if (sourceBitmap.width < 40 || sourceBitmap.height < 40) return null
                    val pixels = IntArray(sourceBitmap.width * sourceBitmap.height)
                    sourceBitmap.getPixels(pixels, 0, sourceBitmap.width, 0, 0, sourceBitmap.width, sourceBitmap.height)
                    val source = RGBLuminanceSource(sourceBitmap.width, sourceBitmap.height, pixels)
                    val localHints = if (pure) hints + (DecodeHintType.PURE_BARCODE to true) else hints
                    val readers = listOf(
                        BinaryBitmap(com.google.zxing.common.HybridBinarizer(source)),
                        BinaryBitmap(com.google.zxing.common.GlobalHistogramBinarizer(source))
                    )
                    for (bb in readers) {
                        val value = runCatching {
                            MultiFormatReader().apply { setHints(localHints) }.decodeWithState(bb).text
                        }.getOrNull()
                        if (!value.isNullOrBlank()) return value
                    }
                    return null
                }

                fun tryBitmap(candidate: Bitmap): String? {
                    decodeOne(candidate)?.let { return it }
                    val scaled = Bitmap.createScaledBitmap(candidate, candidate.width * 2, candidate.height * 2, false)
                    try {
                        decodeOne(scaled)?.let { return it }
                        decodeOne(scaled, pure = true)?.let { return it }
                    } finally {
                        scaled.recycle()
                    }
                    return null
                }

                // First pass: the complete visible page. This is deliberately
                // before any DOM extraction so the returned secret comes from
                // the QR the user can actually see.
                tryBitmap(bitmap)?.let {
                    bitmap.recycle()
                    finish(it)
                    return@post
                }

                // Ask the page only for geometry of visible, square-ish media
                // elements. We then crop those exact on-screen regions from the
                // WebView bitmap. This handles Google's canvas/img QR without
                // trusting hidden/stale otpauth strings in the HTML.
                val candidateScript = """
                    (function() {
                      try {
                        const vw = Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1);
                        const vh = Math.max(1, window.innerHeight || document.documentElement.clientHeight || 1);
                        const out = [];
                        const els = Array.from(document.querySelectorAll('canvas,img,svg'));
                        for (const el of els) {
                          const r = el.getBoundingClientRect();
                          const style = getComputedStyle(el);
                          const w = r.width, h = r.height;
                          if (w < 80 || h < 80 || w > vw * 0.98 || h > vh * 0.98) continue;
                          if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity || 1) === 0) continue;
                          if (r.right <= 0 || r.bottom <= 0 || r.left >= vw || r.top >= vh) continue;
                          const ratio = Math.max(w, h) / Math.max(1, Math.min(w, h));
                          if (ratio > 1.45) continue;
                          out.push({left:r.left, top:r.top, width:w, height:h, area:w*h});
                        }
                        out.sort((a,b) => b.area - a.area);
                        return JSON.stringify({vw:vw, vh:vh, items:out.slice(0, 12)});
                      } catch (_) { return '[]'; }
                    })();
                """.trimIndent()

                view.evaluateJavascript(candidateScript) { raw ->
                    try {
                        val jsonText = raw?.let { decodeJsString(it) }.orEmpty()
                        val root = JSONObject(jsonText)
                        val candidates = root.optJSONArray("items") ?: JSONArray()
                        val cssWidth = root.optDouble("vw", view.width.toDouble()).coerceAtLeast(1.0)
                        val cssHeight = root.optDouble("vh", view.height.toDouble()).coerceAtLeast(1.0)
                        val scaleX = width.toFloat() / cssWidth.toFloat()
                        val scaleY = height.toFloat() / cssHeight.toFloat()
                        for (i in 0 until candidates.length()) {
                            val item = candidates.optJSONObject(i) ?: continue
                            val left = (item.optDouble("left") * scaleX).toInt()
                            val top = (item.optDouble("top") * scaleY).toInt()
                            val cw = (item.optDouble("width") * scaleX).toInt()
                            val ch = (item.optDouble("height") * scaleY).toInt()
                            if (cw <= 0 || ch <= 0) continue
                            val pad = (maxOf(cw, ch) * 0.12f).toInt().coerceAtLeast(12)
                            val l = (left - pad).coerceAtLeast(0)
                            val t = (top - pad).coerceAtLeast(0)
                            val r = (left + cw + pad).coerceAtMost(bitmap.width)
                            val b = (top + ch + pad).coerceAtMost(bitmap.height)
                            if (r <= l || b <= t) continue
                            val crop = Bitmap.createBitmap(bitmap, l, t, r - l, b - t)
                            try {
                                tryBitmap(crop)?.let {
                                    crop.recycle()
                                    bitmap.recycle()
                                    finish(it)
                                    return@evaluateJavascript
                                }
                            } finally {
                                if (!crop.isRecycled) crop.recycle()
                            }
                        }

                        // Last visual pass: a centered crop is useful when the
                        // QR is painted into a non-media container.
                        val left = (width * 0.10f).toInt().coerceAtLeast(0)
                        val top = (height * 0.08f).toInt().coerceAtLeast(0)
                        val right = (width * 0.90f).toInt().coerceAtMost(width)
                        val bottom = (height * 0.92f).toInt().coerceAtMost(height)
                        if (right > left && bottom > top) {
                            val crop = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
                            try {
                                tryBitmap(crop)?.let {
                                    crop.recycle()
                                    bitmap.recycle()
                                    finish(it)
                                    return@evaluateJavascript
                                }
                            } finally {
                                if (!crop.isRecycled) crop.recycle()
                            }
                        }

                        bitmap.recycle()
                        finish(null)
                    } catch (_: Throwable) {
                        if (!bitmap.isRecycled) bitmap.recycle()
                        finish(null)
                    }
                }
            } catch (_: Throwable) {
                finish(null)
            }
        }
    }

    private fun decodeJsString(raw: String): String {
        return runCatching {
            val value = org.json.JSONTokener(raw).nextValue()
            if (value is String) value else raw.trim('"')
        }.getOrElse { raw.trim('"')
            .replace("\\/", "/")
            .replace("\\u003d", "=")
            .replace("\\u0026", "&")
            .replace("\\u003A", ":")
            .replace("\\u003a", ":")
            .replace("\\u002F", "/")
            .replace("\\u002f", "/")
        }
    }


    private fun injectRecoveryEmailRemovalScript(view: WebView) {
        if (googleVerificationActive || googleVerificationCheckPending) return
        if (!recoveryEmailAutomationActive) return
        val script = """
            (function() {
              const visible = el => !!el && el.offsetParent !== null;
              const normalize = s => (s || '').replace(/\\s+/g, ' ').trim();
              const lower = s => normalize(s).toLowerCase();
              const attrs = el => [el?.getAttribute('aria-label'), el?.getAttribute('data-tooltip'), el?.getAttribute('title')]
                .filter(Boolean).join(' ').replace(/\\s+/g, ' ').trim();
              const recoveryHeaderRe = /البريد الإلكتروني المخصص لاسترداد الحساب|عنوان البريد الإلكتروني المخصص لاسترداد الحساب|recovery email/i;
              const addRecoveryRe = /إضافة بريد إلكتروني لاسترداد الحساب|add a recovery email|add recovery email/i;
              const deleteLabelRe = /^(حذف|delete|remove|إزالة)$/i;
              const successRe = /تمت إزالة البريد الإلكتروني المخصص لاسترداد الحساب|تم حذف البريد الإلكتروني المخصص لاسترداد الحساب|تمت إزالة بريد الاسترداد|تم حذف بريد الاسترداد|recovery email.*(?:removed|deleted)|recovery.*email.*(?:removed|deleted)/i;

              // 1) The dedicated Recovery Email page is opened directly by Kotlin.
              // If the email is already absent, report that only when Google explicitly
              // renders the "Add recovery email" action.
              const bodyText = normalize(document.body?.innerText || '');
              const isRecoveryPage = location.href.includes('/recovery/email') ||
                                     (recoveryHeaderRe.test(bodyText) && !location.href.includes('/security'));

              // 2) Confirmation dialog after pressing the trash icon.
              const dialogs = Array.from(document.querySelectorAll('[role="dialog"], [aria-modal="true"]')).filter(visible);
              for (const dialog of dialogs) {
                const confirm = Array.from(dialog.querySelectorAll('button,[role="button"],a'))
                  .filter(visible)
                  .find(el => deleteLabelRe.test(normalize(el.innerText || el.textContent || '')) || deleteLabelRe.test(attrs(el)));
                if (confirm) {
                  confirm.click();
                  return 'delete_confirmed';
                }
              }

              if (isRecoveryPage) {
                // Do not click the trash icon again after the confirmation flow has begun.
                const controls = Array.from(document.querySelectorAll('button,[role="button"],a,input[type="button"],input[type="submit"]')).filter(visible);
                const trash = controls.find(el => {
                  const a = lower(attrs(el));
                  const icon = lower(el.querySelector('svg')?.getAttribute('aria-label') || '');
                  const data = lower(el.getAttribute('data-tooltip-id') || '');
                  return /trash|delete|remove|حذف|إزالة|سلة|مهملات/.test(a) ||
                         /trash|delete|remove|حذف|إزالة|سلة|مهملات/.test(icon) ||
                         /trash|delete|remove/.test(data);
                });
                if (trash && !%s) {
                  trash.click();
                  return 'trash_clicked';
                }

                if (addRecoveryRe.test(bodyText)) return 'not_present';
                return 'waiting';
              }

              return 'waiting';
            })();
        """.trimIndent().format(if (recoveryTrashClicked) "true" else "false")

        if (recoveryRemovalAwaitingVerification) {
            verifyRecoveryRemoval(view)
            return
        }
        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "trash_clicked" -> {
                    recoveryTrashClicked = true
                    view.postDelayed({ if (recoveryEmailAutomationActive) injectRecoveryEmailRemovalScript(view) }, 250L)
                }
                "delete_confirmed" -> {
                    recoveryRemovalAwaitingVerification = true
                    view.postDelayed({ if (recoveryRemovalAwaitingVerification) verifyRecoveryRemoval(view) }, 250L)
                }
                "not_present" -> {
                    // Google explicitly shows the "Add recovery email" action, which
                    // means there is no recovery email configured. In that case there
                    // is nothing to delete, so Recovery is considered satisfied and
                    // the combined flow may continue directly to Password.
                    finishRecoveryStage(view, recoveryWasAlreadyAbsent = true)
                }
                "waiting" -> {
                    view.postDelayed({ if (recoveryEmailAutomationActive) injectRecoveryEmailRemovalScript(view) }, 250L)
                }
            }
        }
    }

    private fun verifyRecoveryRemoval(view: WebView) {
        if (!recoveryRemovalAwaitingVerification) return
        val script = """
            (function() {
              const visible = el => !!el && el.offsetParent !== null;
              const normalize = s => (s || '').replace(/\\s+/g, ' ').trim();
              const bodyText = normalize(document.body?.innerText || '');
              const recoveryHeaderRe = /البريد الإلكتروني المخصص لاسترداد الحساب|عنوان البريد الإلكتروني المخصص لاسترداد الحساب|recovery email/i;
              const addRecoveryRe = /إضافة بريد إلكتروني لاسترداد الحساب|add a recovery email|add recovery email/i;
              const successRe = /تمت إزالة البريد الإلكتروني المخصص لاسترداد الحساب|تم حذف البريد الإلكتروني المخصص لاسترداد الحساب|تمت إزالة بريد الاسترداد|تم حذف بريد الاسترداد|recovery email.*(?:removed|deleted)|recovery.*email.*(?:removed|deleted)/i;

              // This must be Google's dedicated Recovery Email destination, not the
              // Security & sign-in page. The screenshot shows the Recovery Email header
              // together with the Add Recovery Email action after deletion.
              const isRecoveryDestination =
                    (location.href.includes('/recovery/email') || recoveryHeaderRe.test(bodyText)) &&
                    !location.href.includes('/security');

              // Google may render the success message in a snackbar/alert that is
              // not part of the main page text. Check the whole visible document and
              // live/alert regions as well. The success notification itself is the
              // authoritative signal that the deletion completed.
              const liveText = Array.from(document.querySelectorAll('[role="alert"],[role="status"],[aria-live],.snackbar,.toast'))
                .filter(visible)
                .map(el => normalize(el.innerText || el.textContent || el.getAttribute('aria-label') || ''))
                .join(' ');
              const hasSuccessNotification = successRe.test(bodyText) || successRe.test(liveText);

              // Once Google shows the deletion confirmation, move immediately to
              // Password. Do not require the Add Recovery Email button because the
              // snackbar can appear while Google is still finishing its navigation.
              if (isRecoveryDestination && hasSuccessNotification) return 'success_seen';

              // No recovery email: this is the only case where we may continue without
              // a deletion notification. Google must explicitly show the add-recovery
              // action on the dedicated Recovery Email page.
              const hasAddButton = Array.from(document.querySelectorAll('button,a,[role="button"],[role="link"]'))
                .filter(visible)
                .some(el => addRecoveryRe.test(normalize(el.innerText || el.textContent || el.getAttribute('aria-label') || '')));
              if (isRecoveryDestination && hasAddButton) return 'destination_only';
              return 'waiting';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "removed_confirmed" -> {
                    recoverySuccessNotificationSeen = true
                    finishRecoveryStage(view)
                }
                "success_seen" -> {
                    // This is the exact hand-off point: Google's deletion notification
                    // has appeared. Stop Recovery immediately and start Password.
                    recoverySuccessNotificationSeen = true
                    finishRecoveryStage(view)
                }
                "destination_only" -> {
                    // Explicitly no recovery email exists. This is the only successful
                    // no-email path and does not require a deletion snackbar.
                    finishRecoveryStage(view, recoveryWasAlreadyAbsent = true)
                }
                else -> {
                    view.postDelayed({ if (recoveryRemovalAwaitingVerification) verifyRecoveryRemoval(view) }, 500L)
                }
            }
        }
    }

    private fun finishRecoveryStage(view: WebView, recoveryWasAlreadyAbsent: Boolean = false) {
        recoveryRemovalAwaitingVerification = false
        recoveryEmailPageOpened = false
        recoveryTrashClicked = false
        recoverySuccessNotificationSeen = false
        recoveryEmailAutomationActive = false

        combinedAutomationWaitingForPassword = false
        // Recovery completion hands off only to the next ENABLED stage.
        // Password is intentionally the FINAL stage.
        view.postDelayed({
            startNextConfiguredStage(view, "recovery")
        }, if (recoveryWasAlreadyAbsent) 150L else 220L)
    }

    private fun clearPasswordAutomationState() {
        passwordAutomationActive = false
        passwordChangeSubmitted = false
        passwordReauthSubmitted = false
    }

    private fun completePasswordAutomationFromSuccess(view: WebView) {
        if (!passwordAutomationActive || !passwordChangeSubmitted) return

        passwordAutomationActive = false
        passwordChangeSubmitted = false
        passwordReauthSubmitted = false
        passwordFlowStartedForCurrentAutomation = false
        recoveryEmailAutomationActive = false
        combinedAutomationWaitingForPassword = false

        // Clear the one-submit lock only after Google has accepted the change.
        view.evaluateJavascript("try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); sessionStorage.removeItem('__emPasswordFlowReauth'); } catch(e) {}", null)

        // Password is intentionally the final stage of Auto.
        automationCompletedForCurrentAccount = true
        automationHasRunInCurrentGoogleSession = true
        completedAccountKey = currentAccountKey
        Snackbar.make(drawerLayout, "تم تغيير كلمة المرور بنجاح — انتهت كل مراحل Auto", Snackbar.LENGTH_LONG).show()
    }

    private fun injectPasswordChangeScript(view: WebView) {
        if (googleVerificationActive || googleVerificationCheckPending) return
        if (!passwordAutomationActive) return
        val current = JSONObject.quote(passwordAutomationCurrent)
        val newPassword = JSONObject.quote(passwordAutomationNew)

        val script = """
            (function() {
              const currentPassword = $current;
              const newPassword = $newPassword;
              const visible = el => !!el && el.offsetParent !== null;
              const setValue = (el, value) => {
                const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
                if (setter) setter.call(el, value); else el.value = value;
                el.dispatchEvent(new Event('input', {bubbles:true}));
                el.dispatchEvent(new Event('change', {bubbles:true}));
              };
              const buttonText = el => ((el.innerText || el.value || el.getAttribute('aria-label') || '') + '').trim().toLowerCase();
              const buttons = Array.from(document.querySelectorAll('button, input[type=submit]')).filter(visible);
              const passwords = Array.from(document.querySelectorAll('input[type=password]')).filter(visible);
              const pageText = document.body?.innerText || document.documentElement?.innerText || '';
              // Google can show password success in more than one UI surface:
              // a bottom snackbar/toast OR a green confirmation banner near the
              // top of the page. Do not wait for one specific notification class.
              // Read all visible notification-like elements, plus visible elements
              // with a green background, and normalize Arabic whitespace/punctuation.
              const normalizeSuccessText = value => (value || '')
                .replace(/[\u200f\u200e]/g, '')
                .replace(/[\u0640]/g, '')
                .replace(/[\u061f.,،؛:!؟]+/g, ' ')
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();
              const successText = /تم\s+(?:تغيير|تحديث)\s+(?:كلمة\s+)?(?:المرور|السر)(?:\s+بنجاح)?|تم\s+تغيير\s+كلمة\s+المرور|password\s+(?:changed|updated)(?:\s+successfully)?|your\s+password\s+(?:was\s+)?changed|password\s+has\s+been\s+changed/i;
              const notificationNodes = Array.from(document.querySelectorAll(
                '[role="alert"],[role="status"],[aria-live],.snackbar,.toast,.notification,.alert,.banner,[class*="snackbar"],[class*="toast"],[class*="notification"],[class*="alert"],[class*="banner"]'
              )).filter(visible);
              const greenNodes = Array.from(document.querySelectorAll('body *')).filter(el => {
                if (!visible(el)) return false;
                const text = normalizeSuccessText(el.innerText || el.textContent || el.getAttribute('aria-label') || '');
                if (!text || text.length > 220) return false;
                const style = window.getComputedStyle(el);
                const bg = (style.backgroundColor || '').replace(/\s+/g, '');
                return /rgb\(?(?:25[0-9]|2[0-4][0-9]),(?:1[0-9][0-9]|[0-9]{1,2}),(?:7[0-9]|[0-5][0-9])\)?/i.test(bg) ||
                       /rgb\(?(?:0,)?(?:12[0-9]|1[0-1][0-9]),(?:14[0-9]|1[0-9][0-9]),(?:7[0-9]|[0-5][0-9])\)?/i.test(bg);
              });
              const liveText = notificationNodes.concat(greenNodes)
                .map(el => normalizeSuccessText(el.innerText || el.textContent || el.getAttribute('aria-label') || ''))
                .filter(Boolean)
                .join(' ');
              const normalizedPageText = normalizeSuccessText(pageText);
              // window-scoped locks disappear when Google navigates/reloads the
              // password page. sessionStorage survives that navigation, preventing
              // a second fill/click while the first request is still awaiting Google's response.
              // Lock the password submission synchronously in page storage before any
              // second evaluateJavascript callback can reach the fields. This prevents
              // two concurrent injections from both seeing an unlocked form and filling
              // / clicking it twice.
              const submitLocked = window.__emPasswordAutomationSubmitted === true ||
                    (() => { try { return sessionStorage.getItem('__emPasswordFlowSubmitted') === '1'; } catch(e) { return false; } })();
              const reauthLocked = window.__emPasswordAutomationReauthSubmitted === true ||
                    (() => { try { return sessionStorage.getItem('__emPasswordFlowReauth') === '1'; } catch(e) { return false; } })();
              const errorText = /حدث خطأ(?: أثناء تغيير كلمة المرور| في تغيير كلمة المرور)?|حدثت مشكلة(?: أثناء تغيير كلمة المرور| في تغيير كلمة المرور)?|تعذر تغيير كلمة المرور|تعذر تحديث كلمة المرور|لم نتمكن من تغيير كلمة المرور|لم يتم تغيير كلمة المرور|فشل تغيير كلمة المرور|حدث خطأ ما|هناك خطأ ما|هناك مشكلة(?: أثناء تغيير كلمة المرور| في تغيير كلمة المرور)?|حدثت مشكلة ما|something went wrong(?: while changing your password)?|there was a problem(?: changing your password)?|couldn['\\'’]t change your password|could not change your password|unable to change your password|we couldn['\\'’]t change your password|password change failed|failed to change your password|password could not be changed/i;

              if (successText.test(normalizedPageText) || successText.test(liveText)) return 'success';
              if (${passwordChangeSubmitted} || submitLocked) {
                if (errorText.test(pageText)) {
                  window.__emPasswordAutomationSubmitted = false;
                  try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); } catch(e) {}
                  return 'retry_error';
                }
                return 'waiting_success';
              }

              if (passwords.length >= 3) {
                // Acquire the lock BEFORE touching the fields. If another injected
                // script is already in flight, it must see this lock and stop.
                try { if (sessionStorage.getItem('__emPasswordFlowSubmitted') === '1') return 'waiting_success'; sessionStorage.setItem('__emPasswordFlowSubmitted', '1'); } catch(e) { if (window.__emPasswordAutomationSubmitted === true) return 'waiting_success'; window.__emPasswordAutomationSubmitted = true; }
                window.__emPasswordAutomationSubmitted = true;
                setValue(passwords[0], currentPassword);
                setValue(passwords[1], newPassword);
                setValue(passwords[2], newPassword);
                const submit = buttons.find(b => /change|تغيير|حفظ|save/.test(buttonText(b))) || buttons.find(b => b.type === 'submit');
                if (submit && !submit.disabled) {
                  submit.click();
                  return 'submitted';
                }
                return 'filled';
              }

              if (passwords.length === 2) {
                // Acquire the lock BEFORE filling or clicking.
                try { if (sessionStorage.getItem('__emPasswordFlowSubmitted') === '1') return 'waiting_success'; sessionStorage.setItem('__emPasswordFlowSubmitted', '1'); } catch(e) { if (window.__emPasswordAutomationSubmitted === true) return 'waiting_success'; window.__emPasswordAutomationSubmitted = true; }
                window.__emPasswordAutomationSubmitted = true;
                setValue(passwords[0], newPassword);
                setValue(passwords[1], newPassword);
                const submit = buttons.find(b => /change|تغيير|حفظ|save/.test(buttonText(b))) || buttons.find(b => b.type === 'submit');
                if (submit && !submit.disabled) {
                  submit.click();
                  return 'submitted';
                }
                return 'filled';
              }

              if (passwords.length === 1) {
                if (reauthLocked || ${passwordReauthSubmitted}) return 'waiting_reauth';
                setValue(passwords[0], currentPassword);
                const next = buttons.find(b => /next|التالي|continue|متابعة/.test(buttonText(b))) || buttons.find(b => b.type === 'submit');
                if (next && !next.disabled) {
                  window.__emPasswordAutomationReauthSubmitted = true;
                  try { sessionStorage.setItem('__emPasswordFlowReauth', '1'); } catch(e) {}
                  return (next.click(), 'reauth');
                }
                return 'one_password';
              }
              return 'waiting';
            })();
        """.trimIndent()

        view.evaluateJavascript(script) { result ->
            when (result?.trim('"')) {
                "submitted" -> {
                    // After submitting, never press the change button again unless
                    // Google explicitly reports a password-change error.
                    passwordChangeSubmitted = true
                    view.postDelayed({ if (passwordAutomationActive) injectPasswordChangeScript(view) }, 180L)
                }
                "retry_error" -> {
                    // Google explicitly reported that the password change failed.
                    // Only in this case is another attempt allowed.
                    passwordChangeSubmitted = false
                    passwordReauthSubmitted = false
                    passwordFlowStartedForCurrentAutomation = false
                    view.evaluateJavascript("try { sessionStorage.removeItem('__emPasswordFlowSubmitted'); sessionStorage.removeItem('__emPasswordFlowReauth'); } catch(e) {}", null)
                    view.postDelayed({ if (passwordAutomationActive) injectPasswordChangeScript(view) }, 180L)
                }
                "filled", "reauth", "one_password", "waiting_reauth", "waiting", "waiting_success" -> {
                    if (result?.trim('"') == "reauth") passwordReauthSubmitted = true
                    view.postDelayed({ if (passwordAutomationActive) injectPasswordChangeScript(view) }, 180L)
                }
                "success" -> completePasswordAutomationFromSuccess(view)
            }
        }
    }

    private data class TimeZoneOption(
        val country: String,
        val code: String,
        val city: String,
        val zoneId: String
    )

    private fun showTimeZoneDialog() {
        val zones = listOf(
            TimeZoneOption("أفغانستان", "AF", "كابول", "Asia/Kabul"),
            TimeZoneOption("ألبانيا", "AL", "تيرانا", "Europe/Tirane"),
            TimeZoneOption("الجزائر", "DZ", "الجزائر", "Africa/Algiers"),
            TimeZoneOption("أندورا", "AD", "أندورا لا فيلا", "Europe/Andorra"),
            TimeZoneOption("أنغولا", "AO", "لواندا", "Africa/Luanda"),
            TimeZoneOption("أنتيغوا وبربودا", "AG", "سانت جونز", "America/Antigua"),
            TimeZoneOption("الأرجنتين", "AR", "بوينس آيرس", "America/Argentina/Buenos_Aires"),
            TimeZoneOption("أرمينيا", "AM", "يريفان", "Asia/Yerevan"),
            TimeZoneOption("أستراليا", "AU", "سيدني", "Australia/Sydney"),
            TimeZoneOption("النمسا", "AT", "فيينا", "Europe/Vienna"),
            TimeZoneOption("أذربيجان", "AZ", "باكو", "Asia/Baku"),
            TimeZoneOption("الباهاما", "BS", "ناساو", "America/Nassau"),
            TimeZoneOption("البحرين", "BH", "المنامة", "Asia/Bahrain"),
            TimeZoneOption("بنغلاديش", "BD", "دكا", "Asia/Dhaka"),
            TimeZoneOption("بربادوس", "BB", "بريدجتاون", "America/Barbados"),
            TimeZoneOption("بيلاروسيا", "BY", "مينسك", "Europe/Minsk"),
            TimeZoneOption("بلجيكا", "BE", "بروكسل", "Europe/Brussels"),
            TimeZoneOption("بليز", "BZ", "بلموبان", "America/Belize"),
            TimeZoneOption("بنين", "BJ", "بورتو نوفو", "Africa/Porto-Novo"),
            TimeZoneOption("بوتان", "BT", "تيمفو", "Asia/Thimphu"),
            TimeZoneOption("بوليفيا", "BO", "لاباز", "America/La_Paz"),
            TimeZoneOption("البوسنة والهرسك", "BA", "سراييفو", "Europe/Sarajevo"),
            TimeZoneOption("بوتسوانا", "BW", "غابورون", "Africa/Gaborone"),
            TimeZoneOption("البرازيل", "BR", "برازيليا", "America/Sao_Paulo"),
            TimeZoneOption("بروناي", "BN", "بندر سري بكاوان", "Asia/Brunei"),
            TimeZoneOption("بلغاريا", "BG", "صوفيا", "Europe/Sofia"),
            TimeZoneOption("بوركينا فاسو", "BF", "واغادوغو", "Africa/Ouagadougou"),
            TimeZoneOption("بوروندي", "BI", "بوجومبورا", "Africa/Bujumbura"),
            TimeZoneOption("الرأس الأخضر", "CV", "برايا", "Atlantic/Cape_Verde"),
            TimeZoneOption("كمبوديا", "KH", "بنوم بنه", "Asia/Phnom_Penh"),
            TimeZoneOption("الكاميرون", "CM", "ياوندي", "Africa/Douala"),
            TimeZoneOption("كندا", "CA", "تورونتو", "America/Toronto"),
            TimeZoneOption("جمهورية أفريقيا الوسطى", "CF", "بانغي", "Africa/Bangui"),
            TimeZoneOption("تشاد", "TD", "نجامينا", "Africa/Ndjamena"),
            TimeZoneOption("تشيلي", "CL", "سانتياغو", "America/Santiago"),
            TimeZoneOption("الصين", "CN", "بكين", "Asia/Shanghai"),
            TimeZoneOption("كولومبيا", "CO", "بوغوتا", "America/Bogota"),
            TimeZoneOption("جزر القمر", "KM", "موروني", "Indian/Comoro"),
            TimeZoneOption("الكونغو", "CG", "برازافيل", "Africa/Brazzaville"),
            TimeZoneOption("جمهورية الكونغو الديمقراطية", "CD", "كينشاسا", "Africa/Kinshasa"),
            TimeZoneOption("كوستاريكا", "CR", "سان خوسيه", "America/Costa_Rica"),
            TimeZoneOption("ساحل العاج", "CI", "أبيدجان", "Africa/Abidjan"),
            TimeZoneOption("كرواتيا", "HR", "زغرب", "Europe/Zagreb"),
            TimeZoneOption("كوبا", "CU", "هافانا", "America/Havana"),
            TimeZoneOption("قبرص", "CY", "نيقوسيا", "Asia/Nicosia"),
            TimeZoneOption("التشيك", "CZ", "براغ", "Europe/Prague"),
            TimeZoneOption("الدنمارك", "DK", "كوبنهاغن", "Europe/Copenhagen"),
            TimeZoneOption("جيبوتي", "DJ", "جيبوتي", "Africa/Djibouti"),
            TimeZoneOption("دومينيكا", "DM", "روسو", "America/Dominica"),
            TimeZoneOption("جمهورية الدومينيكان", "DO", "سانتو دومينغو", "America/Santo_Domingo"),
            TimeZoneOption("الإكوادور", "EC", "كيتو", "America/Guayaquil"),
            TimeZoneOption("مصر", "EG", "القاهرة", "Africa/Cairo"),
            TimeZoneOption("السلفادور", "SV", "سان سلفادور", "America/El_Salvador"),
            TimeZoneOption("غينيا الاستوائية", "GQ", "مالابو", "Africa/Malabo"),
            TimeZoneOption("إريتريا", "ER", "أسمرة", "Africa/Asmara"),
            TimeZoneOption("إستونيا", "EE", "تالين", "Europe/Tallinn"),
            TimeZoneOption("إسواتيني", "SZ", "مباباني", "Africa/Mbabane"),
            TimeZoneOption("إثيوبيا", "ET", "أديس أبابا", "Africa/Addis_Ababa"),
            TimeZoneOption("فيجي", "FJ", "سوفا", "Pacific/Fiji"),
            TimeZoneOption("فنلندا", "FI", "هلسنكي", "Europe/Helsinki"),
            TimeZoneOption("فرنسا", "FR", "باريس", "Europe/Paris"),
            TimeZoneOption("الغابون", "GA", "ليبرفيل", "Africa/Libreville"),
            TimeZoneOption("غامبيا", "GM", "بانجول", "Africa/Banjul"),
            TimeZoneOption("جورجيا", "GE", "تبليسي", "Asia/Tbilisi"),
            TimeZoneOption("ألمانيا", "DE", "برلين", "Europe/Berlin"),
            TimeZoneOption("غانا", "GH", "أكرا", "Africa/Accra"),
            TimeZoneOption("اليونان", "GR", "أثينا", "Europe/Athens"),
            TimeZoneOption("غرينادا", "GD", "سانت جورجز", "America/Grenada"),
            TimeZoneOption("غواتيمالا", "GT", "غواتيمالا سيتي", "America/Guatemala"),
            TimeZoneOption("غينيا", "GN", "كوناكري", "Africa/Conakry"),
            TimeZoneOption("غينيا بيساو", "GW", "بيساو", "Africa/Bissau"),
            TimeZoneOption("غيانا", "GY", "جورج تاون", "America/Guyana"),
            TimeZoneOption("هايتي", "HT", "بورت أو برنس", "America/Port-au-Prince"),
            TimeZoneOption("هندوراس", "HN", "تيغوسيغالبا", "America/Tegucigalpa"),
            TimeZoneOption("المجر", "HU", "بودابست", "Europe/Budapest"),
            TimeZoneOption("آيسلندا", "IS", "ريكيافيك", "Atlantic/Reykjavik"),
            TimeZoneOption("الهند", "IN", "نيودلهي", "Asia/Kolkata"),
            TimeZoneOption("إندونيسيا", "ID", "جاكرتا", "Asia/Jakarta"),
            TimeZoneOption("إيران", "IR", "طهران", "Asia/Tehran"),
            TimeZoneOption("العراق", "IQ", "بغداد", "Asia/Baghdad"),
            TimeZoneOption("أيرلندا", "IE", "دبلن", "Europe/Dublin"),
            TimeZoneOption("إيطاليا", "IT", "روما", "Europe/Rome"),
            TimeZoneOption("جامايكا", "JM", "كينغستون", "America/Jamaica"),
            TimeZoneOption("اليابان", "JP", "طوكيو", "Asia/Tokyo"),
            TimeZoneOption("الأردن", "JO", "عمّان", "Asia/Amman"),
            TimeZoneOption("كازاخستان", "KZ", "أستانا", "Asia/Almaty"),
            TimeZoneOption("كينيا", "KE", "نيروبي", "Africa/Nairobi"),
            TimeZoneOption("كيريباتي", "KI", "تاراوا", "Pacific/Tarawa"),
            TimeZoneOption("الكويت", "KW", "الكويت", "Asia/Kuwait"),
            TimeZoneOption("قيرغيزستان", "KG", "بيشكيك", "Asia/Bishkek"),
            TimeZoneOption("لاوس", "LA", "فيينتيان", "Asia/Vientiane"),
            TimeZoneOption("لاتفيا", "LV", "ريغا", "Europe/Riga"),
            TimeZoneOption("لبنان", "LB", "بيروت", "Asia/Beirut"),
            TimeZoneOption("ليسوتو", "LS", "ماسيرو", "Africa/Maseru"),
            TimeZoneOption("ليبيريا", "LR", "مونروفيا", "Africa/Monrovia"),
            TimeZoneOption("ليبيا", "LY", "طرابلس", "Africa/Tripoli"),
            TimeZoneOption("ليختنشتاين", "LI", "فادوتس", "Europe/Vaduz"),
            TimeZoneOption("ليتوانيا", "LT", "فيلنيوس", "Europe/Vilnius"),
            TimeZoneOption("لوكسمبورغ", "LU", "لوكسمبورغ", "Europe/Luxembourg"),
            TimeZoneOption("مدغشقر", "MG", "أنتاناناريفو", "Indian/Antananarivo"),
            TimeZoneOption("ملاوي", "MW", "ليلونغوي", "Africa/Blantyre"),
            TimeZoneOption("ماليزيا", "MY", "كوالالمبور", "Asia/Kuala_Lumpur"),
            TimeZoneOption("المالديف", "MV", "ماليه", "Indian/Maldives"),
            TimeZoneOption("مالي", "ML", "باماكو", "Africa/Bamako"),
            TimeZoneOption("مالطا", "MT", "فاليتا", "Europe/Malta"),
            TimeZoneOption("جزر مارشال", "MH", "ماجورو", "Pacific/Majuro"),
            TimeZoneOption("موريتانيا", "MR", "نواكشوط", "Africa/Nouakchott"),
            TimeZoneOption("موريشيوس", "MU", "بورت لويس", "Indian/Mauritius"),
            TimeZoneOption("المكسيك", "MX", "مكسيكو سيتي", "America/Mexico_City"),
            TimeZoneOption("ميكرونيزيا", "FM", "باليكير", "Pacific/Pohnpei"),
            TimeZoneOption("مولدوفا", "MD", "كيشيناو", "Europe/Chisinau"),
            TimeZoneOption("موناكو", "MC", "موناكو", "Europe/Monaco"),
            TimeZoneOption("منغوليا", "MN", "أولان باتور", "Asia/Ulaanbaatar"),
            TimeZoneOption("الجبل الأسود", "ME", "بودغوريتسا", "Europe/Podgorica"),
            TimeZoneOption("المغرب", "MA", "الرباط", "Africa/Casablanca"),
            TimeZoneOption("موزمبيق", "MZ", "مابوتو", "Africa/Maputo"),
            TimeZoneOption("ميانمار", "MM", "نايبيداو", "Asia/Yangon"),
            TimeZoneOption("ناميبيا", "NA", "ويندهوك", "Africa/Windhoek"),
            TimeZoneOption("ناورو", "NR", "يارين", "Pacific/Nauru"),
            TimeZoneOption("نيبال", "NP", "كاتماندو", "Asia/Kathmandu"),
            TimeZoneOption("هولندا", "NL", "أمستردام", "Europe/Amsterdam"),
            TimeZoneOption("نيوزيلندا", "NZ", "أوكلاند", "Pacific/Auckland"),
            TimeZoneOption("نيكاراغوا", "NI", "ماناغوا", "America/Managua"),
            TimeZoneOption("النيجر", "NE", "نيامي", "Africa/Niamey"),
            TimeZoneOption("نيجيريا", "NG", "أبوجا", "Africa/Lagos"),
            TimeZoneOption("كوريا الشمالية", "KP", "بيونغ يانغ", "Asia/Pyongyang"),
            TimeZoneOption("مقدونيا الشمالية", "MK", "سكوبيه", "Europe/Skopje"),
            TimeZoneOption("النرويج", "NO", "أوسلو", "Europe/Oslo"),
            TimeZoneOption("عُمان", "OM", "مسقط", "Asia/Muscat"),
            TimeZoneOption("باكستان", "PK", "إسلام آباد", "Asia/Karachi"),
            TimeZoneOption("بالاو", "PW", "نغيرولمود", "Pacific/Palau"),
            TimeZoneOption("فلسطين", "PS", "القدس", "Asia/Gaza"),
            TimeZoneOption("بنما", "PA", "بنما سيتي", "America/Panama"),
            TimeZoneOption("بابوا غينيا الجديدة", "PG", "بورت مورسبي", "Pacific/Port_Moresby"),
            TimeZoneOption("باراغواي", "PY", "أسونسيون", "America/Asuncion"),
            TimeZoneOption("بيرو", "PE", "ليما", "America/Lima"),
            TimeZoneOption("الفلبين", "PH", "مانيلا", "Asia/Manila"),
            TimeZoneOption("بولندا", "PL", "وارسو", "Europe/Warsaw"),
            TimeZoneOption("البرتغال", "PT", "لشبونة", "Europe/Lisbon"),
            TimeZoneOption("قطر", "QA", "الدوحة", "Asia/Qatar"),
            TimeZoneOption("رومانيا", "RO", "بوخارست", "Europe/Bucharest"),
            TimeZoneOption("روسيا", "RU", "موسكو", "Europe/Moscow"),
            TimeZoneOption("رواندا", "RW", "كيغالي", "Africa/Kigali"),
            TimeZoneOption("سانت كيتس ونيفيس", "KN", "باستير", "America/St_Kitts"),
            TimeZoneOption("سانت لوسيا", "LC", "كاستريس", "America/St_Lucia"),
            TimeZoneOption("سانت فنسنت والغرينادين", "VC", "كينغستاون", "America/St_Vincent"),
            TimeZoneOption("ساموا", "WS", "أبيا", "Pacific/Apia"),
            TimeZoneOption("سان مارينو", "SM", "سان مارينو", "Europe/San_Marino"),
            TimeZoneOption("ساو تومي وبرينسيبي", "ST", "ساو تومي", "Africa/Sao_Tome"),
            TimeZoneOption("السعودية", "SA", "الرياض", "Asia/Riyadh"),
            TimeZoneOption("السنغال", "SN", "داكار", "Africa/Dakar"),
            TimeZoneOption("صربيا", "RS", "بلغراد", "Europe/Belgrade"),
            TimeZoneOption("سيشل", "SC", "فيكتوريا", "Indian/Mahe"),
            TimeZoneOption("سيراليون", "SL", "فريتاون", "Africa/Freetown"),
            TimeZoneOption("سنغافورة", "SG", "سنغافورة", "Asia/Singapore"),
            TimeZoneOption("سلوفاكيا", "SK", "براتيسلافا", "Europe/Bratislava"),
            TimeZoneOption("سلوفينيا", "SI", "ليوبليانا", "Europe/Ljubljana"),
            TimeZoneOption("جزر سليمان", "SB", "هونيارا", "Pacific/Guadalcanal"),
            TimeZoneOption("الصومال", "SO", "مقديشو", "Africa/Mogadishu"),
            TimeZoneOption("جنوب أفريقيا", "ZA", "جوهانسبرغ", "Africa/Johannesburg"),
            TimeZoneOption("كوريا الجنوبية", "KR", "سيول", "Asia/Seoul"),
            TimeZoneOption("جنوب السودان", "SS", "جوبا", "Africa/Juba"),
            TimeZoneOption("إسبانيا", "ES", "مدريد", "Europe/Madrid"),
            TimeZoneOption("سريلانكا", "LK", "كولومبو", "Asia/Colombo"),
            TimeZoneOption("السودان", "SD", "الخرطوم", "Africa/Khartoum"),
            TimeZoneOption("سورينام", "SR", "باراماريبو", "America/Paramaribo"),
            TimeZoneOption("السويد", "SE", "ستوكهولم", "Europe/Stockholm"),
            TimeZoneOption("سويسرا", "CH", "زيورخ", "Europe/Zurich"),
            TimeZoneOption("سوريا", "SY", "دمشق", "Asia/Damascus"),
            TimeZoneOption("تايوان", "TW", "تايبيه", "Asia/Taipei"),
            TimeZoneOption("طاجيكستان", "TJ", "دوشنبه", "Asia/Dushanbe"),
            TimeZoneOption("تنزانيا", "TZ", "دار السلام", "Africa/Dar_es_Salaam"),
            TimeZoneOption("تايلاند", "TH", "بانكوك", "Asia/Bangkok"),
            TimeZoneOption("تيمور الشرقية", "TL", "ديلي", "Asia/Dili"),
            TimeZoneOption("توجو", "TG", "لومي", "Africa/Lome"),
            TimeZoneOption("تونغا", "TO", "نوكو ألوفا", "Pacific/Tongatapu"),
            TimeZoneOption("ترينيداد وتوباغو", "TT", "بورت أوف سبين", "America/Port_of_Spain"),
            TimeZoneOption("تونس", "TN", "تونس", "Africa/Tunis"),
            TimeZoneOption("تركيا", "TR", "إسطنبول", "Europe/Istanbul"),
            TimeZoneOption("تركمانستان", "TM", "عشق آباد", "Asia/Ashgabat"),
            TimeZoneOption("توفالو", "TV", "فونافوتي", "Pacific/Funafuti"),
            TimeZoneOption("أوغندا", "UG", "كمبالا", "Africa/Kampala"),
            TimeZoneOption("أوكرانيا", "UA", "كييف", "Europe/Kyiv"),
            TimeZoneOption("الإمارات", "AE", "دبي", "Asia/Dubai"),
            TimeZoneOption("المملكة المتحدة", "GB", "لندن", "Europe/London"),
            TimeZoneOption("الولايات المتحدة", "US", "نيويورك", "America/New_York"),
            TimeZoneOption("أوروغواي", "UY", "مونتيفيديو", "America/Montevideo"),
            TimeZoneOption("أوزبكستان", "UZ", "طشقند", "Asia/Tashkent"),
            TimeZoneOption("فانواتو", "VU", "بورت فيلا", "Pacific/Efate"),
            TimeZoneOption("الفاتيكان", "VA", "الفاتيكان", "Europe/Vatican"),
            TimeZoneOption("فنزويلا", "VE", "كاراكاس", "America/Caracas"),
            TimeZoneOption("فيتنام", "VN", "مدينة هو تشي منه", "Asia/Ho_Chi_Minh"),
            TimeZoneOption("اليمن", "YE", "صنعاء", "Asia/Aden"),
            TimeZoneOption("زامبيا", "ZM", "لوساكا", "Africa/Lusaka"),
            TimeZoneOption("زيمبابوي", "ZW", "هراري", "Africa/Harare"),
        ).sortedBy { it.city }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
        }

        val header = TextView(this).apply {
            text = "تحديد المنطقة الزمنية"
            textSize = 20f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(if (darkModeEnabled) Color.WHITE else Color.BLACK)
            setPadding(dp(16), dp(18), dp(16), dp(18))
        }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(68)))

        val searchBox = android.widget.EditText(this).apply {
            textSize = 16f
            setTextColor(if (darkModeEnabled) Color.WHITE else Color.BLACK)
            setHintTextColor(if (darkModeEnabled) Color.LTGRAY else Color.GRAY)
            hint = "بحث عن المنطقة الزمنية"
            setPadding(dp(14), 0, dp(14), 0)
            background = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.bg_address_bar)
            isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(searchBox, LinearLayout.LayoutParams(-1, dp(40)).apply {
            marginStart = dp(10)
            marginEnd = dp(10)
            bottomMargin = dp(10)
        })

        val list = android.widget.ListView(this).apply {
            divider = android.graphics.drawable.ColorDrawable(if (darkModeEnabled) Color.rgb(55, 55, 55) else Color.rgb(225, 225, 225))
            dividerHeight = dp(1)
            setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        val dialog = AlertDialog.Builder(this).setView(root).create()
        val filteredZones = zones.toMutableList()

        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = filteredZones.size
            override fun getItem(position: Int) = filteredZones[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val option = filteredZones[position]
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(18), dp(10), dp(18), dp(10))
                    setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
                }

                val arrow = TextView(this@MainActivity).apply {
                    text = "‹"
                    textSize = 34f
                    gravity = Gravity.CENTER
                    setTextColor(if (darkModeEnabled) Color.LTGRAY else Color.LTGRAY)
                }
                row.addView(arrow, LinearLayout.LayoutParams(dp(42), -1))

                val textBox = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val city = TextView(this@MainActivity).apply {
                    text = option.city
                    textSize = 17f
                    gravity = Gravity.END
                    setTextColor(if (darkModeEnabled) Color.WHITE else Color.BLACK)
                }
                val offset = TextView(this@MainActivity).apply {
                    text = "غرينتش ${formatGmtOffset(option.zoneId)}"
                    textSize = 14f
                    gravity = Gravity.END
                    setTextColor(if (darkModeEnabled) Color.LTGRAY else Color.DKGRAY)
                }
                textBox.addView(city, LinearLayout.LayoutParams(-1, dp(30)))
                textBox.addView(offset, LinearLayout.LayoutParams(-1, dp(25)))
                row.addView(textBox, LinearLayout.LayoutParams(0, -1, 1f))
                return row
            }
        }
        list.adapter = adapter

        searchBox.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString()?.trim()?.lowercase(java.util.Locale.ROOT).orEmpty()
                filteredZones.clear()
                if (query.isEmpty()) {
                    filteredZones.addAll(zones)
                } else {
                    filteredZones.addAll(zones.filter { option ->
                        option.country.lowercase(java.util.Locale.ROOT).contains(query) ||
                        option.city.lowercase(java.util.Locale.ROOT).contains(query) ||
                        option.zoneId.lowercase(java.util.Locale.ROOT).contains(query) ||
                        option.code.lowercase(java.util.Locale.ROOT).contains(query)
                    })
                }
                adapter.notifyDataSetChanged()
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        list.setOnItemClickListener { _, _, position, _ ->
            val selected = filteredZones[position]
            countryCode = selected.code
            countryName = selected.country
            timeZoneId = selected.zoneId
            timeZoneCity = selected.city
            timeZoneMenuItem.text = timeZoneMenuLabel()
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_COUNTRY_CODE, countryCode)
                .putString(KEY_COUNTRY_NAME, countryName)
                .putString(KEY_TIME_ZONE, timeZoneId)
                .putString(KEY_TIME_ZONE_CITY, timeZoneCity)
                .apply()
            dialog.dismiss()
            currentWebView()?.loadUrl(homeUrl())
        }

        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(),
            (resources.displayMetrics.heightPixels * 0.90f).toInt())
    }

    private fun showLanguageDialog() {
        val options = arrayOf("English", "العربية")
        val checked = if (browserLanguage == "en") 0 else 1
        AlertDialog.Builder(this)
            .setTitle("Language")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                val selected = if (which == 0) "en" else "ar"
                if (selected != browserLanguage) {
                    browserLanguage = selected
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putString(KEY_LANGUAGE, browserLanguage)
                        .apply()
                    val current = currentWebView()
                    val currentUrl = current?.url
                    if (!currentUrl.isNullOrBlank()) {
                        current.loadUrl(withSelectedLanguage(currentUrl))
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun timeZoneMenuLabel(): CharSequence {
        val city = timeZoneId.substringAfterLast('/').replace('_', ' ').lowercase(java.util.Locale.ENGLISH)
        val label = "Time Zone ($city)"
        val styled = SpannableString(label)
        val start = label.indexOf('(')
        if (start >= 0) {
            styled.setSpan(
                RelativeSizeSpan(0.82f),
                start,
                label.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        return styled
    }

    private fun formatGmtOffset(zoneId: String): String {
        val offsetMillis = TimeZone.getTimeZone(zoneId).getOffset(System.currentTimeMillis())
        val totalMinutes = offsetMillis / 60000
        val sign = if (totalMinutes >= 0) "+" else "-"
        val absoluteMinutes = kotlin.math.abs(totalMinutes)
        val hours = absoluteMinutes / 60
        val minutes = absoluteMinutes % 60
        return String.format(java.util.Locale.US, "%s%02d:%02d", sign, hours, minutes)
    }

    private fun homeUrl(): String = "https://accounts.google.com/?hl=$browserLanguage&gl=$countryCode"

    private fun captureTabThumbnail(tab: BrowserTab): Bitmap? {
        val webView = tab.webView
        if (webView.width <= 0 || webView.height <= 0) return tab.thumbnail
        return try {
            // Keep enough resolution for the large Chrome-style tab cards.
            val maxWidth = dp(600)
            val ratio = maxWidth.toFloat() / webView.width.toFloat()
            val bitmap = Bitmap.createBitmap(
                maxWidth,
                (webView.height * ratio).toInt().coerceAtLeast(dp(180)),
                Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(bitmap)
            canvas.scale(ratio, ratio)
            webView.draw(canvas)
            bitmap
        } catch (_: Throwable) {
            tab.thumbnail
        }
    }

    private fun showTabSwitcher() {
        if (tabs.isNotEmpty()) {
            tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
        }

        // Match the reference: a light full-screen Chrome-style tab switcher,
        // with two large cards per row and generous outer/inner spacing.
        val backgroundColor = if (darkModeEnabled) Color.rgb(32, 33, 36) else Color.rgb(250, 250, 250)
        val cardColor = if (darkModeEnabled) Color.rgb(45, 46, 49) else Color.WHITE
        val textColor = if (darkModeEnabled) Color.WHITE else Color.rgb(45, 45, 45)
        val secondaryColor = if (darkModeEnabled) Color.LTGRAY else Color.rgb(80, 80, 80)
        val activeGreen = Color.rgb(17, 107, 55)

        val dialogRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(28), dp(8), dp(28), dp(14))
            setBackgroundColor(backgroundColor)
        }
        lateinit var dialog: AlertDialog

        // Chrome-like top controls.
        val topBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        val more = TextView(this).apply {
            text = "⋮"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(textColor)
            setPadding(0, 0, 0, dp(4))
            setOnClickListener { dialog.dismiss(); drawerLayout.openDrawer(Gravity.END) }
        }
        topBar.addView(more, LinearLayout.LayoutParams(dp(44), dp(58)))

        // Keep the tab counter visually centered in the top bar after removing
        // the extra grid button.
        val leftSpacer = View(this)
        topBar.addView(leftSpacer, LinearLayout.LayoutParams(0, dp(58), 1f))

        val countPill = TextView(this).apply {
            text = tabs.size.toString()
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(textColor)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(9).toFloat()
                setColor(if (darkModeEnabled) Color.rgb(58, 59, 62) else Color.WHITE)
                setStroke(dp(1), if (darkModeEnabled) Color.rgb(75, 76, 79) else Color.rgb(235, 235, 235))
            }
        }
        topBar.addView(countPill, LinearLayout.LayoutParams(dp(26), dp(26)).apply {
            gravity = Gravity.CENTER_VERTICAL
            leftMargin = dp(2)
        })

        val spacer = View(this)
        topBar.addView(spacer, LinearLayout.LayoutParams(0, dp(58), 1f))

        val add = TextView(this).apply {
            text = "+"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(Color.rgb(16, 123, 61))
            }
            setOnClickListener {
                dialog.dismiss()
                addTab(homeUrl())
            }
        }
        topBar.addView(add, LinearLayout.LayoutParams(dp(44), dp(44)))
        dialogRoot.addView(topBar, LinearLayout.LayoutParams(-1, dp(58)))

        val search = EditText(this).apply {
            hint = "البحث في علامات التبويب"
            textSize = 15f
            setSingleLine(true)
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            setTextColor(textColor)
            setHintTextColor(if (darkModeEnabled) Color.LTGRAY else Color.rgb(90, 90, 90))
            setPadding(dp(14), 0, dp(14), 0)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(35).toFloat()
                setColor(if (darkModeEnabled) Color.rgb(55, 56, 59) else Color.rgb(232, 232, 232))
            }
        }
        dialogRoot.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(2)
            leftMargin = dp(14)
            rightMargin = dp(14)
            bottomMargin = dp(12)
        })

        val grid = android.widget.GridLayout(this).apply {
            // Two columns so six tab cards (2 x 3) fit on the screen.
            columnCount = 2
            useDefaultMargins = false
            alignmentMode = android.widget.GridLayout.ALIGN_BOUNDS
        }
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(grid, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        dialogRoot.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun refreshGrid(filter: String = "") {
            grid.removeAllViews()
            val query = filter.trim().lowercase(java.util.Locale.getDefault())
            val visible = tabs.mapIndexedNotNull { index, tab ->
                val title = tab.title.ifBlank { "New tab" }
                if (query.isBlank() || title.lowercase(java.util.Locale.getDefault()).contains(query)) index to tab else null
            }

            // Six cards should be visible at once: 2 columns x 3 rows.
            // Keep compact gaps and let each card fill one half of the grid.
            val horizontalGap = dp(10)
            val verticalGap = dp(12)
            val availableWidth = resources.displayMetrics.widthPixels - dp(56)
            val cardWidth = ((availableWidth - horizontalGap) / 2).coerceAtLeast(dp(1))
            val cardHeight = dp(250)

            visible.forEachIndexed { position, pair ->
                val index = pair.first
                val tab = pair.second
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(0, 0, 0, 0)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(24).toFloat()
                        setColor(cardColor)
                        setStroke(
                            if (index == activeTab) dp(3) else dp(1),
                            if (index == activeTab) activeGreen
                            else if (darkModeEnabled) Color.rgb(75, 76, 79) else Color.rgb(225, 225, 225)
                        )
                    }
                    elevation = dp(1).toFloat()
                    clipToOutline = true
                    isClickable = true
                    isFocusable = true
                    setOnClickListener {
                        if (tabs.isNotEmpty()) tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
                        activeTab = index
                        dialog.dismiss()
                        showActiveWebView()
                    }
                }

                val topRow = LinearLayout(this).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_LTR
                    setPadding(dp(8), 0, dp(8), 0)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadii = floatArrayOf(
                            dp(21).toFloat(), dp(21).toFloat(),
                            dp(21).toFloat(), dp(21).toFloat(),
                            0f, 0f, 0f, 0f
                        )
                        setColor(if (index == activeTab) activeGreen else cardColor)
                    }
                }

                val close = TextView(this).apply {
                    text = "×"
                    textSize = 28f
                    gravity = Gravity.CENTER
                    setTextColor(if (index == activeTab) Color.WHITE else secondaryColor)
                    setOnClickListener {
                        closeTab(index)
                        if (tabs.isEmpty()) {
                            dialog.dismiss()
                        } else {
                            if (activeTab >= tabs.size) activeTab = tabs.lastIndex
                            refreshGrid(search.text?.toString() ?: "")
                        }
                    }
                }
                topRow.addView(close, LinearLayout.LayoutParams(dp(34), dp(46)))

                val tabTitle = TextView(this).apply {
                    text = tab.title.ifBlank { "New tab" }
                    textSize = 15.5f
                    setTextColor(if (index == activeTab) Color.WHITE else textColor)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER_VERTICAL
                }
                topRow.addView(tabTitle, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                    leftMargin = dp(4)
                    rightMargin = dp(4)
                })

                val favicon = ImageView(this).apply {
                    val icon = tab.webView.favicon
                    if (icon != null) {
                        setImageBitmap(icon)
                    } else {
                        setImageDrawable(ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.ic_em_browser))
                    }
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                }
                topRow.addView(favicon, LinearLayout.LayoutParams(dp(32), dp(46)))
                card.addView(topRow, LinearLayout.LayoutParams(-1, dp(46)))

                val thumbnail = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setBackgroundColor(if (darkModeEnabled) Color.rgb(35, 36, 39) else Color.WHITE)
                    clipToOutline = true
                    outlineProvider = object : android.view.ViewOutlineProvider() {
                        override fun getOutline(view: View, outline: android.graphics.Outline) {
                            outline.setRoundRect(0, 0, view.width, view.height, dp(18).toFloat())
                        }
                    }
                    tab.thumbnail?.let { setImageBitmap(it) }
                    if (drawable == null) {
                        setImageDrawable(ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.ic_em_browser))
                        scaleType = ImageView.ScaleType.CENTER_INSIDE
                    }
                }
                card.addView(thumbnail, LinearLayout.LayoutParams(-1, 0, 1f).apply {
                    leftMargin = dp(5)
                    rightMargin = dp(5)
                    bottomMargin = dp(5)
                })

                val lp = android.widget.GridLayout.LayoutParams().apply {
                    width = cardWidth
                    height = cardHeight
                    columnSpec = android.widget.GridLayout.spec(position % 2, 1)
                    rowSpec = android.widget.GridLayout.spec(position / 2)
                    setMargins(
                        if (position % 2 == 0) 0 else horizontalGap / 2,
                        verticalGap / 2,
                        if (position % 2 == 1) 0 else horizontalGap / 2,
                        verticalGap / 2
                    )
                }
                grid.addView(card, lp)
            }

            // New-tab card is part of the same two-column grid.
            val newTabCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(24).toFloat()
                    setColor(cardColor)
                    setStroke(dp(1), if (darkModeEnabled) Color.rgb(75, 76, 79) else Color.rgb(225, 225, 225))
                }
                setOnClickListener {
                    dialog.dismiss()
                    addTab(homeUrl())
                }
            }
            val newIcon = ImageView(this).apply {
                setImageDrawable(ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.ic_em_browser))
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(20), dp(20), dp(20), dp(8))
            }
            newTabCard.addView(newIcon, LinearLayout.LayoutParams(-1, 0, 1f))
            val newLabel = TextView(this).apply {
                text = "علامة تبويب جديدة"
                textSize = 15f
                gravity = Gravity.CENTER
                setTextColor(textColor)
            }
            newTabCard.addView(newLabel, LinearLayout.LayoutParams(-1, dp(46)))
            val newLp = android.widget.GridLayout.LayoutParams().apply {
                width = cardWidth
                height = cardHeight
                columnSpec = android.widget.GridLayout.spec(visible.size % 2, 1)
                rowSpec = android.widget.GridLayout.spec(visible.size / 2)
                setMargins(
                    if (visible.size % 2 == 0) 0 else horizontalGap / 2,
                    verticalGap / 2,
                    if (visible.size % 2 == 1) 0 else horizontalGap / 2,
                    verticalGap / 2
                )
            }
            if (query.isBlank()) grid.addView(newTabCard, newLp)
        }

        refreshGrid()
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = refreshGrid(s?.toString() ?: "")
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        dialog = AlertDialog.Builder(this)
            .setView(dialogRoot)
            .create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(backgroundColor)
            })
            dialog.window?.setStatusBarColor(backgroundColor)
            dialog.window?.setNavigationBarColor(backgroundColor)
            dialog.window?.decorView?.systemUiVisibility = if (darkModeEnabled) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(backgroundColor)
        })
        dialog.window?.setStatusBarColor(backgroundColor)
        dialog.window?.setNavigationBarColor(backgroundColor)
        dialog.window?.decorView?.systemUiVisibility = if (darkModeEnabled) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    }

    private fun loadAddress(raw: String) {
        val input = raw.trim()
        if (input.isBlank()) return
        val url = if (android.util.Patterns.WEB_URL.matcher(input).matches() &&
            (input.startsWith("http://") || input.startsWith("https://"))) {
            input
        } else if (input.contains(".") && !input.contains(" ")) {
            "https://$input"
        } else {
            "https://www.google.com/search?q=" + android.net.Uri.encode(input)
        }
        progressAnimator?.cancel()
        pageProgress.progress = 0
        pageProgress.visibility = View.VISIBLE
        currentWebView()?.loadUrl(withSelectedLanguage(url))
        addressBar.clearFocus()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun addTab(url: String, restoredProfileName: String? = null, loadPage: Boolean = true) {
        if (tabs.isNotEmpty()) {
            tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
        }

        val profileName = restoredProfileName ?: if (tabs.isEmpty()) {
            // Keep the first tab on WebView's default profile so an existing
            // Google Account session remains available there.
            Profile.DEFAULT_PROFILE_NAME
        } else {
            // Every new tab gets its own persistent WebView profile. Cookies,
            // local storage and other site data are therefore not shared with
            // the first tab or with any other tab.
            "em_tab_${System.currentTimeMillis()}_${tabs.size}"
        }

        val webView = WebView(this)
        applyProfile(webView, profileName)
        val tab = BrowserTab(webView = webView, profileName = profileName)
        tabs.add(tab)
        // A new tab is a new automation run. Settings remain enabled, but the
        // master Automation switch controls whether execution starts automatically
        // once this tab reaches Google/Gmail.
        automationCompletedForCurrentAccount = false
        automationHasRunInCurrentGoogleSession = false
        completedAccountKey = ""
        currentAccountKey = ""
        passwordAutomationActive = false
        passwordFlowStartedForCurrentAutomation = false
        passwordChangeSubmitted = false
        recoveryEmailAutomationActive = false
        recoveryRemovalAwaitingVerification = false
        combinedAutomationWaitingForPassword = false
        recoveryDirectRetryCount = 0
        twoStepAutomationActive = false
        twoStepAutomationStage = "idle"
        twoStepAutomationRefreshDone = false
        twoStepAutomationTurnOnClicked = false
        configureWebView(webView)
        activeTab = tabs.lastIndex
        showActiveWebView()
        progressAnimator?.cancel()
        pageProgress.progress = 0
        pageProgress.visibility = View.VISIBLE
        if (loadPage) {
            webView.loadUrl(withSelectedLanguage(url))
        }
        updateChromeBar()
        saveTabsState()
    }

    private fun saveTabsState() {
        if (incognitoEnabled || tabs.isEmpty()) return

        val array = JSONArray()
        tabs.forEach { tab ->
            val url = tab.webView.url?.takeIf { it.isNotBlank() } ?: HOME_URL
            array.put(JSONObject().apply {
                put("url", url)
                put("title", tab.title)
                put("profile", tab.profileName)
            })
        }

        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_TABS_STATE, array.toString())
            .putInt(KEY_ACTIVE_TAB, activeTab.coerceIn(0, tabs.lastIndex))
            .apply()
    }

    private fun restoreTabsState(): Boolean {
        if (incognitoEnabled) return false

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val raw = prefs.getString(KEY_TABS_STATE, null) ?: return false
        return runCatching {
            val array = JSONArray(raw)
            if (array.length() == 0) return false

            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val url = item.optString("url", HOME_URL).ifBlank { HOME_URL }
                val title = item.optString("title", "New tab").ifBlank { "New tab" }
                val profile = item.optString("profile", Profile.DEFAULT_PROFILE_NAME)
                    .ifBlank { Profile.DEFAULT_PROFILE_NAME }
                addTab(url, profile, loadPage = true)
                tabs.last().title = title
            }

            activeTab = prefs.getInt(KEY_ACTIVE_TAB, 0).coerceIn(0, tabs.lastIndex)
            showActiveWebView()
            updateChromeBar()
            true
        }.getOrElse {
            prefs.edit().remove(KEY_TABS_STATE).remove(KEY_ACTIVE_TAB).apply()
            false
        }
    }

    private fun applyProfile(webView: WebView, profileName: String) {
        if (profileName == Profile.DEFAULT_PROFILE_NAME) return
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            WebViewCompat.setProfile(webView, profileName)
        }
    }

    private fun detectGoogleAccountKey(view: WebView, onDetected: (String) -> Unit) {
        val script = """
            (function() {
              const emailRe = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig;
              const priority = Array.from(document.querySelectorAll('[data-email],[aria-label],[title]'))
                .map(el => [el.getAttribute('data-email'), el.getAttribute('aria-label'), el.getAttribute('title')].filter(Boolean).join(' '))
                .filter(v => /google account|حساب google|حساب Google|account/.test(v.toLowerCase()));
              const matches = priority.join('\n').match(emailRe);
              if (matches && matches.length) return matches[0].toLowerCase();

              const dataEmail = Array.from(document.querySelectorAll('[data-email]'))
                .map(el => el.getAttribute('data-email') || '').find(v => emailRe.test(v));
              if (dataEmail) return dataEmail.toLowerCase();

              // Fallback for Gmail pages where the account menu exposes the email only in its label.
              const labels = Array.from(document.querySelectorAll('[aria-label],[title]'))
                .map(el => [el.getAttribute('aria-label'), el.getAttribute('title')].filter(Boolean).join(' '));
              const fallback = labels.join('\n').match(emailRe);
              return fallback && fallback.length ? fallback[0].toLowerCase() : '';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { result ->
            val key = result?.trim('"')?.replace("\\\"", "\"")?.trim().orEmpty()
            onDetected(key)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(webView: WebView) {
        webView.settings.apply {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            builtInZoomControls = false
            displayZoomControls = false
            domStorageEnabled = !incognitoEnabled
            databaseEnabled = !incognitoEnabled
            cacheMode = if (incognitoEnabled) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false
            allowContentAccess = false
            textZoom = zoomPercent
            userAgentString = "${WebSettings.getDefaultUserAgent(this@MainActivity)} eM-browser/2.0 (en-US)"
        }

        webView.addJavascriptInterface(inspectBridge, "EMInspect")
        webView.setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (::pageProgress.isInitialized && view === currentWebView()) {
                    val target = newProgress.coerceIn(0, 100)
                    if (target < 100) {
                        pageProgress.visibility = View.VISIBLE
                    }
                    progressAnimator?.cancel()
                    progressAnimator = ObjectAnimator.ofInt(pageProgress, "progress", pageProgress.progress, target).apply {
                        duration = if (target >= 100) 220L else 260L
                        start()
                    }
                    if (target >= 100) {
                        pageProgress.postDelayed({
                            if (pageProgress.progress >= 100) pageProgress.visibility = View.GONE
                        }, 240L)
                    }
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val target = request.url.toString()

                // Let Google's password page navigate normally. The old global
                // interception called loadUrl() from inside shouldOverrideUrlLoading(),
                // which could turn one password-page navigation into a second load.
                // During the automated Password stage this must be a single navigation.
                if ((passwordAutomationActive &&
                    (target.contains("myaccount.google.com/signinoptions/password") ||
                     target.contains("accounts.google.com/signinoptions/password"))) ||
                    (authenticatorAutomationActive && target.contains("myaccount.google.com/two-step-verification")) ||
                    (twoStepAutomationActive && (target.contains("myaccount.google.com/signinoptions/twosv") || target.contains("myaccount.google.com/two-step-verification"))) ||
                    (outAutomationActive && target.contains("myaccount.google.com/family/leave")) ||
                    supervisionAutomationActive) {
                    return false
                }

                view.loadUrl(withSelectedLanguage(target))
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.settings.textZoom = zoomPercent
                val index = tabs.indexOfFirst { it.webView === view }
                if (index >= 0) {
                    tabs[index].title = view.title?.ifBlank { "eM gmail" } ?: "eM gmail"
                    if (index == activeTab) {
                        updateChromeBar()
                        addressBar.setText(url ?: view.url ?: "")
                    }
                }
                val pageUrl = url.orEmpty()
                if (automationMasterEnabled && (supervisionAutomationActive || outAutomationActive || passwordAutomationActive || recoveryEmailAutomationActive || authenticatorAutomationActive || twoStepAutomationActive)) {
                    googleVerificationCheckPending = true
                    view.postDelayed({ injectGoogleVerification(view) }, 120L)
                }
                if (inspectModeEnabled) {
                    view.postDelayed({ if (inspectModeEnabled) installInspectMode(view) }, 120L)
                }
                if (outAutomationActive && pageUrl.contains("myaccount.google.com/family/leave")) {
                    view.postDelayed({ injectOutAutomation(view) }, 150L)
                }
                if (supervisionAutomationActive) {
                    view.postDelayed({ injectSupervisionAutomation(view) }, 120L)
                }
                // Recovery automation must stay on Google's dedicated Recovery Email page.
                // If Google lands on the recovery-phone page, never start Password from there;
                // return once to the direct Recovery Email destination instead.
                if (recoveryEmailAutomationActive &&
                    pageUrl.contains("myaccount.google.com/recovery/phone")) {
                    if (recoveryDirectRetryCount < 2) {
                        recoveryDirectRetryCount++
                        view.postDelayed({
                            if (recoveryEmailAutomationActive) view.loadUrl(withSelectedLanguage(RECOVERY_EMAIL_URL))
                        }, 250L)
                    }
                    return
                }
                val isGoogleAccountPage = pageUrl.contains("myaccount.google.com") || pageUrl.contains("accounts.google.com")
                val isGmailPage = pageUrl.contains("mail.google.com")
                if (isGoogleAccountPage || isGmailPage) {
                    lastAutomationUrl = pageUrl
                    detectGoogleAccountKey(view) { detectedKey ->
                        if (detectedKey.isNotBlank()) {
                            val accountChanged = currentAccountKey.isNotBlank() && currentAccountKey != detectedKey
                            currentAccountKey = detectedKey
                            accountKeyByWebView[view] = detectedKey
                            if (accountChanged) {
                                automationCompletedForCurrentAccount = false
                                automationHasRunInCurrentGoogleSession = false
                                completedAccountKey = ""
                            }
                        }

                        if (automationCompletedForCurrentAccount && completedAccountKey.isNotBlank() && currentAccountKey.isNotBlank() && completedAccountKey != currentAccountKey) {
                            automationCompletedForCurrentAccount = false
                            automationHasRunInCurrentGoogleSession = false
                        }

                        if (outAutomationActive) {
                            view.postDelayed({ injectOutAutomation(view) }, 150L)
                        }
                        if (supervisionAutomationActive) {
                            view.postDelayed({ injectSupervisionAutomation(view) }, 80L)
                        }
                        if (passwordAutomationActive) {
                            // Google may confirm a successful password change by navigating
                            // away from the password page before (or instead of) exposing
                            // its snackbar/banner in the WebView DOM. Once the submitted
                            // request has completed and Google lands on another account page,
                            // treat that navigation as the success signal immediately.
                            val passwordPage = pageUrl.contains("myaccount.google.com/signinoptions/password") ||
                                pageUrl.contains("accounts.google.com/signinoptions/password")
                            if (passwordChangeSubmitted && !passwordPage && isGoogleAccountPage &&
                                !pageUrl.contains("signin/challenge") && !pageUrl.contains("challenge/")) {
                                completePasswordAutomationFromSuccess(view)
                                return@detectGoogleAccountKey
                            }
                            view.postDelayed({ if (passwordAutomationActive) injectPasswordChangeScript(view) }, 250L)
                        }
                        if (recoveryEmailAutomationActive) {
                            view.postDelayed({ injectRecoveryEmailRemovalScript(view) }, 250L)
                        }
                        if (authenticatorAutomationActive) {
                            view.postDelayed({ injectAuthenticatorAutomation(view) }, 500L)
                        }
                        if (twoStepAutomationActive) {
                            // Direct flow: no reload/refresh. As soon as the 2-Step
                            // page finishes loading, press the Turn On action.
                            if (!twoStepAutomationTurnOnClicked && twoStepAutomationStage != "confirm" && twoStepAutomationStage != "waiting_success") {
                                twoStepAutomationStage = "direct_click"
                            }
                            view.postDelayed({ injectTwoStepAutomation(view) }, 350L)
                        }
                        if (automationMasterEnabled && !supervisionAutomationActive && !outAutomationActive && !passwordAutomationActive && !recoveryEmailAutomationActive && !authenticatorAutomationActive && !twoStepAutomationActive && !automationCompletedForCurrentAccount) {
                            view.postDelayed({ startConfiguredAutomationForCurrentAccount() }, 250L)
                        }
                    }
                }
                saveTabsState()
            }

            override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                // Recover from a WebView renderer crash without taking down the
                // whole browser. This is important when several tabs are open.
                val index = tabs.indexOfFirst { it.webView === view }
                if (index < 0) return true

                val urlToRestore = view.url ?: HOME_URL
                (view.parent as? ViewGroup)?.removeView(view)
                view.stopLoading()
                view.destroy()

                val replacement = WebView(this@MainActivity)
                val oldTitle = tabs[index].title
                val profileName = tabs[index].profileName
                tabs[index].webView = replacement
                tabs[index].title = oldTitle
                applyProfile(replacement, profileName)
                configureWebView(replacement)

                if (index == activeTab) {
                    showActiveWebView()
                    replacement.loadUrl(withSelectedLanguage(urlToRestore))
                } else {
                    replacement.loadUrl(withSelectedLanguage(urlToRestore))
                }
                return true
            }
        }
    }

    private fun showActiveWebView() {
        // A WebView can only have one parent. The previous implementation left
        // an inactive WebView attached to its old SwipeRefreshLayout after the
        // tab container was removed, which could crash when switching between
        // multiple tabs (especially when the same page was opened more than once).
        val webView = tabs.getOrNull(activeTab)?.webView ?: return
        (webView.parent as? ViewGroup)?.removeView(webView)
        contentFrame.removeAllViews()

        val refresh = SwipeRefreshLayout(this).apply {
            setColorSchemeColors(ContextCompat.getColor(this@MainActivity, R.color.page_progress_blue))
            addView(webView, ViewGroup.LayoutParams(-1, -1))
            setOnRefreshListener {
                webView.reload()
                postDelayed({ isRefreshing = false }, 800)
            }
        }
        contentFrame.addView(refresh, LinearLayout.LayoutParams(-1, -1))
        updateChromeBar()
    }

    private fun updateChromeBar() {
        if (::tabCountView.isInitialized) tabCountView.text = tabs.size.toString()
        if (::addressBar.isInitialized) {
            currentWebView()?.url?.let { addressBar.setText(it) }
        }
    }

    private fun closeTab(index: Int) {
        if (tabs.size == 1) {
            tabs[0].webView.loadUrl(HOME_URL)
            tabs[0].title = "New tab"
            updateChromeBar()
            saveTabsState()
            return
        }
        val tab = tabs.removeAt(index)
        tab.webView.stopLoading()
        tab.webView.destroy()
        // Remove the tab's private profile after its WebView is gone.
        // The default profile belongs to the first tab and is intentionally kept.
        if (tab.profileName != Profile.DEFAULT_PROFILE_NAME &&
            WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            runCatching { ProfileStore.getInstance().deleteProfile(tab.profileName) }
        }
        activeTab = when {
            activeTab >= tabs.size -> tabs.lastIndex
            index < activeTab -> activeTab - 1
            else -> activeTab
        }
        showActiveWebView()
        saveTabsState()
    }

    private fun showClearAllDataDialog() {
        val dialog = AlertDialog.Builder(this)
            .setMessage("هل تريد مسح جميع البيانات؟")
            .setNegativeButton("لا", null)
            .setPositiveButton("نعم") { _, _ ->
                clearAllBrowserData()
            }
            .create()

        dialog.setOnShowListener {
            val isDark = darkModeEnabled
            val dialogBackground = if (isDark) Color.BLACK else Color.WHITE
            val dialogText = if (isDark) Color.WHITE else Color.BLACK

            dialog.window?.setBackgroundDrawable(
                android.graphics.drawable.ColorDrawable(dialogBackground)
            )
            dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(dialogText)
        }

        dialog.show()
    }

    /**
     * Resets eM browser to a first-install state without uninstalling the APK.
     * All browser/site data and all app preferences created by the browser are removed.
     */
    private fun clearAllBrowserData() {
        // Destroy every WebView first so no page can recreate data while we are clearing it.
        tabs.forEach { tab ->
            tab.webView.stopLoading()
            tab.webView.clearHistory()
            tab.webView.clearCache(true)
            tab.webView.clearFormData()
            tab.webView.clearSslPreferences()
            tab.webView.clearMatches()
            tab.webView.destroy()
        }
        tabs.clear()
        activeTab = 0

        // Clear every tab profile as well as the default profile. Profiles keep
        // separate cookies/storage, so clearing only CookieManager.getInstance()
        // would leave login data behind in other tabs.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            runCatching {
                val store = ProfileStore.getInstance()
                store.getAllProfileNames().forEach { name ->
                    if (name != Profile.DEFAULT_PROFILE_NAME) {
                        store.getProfile(name)?.let { profile ->
                            profile.getCookieManager().removeAllCookies(null)
                            profile.getWebStorage().deleteAllData()
                        }
                    }
                }
            }
        }

        // Clear WebView's default-profile browser stores.
        WebStorage.getInstance().deleteAllData()
        val webViewDatabase = WebViewDatabase.getInstance(this)
        webViewDatabase.clearHttpAuthUsernamePassword()
        webViewDatabase.clearFormData()
        webViewDatabase.clearUsernamePassword()

        // Cookie deletion is asynchronous; finish the reset only after it completes.
        val cookieManager = CookieManager.getInstance()
        cookieManager.removeAllCookies {
            cookieManager.removeSessionCookies {
                cookieManager.flush()
                finishFullBrowserReset()
            }
        }
        cookieManager.flush()
    }

    private fun finishFullBrowserReset() {
        // Remove all preferences saved by eM browser, including appearance and zoom settings.
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().commit()
        incognitoEnabled = false
        darkModeEnabled = false
        zoomPercent = 100

        // Remove app-private files, databases, caches, and preferences created at runtime.
        deleteDirectoryContents(filesDir)
        deleteDirectoryContents(cacheDir)
        deleteDirectoryContents(noBackupFilesDir)
        deleteDirectoryContents(File(applicationInfo.dataDir, "shared_prefs"))
        databaseList().forEach { name -> deleteDatabase(name) }
        externalCacheDir?.let { deleteDirectoryContents(it) }

        // WebView can keep additional runtime data under app_webview/code_cache.
        File(applicationInfo.dataDir, "app_webview").let { if (it.exists()) it.deleteRecursively() }
        File(applicationInfo.dataDir, "code_cache").let { if (it.exists()) it.deleteRecursively() }

        // Re-read the same defaults used by a brand-new installation.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        // Recreate the activity so a completely fresh WebView and UI are constructed.
        recreate()
    }

    private fun deleteDirectoryContents(directory: File) {
        directory.listFiles()?.forEach { file ->
            if (file.isDirectory) file.deleteRecursively() else file.delete()
        }
    }

    private fun showZoomDialog() {
        val appTextColor = if (darkModeEnabled) Color.WHITE else Color.BLACK
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), dp(8))
        }
        val label = TextView(this).apply {
            text = "حجم النص والواجهة: $zoomPercent%"
            textSize = 17f
            setTextColor(appTextColor)
        }
        val seek = SeekBar(this).apply {
            min = MIN_ZOOM
            max = MAX_ZOOM
            progress = zoomPercent
            progressTintList = android.content.res.ColorStateList.valueOf(appTextColor)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(
                if (darkModeEnabled) Color.DKGRAY else Color.LTGRAY
            )
            thumbTintList = android.content.res.ColorStateList.valueOf(appTextColor)
        }
        box.addView(label)
        box.addView(seek)

        val dialog = AlertDialog.Builder(this)
            .setTitle("حجم النص والواجهة")
            .setView(box)
            .setPositiveButton("تم", null)
            .create()

        dialog.setOnShowListener {
            val dialogBackground = if (darkModeEnabled) Color.BLACK else Color.WHITE
            val dialogText = if (darkModeEnabled) Color.WHITE else Color.BLACK
            dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(dialogBackground))
            dialog.findViewById<TextView>(androidx.appcompat.R.id.alertTitle)?.setTextColor(dialogText)
            dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(dialogText)
        }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                zoomPercent = value.coerceIn(MIN_ZOOM, MAX_ZOOM)
                label.text = "حجم النص والواجهة: $zoomPercent%"
                tabs.forEach { it.webView.settings.textZoom = zoomPercent }
                updateChromeBar()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        dialog.setOnDismissListener {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_ZOOM, zoomPercent).apply()
        }
        dialog.show()
    }

    private fun setIncognitoMode(enabled: Boolean) {
        incognitoEnabled = enabled
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_INCOGNITO, enabled).apply()
        if (enabled) clearPrivateData()
        tabs.forEach {
            it.webView.settings.domStorageEnabled = !enabled
            it.webView.settings.databaseEnabled = !enabled
            it.webView.settings.cacheMode = if (enabled) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        }
    }

    private fun clearPrivateData() {
        tabs.forEach {
            it.webView.clearHistory()
            it.webView.clearCache(true)
            it.webView.clearFormData()
            it.webView.clearSslPreferences()
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            tabs.forEach { tab ->
                runCatching {
                    WebViewCompat.getProfile(tab.webView).getCookieManager().removeAllCookies(null)
                    WebViewCompat.getProfile(tab.webView).getWebStorage().deleteAllData()
                }
            }
        } else {
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
        }
        CookieManager.getInstance().flush()
    }

    private fun setDarkMode(enabled: Boolean) {
        darkModeEnabled = enabled
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_DARK, enabled).apply()
        AppCompatDelegate.setDefaultNightMode(
            if (enabled) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !enabled
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !enabled
    }

    private fun currentWebView(): WebView? = tabs.getOrNull(activeTab)?.webView

    private fun withSelectedLanguage(url: String): String {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return url
        val host = runCatching { android.net.Uri.parse(url).host.orEmpty().lowercase(Locale.US) }.getOrDefault("")
        val isGoogle = host == "google.com" || host.endsWith(".google.com")
        // Google/Gmail is always forced to English so automation sees one stable UI.
        // The app's Language setting remains available for non-Google websites.
        val language = if (isGoogle) "en" else if (browserLanguage == "en") "en" else "ar"
        return if (url.contains(Regex("([?&])hl=[^&]*", RegexOption.IGNORE_CASE))) {
            url.replace(Regex("([?&])hl=[^&]*", RegexOption.IGNORE_CASE), "$1hl=$language")
        } else {
            url + if (url.contains("?")) "&hl=$language" else "?hl=$language"
        }
    }

    private fun resolveColor(attr: Int): Int {
        val value = android.util.TypedValue()
        theme.resolveAttribute(attr, value, true)
        return if (value.resourceId != 0) ContextCompat.getColor(this, value.resourceId) else value.data
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onStop() {
        // Persist open tabs and WebView site state before Android may stop the activity/process.
        saveTabsState()
        // Persist WebView cookies/site state before Android may stop the activity/process.
        runCatching { CookieManager.getInstance().flush() }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            tabs.forEach { tab ->
                runCatching { WebViewCompat.getProfile(tab.webView).getCookieManager().flush() }
            }
        }
        super.onStop()
    }

    override fun onDestroy() {
        // Never clear browser/site data automatically when the activity is destroyed.
        // Browsing data is removed only through the user's explicit Clear Browsing Data action.
        tabs.forEach { it.webView.stopLoading(); it.webView.destroy() }
        super.onDestroy()
    }
}
