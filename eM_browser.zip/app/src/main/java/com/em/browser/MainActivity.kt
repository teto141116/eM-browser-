package com.em.browser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebChromeClient
import android.webkit.WebStorage
import android.webkit.WebViewDatabase
import java.io.File
import android.webkit.WebView
import android.webkit.WebViewClient
import android.animation.ObjectAnimator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.core.content.ContextCompat
import androidx.webkit.Profile
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private data class BrowserTab(
        var webView: WebView,
        var profileName: String = Profile.DEFAULT_PROFILE_NAME,
        var title: String = "New tab",
        var thumbnail: Bitmap? = null
    )

    private val tabs = mutableListOf<BrowserTab>()
    private var activeTab = 0
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var rootLayout: LinearLayout
    private lateinit var chromeBar: LinearLayout
    private lateinit var addressBar: android.widget.EditText
    private lateinit var tabCountView: TextView
    private lateinit var contentFrame: LinearLayout
    private lateinit var pageProgress: ProgressBar
    private lateinit var sideMenu: LinearLayout
    private lateinit var systemBottomSpacer: View
    private var progressAnimator: ObjectAnimator? = null

    private var incognitoEnabled = false
    private var darkModeEnabled = false
    private var zoomPercent = 100
    private var countryCode = "EG"
    private var countryName = "Egypt"

    companion object {
        private const val HOME_URL = "https://accounts.google.com/?hl=ar"
        private const val PREFS = "browser_prefs"
        private const val KEY_INCOGNITO = "incognito"
        private const val KEY_DARK = "dark"
        private const val KEY_ZOOM = "zoom"
        private const val KEY_COUNTRY_CODE = "country_code"
        private const val KEY_COUNTRY_NAME = "country_name"
        private const val MIN_ZOOM = 50
        private const val MAX_ZOOM = 120
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        incognitoEnabled = prefs.getBoolean(KEY_INCOGNITO, false)
        darkModeEnabled = prefs.getBoolean(KEY_DARK, false)
        zoomPercent = prefs.getInt(KEY_ZOOM, 100).coerceIn(MIN_ZOOM, MAX_ZOOM)
        countryCode = prefs.getString(KEY_COUNTRY_CODE, "EG") ?: "EG"
        countryName = prefs.getString(KEY_COUNTRY_NAME, "Egypt") ?: "Egypt"

        AppCompatDelegate.setDefaultNightMode(
            if (darkModeEnabled) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )

        buildInterface()
        addTab(homeUrl())
    }

    private fun buildInterface() {
        // Keep the Android status/navigation areas visible instead of drawing the browser UI over them.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = resolveColor(com.google.android.material.R.attr.colorSurface)
        window.navigationBarColor = resolveColor(com.google.android.material.R.attr.colorSurface)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !darkModeEnabled
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !darkModeEnabled

        drawerLayout = DrawerLayout(this).apply {
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        // Android 15 can enforce edge-to-edge for targetSdk 35. Explicitly reserve the system-bar space.
        // Keep browser content below the Android status bar and, importantly,
        // reserve the full navigation-bar area at the bottom. Some Android
        // devices use an overlay/gesture navigation bar, so relying only on
        // WebView scrolling can leave website footer links (Privacy, Terms,
        // Language, etc.) underneath the phone's navigation controls.
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, bars.top, 0, 0)
            if (::systemBottomSpacer.isInitialized) {
                systemBottomSpacer.layoutParams = systemBottomSpacer.layoutParams.apply {
                    height = bars.bottom
                }
                systemBottomSpacer.requestLayout()
            }
            insets
        }

        chromeBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(4), dp(5), dp(4), dp(5))
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
            elevation = dp(2).toFloat()
        }

        fun chromeButton(label: String, size: Float = 24f): TextView = TextView(this).apply {
            text = label
            textSize = size
            gravity = Gravity.CENTER
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            isClickable = true
            isFocusable = true
            background = null
        }

        val menuButton = chromeButton("⋮", 30f).apply {
            contentDescription = "القائمة"
            setOnClickListener { drawerLayout.openDrawer(Gravity.END) }
        }
        chromeBar.addView(menuButton, LinearLayout.LayoutParams(dp(44), dp(48)))

        tabCountView = chromeButton("1", 12f).apply {
            contentDescription = "علامات التبويب"
            setPadding(dp(5), dp(3), dp(5), dp(3))
            background = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.bg_tab_count)
            setOnClickListener { showTabSwitcher() }
        }
        chromeBar.addView(tabCountView, LinearLayout.LayoutParams(dp(22), dp(24)).apply { gravity = Gravity.CENTER_VERTICAL })

        val addButton = chromeButton("+", 30f).apply {
            contentDescription = "تبويب جديد"
            setOnClickListener { addTab(homeUrl()) }
        }
        chromeBar.addView(addButton, LinearLayout.LayoutParams(dp(44), dp(48)))

        addressBar = android.widget.EditText(this).apply {
            textSize = 16f
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setHintTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            hint = "بحث أو إدخال عنوان"
            setPadding(dp(14), 0, dp(14), 0)
            background = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.bg_address_bar)
            isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setOnEditorActionListener { v, _, _ ->
                loadAddress(v.text?.toString().orEmpty())
                true
            }
        }
        chromeBar.addView(addressBar, LinearLayout.LayoutParams(0, dp(40), 1f).apply {
            gravity = Gravity.CENTER_VERTICAL
            marginStart = dp(7)
            marginEnd = dp(7)
        })

        val homeButton = chromeButton("⌂", 28f).apply {
            contentDescription = "الصفحة الرئيسية"
            setOnClickListener { currentWebView()?.loadUrl(homeUrl()) }
        }
        chromeBar.addView(homeButton, LinearLayout.LayoutParams(dp(48), dp(48)))

        // Standard browser-style page loading indicator: a thin, natural blue line
        // directly below the tab/address bar. It does not consume the status-bar area.
        pageProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            isIndeterminate = false
            visibility = View.GONE
            progressDrawable = ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.progress_page)
            setPadding(0, 0, 0, 0)
        }

        contentFrame = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // A dedicated inset spacer guarantees that the bottom of every WebView
        // stays above the phone's system navigation/gesture area.
        systemBottomSpacer = View(this).apply {
            setBackgroundColor(resolveColor(com.google.android.material.R.attr.colorSurface))
        }

        rootLayout.addView(chromeBar, LinearLayout.LayoutParams(-1, dp(58)))
        rootLayout.addView(pageProgress, LinearLayout.LayoutParams(-1, dp(3)))
        rootLayout.addView(contentFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        rootLayout.addView(systemBottomSpacer, LinearLayout.LayoutParams(-1, 0))

        drawerLayout.addView(rootLayout, DrawerLayout.LayoutParams(-1, -1))
        buildSideMenu()
        drawerLayout.addView(sideMenu, DrawerLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.END
            topMargin = dp(12)
            bottomMargin = dp(12)
        })
        ViewCompat.setOnApplyWindowInsetsListener(drawerLayout) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val lp = sideMenu.layoutParams as DrawerLayout.LayoutParams
            lp.topMargin = bars.top + dp(12)
            lp.bottomMargin = bars.bottom + dp(12)
            sideMenu.layoutParams = lp
            insets
        }
        setContentView(drawerLayout)
    }

    private fun buildSideMenu() {
        sideMenu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(16), 0, dp(10))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(28).toFloat()
                setColor(resolveColor(com.google.android.material.R.attr.colorSurface))
            }
            elevation = dp(8).toFloat()
            clipToOutline = true
        }

        val title = TextView(this).apply {
            text = "eM browser"
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(dp(28), dp(6), dp(28), dp(12))
        }
        sideMenu.addView(title)

        fun menuItem(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
            text = label
            textSize = 15.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(resolveColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(dp(28), 0, dp(28), 0)
            // No pressed/selected highlight color: keep the app monochrome.
            background = null
            setOnClickListener { onClick() }
        }

        sideMenu.addView(menuItem("Refresh Page") { currentWebView()?.reload(); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("New Tab") { addTab(homeUrl()); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Incognito") { setIncognitoMode(!incognitoEnabled); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Dark Mode") { setDarkMode(!darkModeEnabled); drawerLayout.closeDrawer(Gravity.END) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Text Size") { drawerLayout.closeDrawer(Gravity.END); showZoomDialog() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Country") { drawerLayout.closeDrawer(Gravity.END); showCountryDialog() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        sideMenu.addView(menuItem("Clear Browsing Data") { drawerLayout.closeDrawer(Gravity.END); showClearAllDataDialog() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
    }

    private data class CountryOption(val name: String, val code: String)

    private fun showCountryDialog() {
        val countries = listOf(
            CountryOption("Afghanistan", "AF"), CountryOption("Albania", "AL"), CountryOption("Algeria", "DZ"),
            CountryOption("Andorra", "AD"), CountryOption("Angola", "AO"), CountryOption("Antigua and Barbuda", "AG"),
            CountryOption("Argentina", "AR"), CountryOption("Armenia", "AM"), CountryOption("Australia", "AU"),
            CountryOption("Austria", "AT"), CountryOption("Azerbaijan", "AZ"), CountryOption("Bahamas", "BS"),
            CountryOption("Bahrain", "BH"), CountryOption("Bangladesh", "BD"), CountryOption("Barbados", "BB"),
            CountryOption("Belarus", "BY"), CountryOption("Belgium", "BE"), CountryOption("Belize", "BZ"),
            CountryOption("Benin", "BJ"), CountryOption("Bhutan", "BT"), CountryOption("Bolivia", "BO"),
            CountryOption("Bosnia and Herzegovina", "BA"), CountryOption("Botswana", "BW"), CountryOption("Brazil", "BR"),
            CountryOption("Brunei", "BN"), CountryOption("Bulgaria", "BG"), CountryOption("Burkina Faso", "BF"),
            CountryOption("Burundi", "BI"), CountryOption("Cambodia", "KH"), CountryOption("Cameroon", "CM"),
            CountryOption("Canada", "CA"), CountryOption("Cape Verde", "CV"), CountryOption("Central African Republic", "CF"),
            CountryOption("Chad", "TD"), CountryOption("Chile", "CL"), CountryOption("China", "CN"),
            CountryOption("Colombia", "CO"), CountryOption("Comoros", "KM"), CountryOption("Costa Rica", "CR"),
            CountryOption("Croatia", "HR"), CountryOption("Cuba", "CU"), CountryOption("Cyprus", "CY"),
            CountryOption("Czechia", "CZ"), CountryOption("Denmark", "DK"), CountryOption("Djibouti", "DJ"),
            CountryOption("Dominica", "DM"), CountryOption("Dominican Republic", "DO"), CountryOption("Ecuador", "EC"),
            CountryOption("Egypt", "EG"), CountryOption("El Salvador", "SV"), CountryOption("Equatorial Guinea", "GQ"),
            CountryOption("Eritrea", "ER"), CountryOption("Estonia", "EE"), CountryOption("Eswatini", "SZ"),
            CountryOption("Ethiopia", "ET"), CountryOption("Fiji", "FJ"), CountryOption("Finland", "FI"),
            CountryOption("France", "FR"), CountryOption("Gabon", "GA"), CountryOption("Gambia", "GM"),
            CountryOption("Georgia", "GE"), CountryOption("Germany", "DE"), CountryOption("Ghana", "GH"),
            CountryOption("Greece", "GR"), CountryOption("Grenada", "GD"), CountryOption("Guatemala", "GT"),
            CountryOption("Guinea", "GN"), CountryOption("Guinea-Bissau", "GW"), CountryOption("Guyana", "GY"),
            CountryOption("Haiti", "HT"), CountryOption("Honduras", "HN"), CountryOption("Hungary", "HU"),
            CountryOption("Iceland", "IS"), CountryOption("India", "IN"), CountryOption("Indonesia", "ID"),
            CountryOption("Iran", "IR"), CountryOption("Iraq", "IQ"), CountryOption("Ireland", "IE"),
            CountryOption("Italy", "IT"), CountryOption("Jamaica", "JM"), CountryOption("Japan", "JP"),
            CountryOption("Jordan", "JO"), CountryOption("Kazakhstan", "KZ"), CountryOption("Kenya", "KE"),
            CountryOption("Kiribati", "KI"), CountryOption("Kuwait", "KW"), CountryOption("Kyrgyzstan", "KG"),
            CountryOption("Laos", "LA"), CountryOption("Latvia", "LV"), CountryOption("Lebanon", "LB"),
            CountryOption("Lesotho", "LS"), CountryOption("Liberia", "LR"), CountryOption("Libya", "LY"),
            CountryOption("Liechtenstein", "LI"), CountryOption("Lithuania", "LT"), CountryOption("Luxembourg", "LU"),
            CountryOption("Madagascar", "MG"), CountryOption("Malawi", "MW"), CountryOption("Malaysia", "MY"),
            CountryOption("Maldives", "MV"), CountryOption("Mali", "ML"), CountryOption("Malta", "MT"),
            CountryOption("Marshall Islands", "MH"), CountryOption("Mauritania", "MR"), CountryOption("Mauritius", "MU"),
            CountryOption("Mexico", "MX"), CountryOption("Micronesia", "FM"), CountryOption("Moldova", "MD"),
            CountryOption("Monaco", "MC"), CountryOption("Mongolia", "MN"), CountryOption("Montenegro", "ME"),
            CountryOption("Morocco", "MA"), CountryOption("Mozambique", "MZ"), CountryOption("Myanmar", "MM"),
            CountryOption("Namibia", "NA"), CountryOption("Nauru", "NR"), CountryOption("Nepal", "NP"),
            CountryOption("Netherlands", "NL"), CountryOption("New Zealand", "NZ"), CountryOption("Nicaragua", "NI"),
            CountryOption("Niger", "NE"), CountryOption("Nigeria", "NG"), CountryOption("North Korea", "KP"),
            CountryOption("North Macedonia", "MK"), CountryOption("Norway", "NO"), CountryOption("Oman", "OM"),
            CountryOption("Pakistan", "PK"), CountryOption("Palau", "PW"), CountryOption("Palestine", "PS"),
            CountryOption("Panama", "PA"), CountryOption("Papua New Guinea", "PG"), CountryOption("Paraguay", "PY"),
            CountryOption("Peru", "PE"), CountryOption("Philippines", "PH"), CountryOption("Poland", "PL"),
            CountryOption("Portugal", "PT"), CountryOption("Qatar", "QA"), CountryOption("Romania", "RO"),
            CountryOption("Russia", "RU"), CountryOption("Rwanda", "RW"), CountryOption("Saint Kitts and Nevis", "KN"),
            CountryOption("Saint Lucia", "LC"), CountryOption("Saint Vincent and the Grenadines", "VC"), CountryOption("Samoa", "WS"),
            CountryOption("San Marino", "SM"), CountryOption("Sao Tome and Principe", "ST"), CountryOption("Saudi Arabia", "SA"),
            CountryOption("Senegal", "SN"), CountryOption("Serbia", "RS"), CountryOption("Seychelles", "SC"),
            CountryOption("Sierra Leone", "SL"), CountryOption("Singapore", "SG"), CountryOption("Slovakia", "SK"),
            CountryOption("Slovenia", "SI"), CountryOption("Solomon Islands", "SB"), CountryOption("Somalia", "SO"),
            CountryOption("South Africa", "ZA"), CountryOption("South Korea", "KR"), CountryOption("South Sudan", "SS"),
            CountryOption("Spain", "ES"), CountryOption("Sri Lanka", "LK"), CountryOption("Sudan", "SD"),
            CountryOption("Suriname", "SR"), CountryOption("Sweden", "SE"), CountryOption("Switzerland", "CH"),
            CountryOption("Syria", "SY"), CountryOption("Taiwan", "TW"), CountryOption("Tajikistan", "TJ"),
            CountryOption("Tanzania", "TZ"), CountryOption("Thailand", "TH"), CountryOption("Timor-Leste", "TL"),
            CountryOption("Togo", "TG"), CountryOption("Tonga", "TO"), CountryOption("Trinidad and Tobago", "TT"),
            CountryOption("Tunisia", "TN"), CountryOption("Turkey", "TR"), CountryOption("Turkmenistan", "TM"),
            CountryOption("Tuvalu", "TV"), CountryOption("Uganda", "UG"), CountryOption("Ukraine", "UA"),
            CountryOption("United Arab Emirates", "AE"), CountryOption("United Kingdom", "GB"), CountryOption("United States", "US"),
            CountryOption("Uruguay", "UY"), CountryOption("Uzbekistan", "UZ"), CountryOption("Vanuatu", "VU"),
            CountryOption("Vatican City", "VA"), CountryOption("Venezuela", "VE"), CountryOption("Vietnam", "VN"),
            CountryOption("Yemen", "YE"), CountryOption("Zambia", "ZM"), CountryOption("Zimbabwe", "ZW")
        ).sortedBy { it.name }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(8))
            setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
        }
        val search = EditText(this).apply {
            hint = "Search country"
            textSize = 16f
            setSingleLine(true)
            setTextColor(if (darkModeEnabled) Color.WHITE else Color.BLACK)
            setHintTextColor(if (darkModeEnabled) Color.LTGRAY else Color.GRAY)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(52)))

        val list = android.widget.ListView(this).apply {
            divider = null
            setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        val dialog = AlertDialog.Builder(this).setTitle("Country").setView(root).create()

        fun updateList(query: String) {
            val filtered = countries.filter { it.name.contains(query.trim(), ignoreCase = true) }
            list.adapter = object : android.widget.BaseAdapter() {
                override fun getCount() = filtered.size
                override fun getItem(position: Int) = filtered[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val item = TextView(this@MainActivity).apply {
                        text = filtered[position].name
                        textSize = 16f
                        gravity = Gravity.CENTER_VERTICAL
                        setTextColor(if (darkModeEnabled) Color.WHITE else Color.BLACK)
                        setPadding(dp(12), 0, dp(12), 0)
                    }
                    return item
                }
            }
        }
        updateList("")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateList(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })
        list.setOnItemClickListener { _, _, position, _ ->
            val query = search.text?.toString().orEmpty().trim()
            val selected = countries.filter { it.name.contains(query, ignoreCase = true) }[position]
            countryCode = selected.code
            countryName = selected.name
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_COUNTRY_CODE, countryCode)
                .putString(KEY_COUNTRY_NAME, countryName)
                .apply()
            dialog.dismiss()
            currentWebView()?.loadUrl(homeUrl())
        }
        dialog.show()
        dialog.window?.setLayout(dp(340), dp(620))
    }

    private fun homeUrl(): String = "https://accounts.google.com/?hl=ar&gl=$countryCode"

    private fun captureTabThumbnail(tab: BrowserTab): Bitmap? {
        val webView = tab.webView
        if (webView.width <= 0 || webView.height <= 0) return tab.thumbnail
        return try {
            val maxWidth = dp(170)
            val ratio = maxWidth.toFloat() / webView.width.toFloat()
            val bitmap = Bitmap.createBitmap(maxWidth, (webView.height * ratio).toInt().coerceAtLeast(dp(120)), Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.scale(ratio, ratio)
            webView.draw(canvas)
            bitmap
        } catch (_: Throwable) {
            tab.thumbnail
        }
    }

    private fun showTabSwitcher() {
        if (tabs.isNotEmpty()) {
            tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
        }

        val backgroundColor = if (darkModeEnabled) Color.BLACK else Color.rgb(248, 248, 248)
        val textColor = if (darkModeEnabled) Color.WHITE else Color.rgb(35, 35, 35)
        val secondaryColor = if (darkModeEnabled) Color.LTGRAY else Color.DKGRAY
        val cardColor = if (darkModeEnabled) Color.rgb(28, 28, 28) else Color.WHITE
        val dialogRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(backgroundColor)
        }
        lateinit var dialog: AlertDialog

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(8))
        }
        val title = TextView(this).apply {
            text = "Tabs (${tabs.size})"
            textSize = 19f
            setTextColor(textColor)
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        dialogRoot.addView(header, LinearLayout.LayoutParams(-1, dp(48)))

        val grid = android.widget.GridLayout(this).apply {
            columnCount = 2
            rowCount = (tabs.size + 1) / 2
            useDefaultMargins = false
        }
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            addView(grid, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        dialogRoot.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val horizontalGap = dp(8)
        val verticalGap = dp(10)
        val cardHeight = dp(220)

        tabs.forEachIndexed { index, tab ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(18).toFloat()
                    setColor(cardColor)
                    setStroke(dp(1), if (index == activeTab) {
                        if (darkModeEnabled) Color.WHITE else Color.DKGRAY
                    } else {
                        if (darkModeEnabled) Color.DKGRAY else Color.rgb(225, 225, 225)
                    })
                }
                elevation = dp(1).toFloat()
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    if (tabs.isNotEmpty()) {
                        tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
                    }
                    activeTab = index
                    dialog.dismiss()
                    showActiveWebView()
                }
            }

            val topRow = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(2), 0, 0, dp(4))
            }
            val tabTitle = TextView(this).apply {
                text = tab.title.ifBlank { "New tab" }
                textSize = 14f
                setTextColor(textColor)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER_VERTICAL
            }
            topRow.addView(tabTitle, LinearLayout.LayoutParams(0, dp(30), 1f))

            val close = TextView(this).apply {
                text = "×"
                textSize = 25f
                gravity = Gravity.CENTER
                setTextColor(secondaryColor)
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    closeTab(index)
                    dialog.dismiss()
                    if (tabs.isNotEmpty()) showTabSwitcher()
                }
            }
            topRow.addView(close, LinearLayout.LayoutParams(dp(32), dp(30)))
            card.addView(topRow, LinearLayout.LayoutParams(-1, dp(34)))

            val thumbnail = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(if (darkModeEnabled) Color.rgb(45, 45, 45) else Color.rgb(242, 242, 242))
                clipToOutline = true
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: android.graphics.Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, dp(13).toFloat())
                    }
                }
                tab.thumbnail?.let { setImageBitmap(it) }
                if (drawable == null) {
                    setImageDrawable(ContextCompat.getDrawable(this@MainActivity, com.em.browser.R.drawable.ic_em_browser))
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                }
            }
            card.addView(thumbnail, LinearLayout.LayoutParams(-1, 0, 1f))

            val lp = android.widget.GridLayout.LayoutParams().apply {
                width = 0
                height = cardHeight
                columnSpec = android.widget.GridLayout.spec(index % 2, 1, 1f)
                rowSpec = android.widget.GridLayout.spec(index / 2)
                setMargins(if (index % 2 == 0) 0 else horizontalGap / 2, verticalGap / 2,
                    if (index % 2 == 0) horizontalGap / 2 else 0, verticalGap / 2)
            }
            grid.addView(card, lp)
        }

        val newTabButton = TextView(this).apply {
            text = "+  New Tab"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(textColor)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(if (darkModeEnabled) Color.rgb(35, 35, 35) else Color.WHITE)
                setStroke(dp(1), if (darkModeEnabled) Color.DKGRAY else Color.rgb(225, 225, 225))
            }
            isClickable = true
            isFocusable = true
            setOnClickListener {
                dialog.dismiss()
                addTab(homeUrl())
            }
        }
        dialogRoot.addView(newTabButton, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(8)
        })

        dialog = AlertDialog.Builder(this)
            .setView(dialogRoot)
            .create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(22).toFloat()
                setColor(backgroundColor)
            })
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.96f).toInt(),
                (resources.displayMetrics.heightPixels * 0.88f).toInt())
        }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.96f).toInt(),
            (resources.displayMetrics.heightPixels * 0.88f).toInt())
    }

    private fun loadAddress(raw: String) {
        val input = raw.trim()
        if (input.isBlank()) return
        val url = if (android.util.Patterns.WEB_URL.matcher(input).matches() &&
            (input.startsWith("http://") || input.startsWith("https://"))) {
            input
        } else if (input.contains(".") && !input.contains(" ")) {
            "https://$input"
        } else {
            "https://www.google.com/search?q=" + android.net.Uri.encode(input)
        }
        progressAnimator?.cancel()
        pageProgress.progress = 0
        pageProgress.visibility = View.VISIBLE
        currentWebView()?.loadUrl(withArabicLanguage(url))
        addressBar.clearFocus()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun addTab(url: String) {
        if (tabs.isNotEmpty()) {
            tabs[activeTab].thumbnail = captureTabThumbnail(tabs[activeTab])
        }

        val profileName = if (tabs.isEmpty()) {
            // Keep the first tab on WebView's default profile so an existing
            // Google Account session remains available there.
            Profile.DEFAULT_PROFILE_NAME
        } else {
            // Every new tab gets its own persistent WebView profile. Cookies,
            // local storage and other site data are therefore not shared with
            // the first tab or with any other tab.
            "em_tab_${System.currentTimeMillis()}_${tabs.size}"
        }

        val webView = WebView(this)
        applyProfile(webView, profileName)
        val tab = BrowserTab(webView = webView, profileName = profileName)
        tabs.add(tab)
        configureWebView(webView)
        activeTab = tabs.lastIndex
        showActiveWebView()
        progressAnimator?.cancel()
        pageProgress.progress = 0
        pageProgress.visibility = View.VISIBLE
        webView.loadUrl(withArabicLanguage(url))
        updateChromeBar()
    }

    private fun applyProfile(webView: WebView, profileName: String) {
        if (profileName == Profile.DEFAULT_PROFILE_NAME) return
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            WebViewCompat.setProfile(webView, profileName)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(webView: WebView) {
        webView.settings.apply {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            builtInZoomControls = false
            displayZoomControls = false
            domStorageEnabled = !incognitoEnabled
            databaseEnabled = !incognitoEnabled
            cacheMode = if (incognitoEnabled) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false
            allowContentAccess = false
            textZoom = zoomPercent
            userAgentString = "${WebSettings.getDefaultUserAgent(this@MainActivity)} eM-browser/2.0 (ar-EG)"
        }

        webView.setBackgroundColor(if (darkModeEnabled) Color.BLACK else Color.WHITE)
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (::pageProgress.isInitialized && view === currentWebView()) {
                    val target = newProgress.coerceIn(0, 100)
                    if (target < 100) {
                        pageProgress.visibility = View.VISIBLE
                    }
                    progressAnimator?.cancel()
                    progressAnimator = ObjectAnimator.ofInt(pageProgress, "progress", pageProgress.progress, target).apply {
                        duration = if (target >= 100) 220L else 260L
                        start()
                    }
                    if (target >= 100) {
                        pageProgress.postDelayed({
                            if (pageProgress.progress >= 100) pageProgress.visibility = View.GONE
                        }, 240L)
                    }
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                view.loadUrl(withArabicLanguage(request.url.toString()))
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.settings.textZoom = zoomPercent
                val index = tabs.indexOfFirst { it.webView === view }
                if (index >= 0) {
                    tabs[index].title = view.title?.ifBlank { "eM browser" } ?: "eM browser"
                    if (index == activeTab) {
                        updateChromeBar()
                        addressBar.setText(url ?: view.url ?: "")
                    }
                }
            }

            override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                // Recover from a WebView renderer crash without taking down the
                // whole browser. This is important when several tabs are open.
                val index = tabs.indexOfFirst { it.webView === view }
                if (index < 0) return true

                val urlToRestore = view.url ?: HOME_URL
                (view.parent as? ViewGroup)?.removeView(view)
                view.stopLoading()
                view.destroy()

                val replacement = WebView(this@MainActivity)
                val oldTitle = tabs[index].title
                val profileName = tabs[index].profileName
                tabs[index].webView = replacement
                tabs[index].title = oldTitle
                applyProfile(replacement, profileName)
                configureWebView(replacement)

                if (index == activeTab) {
                    showActiveWebView()
                    replacement.loadUrl(withArabicLanguage(urlToRestore))
                } else {
                    replacement.loadUrl(withArabicLanguage(urlToRestore))
                }
                return true
            }
        }
    }

    private fun showActiveWebView() {
        // A WebView can only have one parent. The previous implementation left
        // an inactive WebView attached to its old SwipeRefreshLayout after the
        // tab container was removed, which could crash when switching between
        // multiple tabs (especially when the same page was opened more than once).
        val webView = tabs.getOrNull(activeTab)?.webView ?: return
        (webView.parent as? ViewGroup)?.removeView(webView)
        contentFrame.removeAllViews()

        val refresh = SwipeRefreshLayout(this).apply {
            setColorSchemeColors(ContextCompat.getColor(this@MainActivity, R.color.page_progress_blue))
            addView(webView, ViewGroup.LayoutParams(-1, -1))
            setOnRefreshListener {
                webView.reload()
                postDelayed({ isRefreshing = false }, 800)
            }
        }
        contentFrame.addView(refresh, LinearLayout.LayoutParams(-1, -1))
        updateChromeBar()
    }

    private fun updateChromeBar() {
        if (::tabCountView.isInitialized) tabCountView.text = tabs.size.toString()
        if (::addressBar.isInitialized) {
            currentWebView()?.url?.let { addressBar.setText(it) }
        }
    }

    private fun closeTab(index: Int) {
        if (tabs.size == 1) {
            tabs[0].webView.loadUrl(HOME_URL)
            tabs[0].title = "New tab"
            updateChromeBar()
            return
        }
        val tab = tabs.removeAt(index)
        tab.webView.stopLoading()
        tab.webView.destroy()
        // Remove the tab's private profile after its WebView is gone.
        // The default profile belongs to the first tab and is intentionally kept.
        if (tab.profileName != Profile.DEFAULT_PROFILE_NAME &&
            WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            runCatching { ProfileStore.getInstance().deleteProfile(tab.profileName) }
        }
        activeTab = when {
            activeTab >= tabs.size -> tabs.lastIndex
            index < activeTab -> activeTab - 1
            else -> activeTab
        }
        showActiveWebView()
    }

    private fun showClearAllDataDialog() {
        val dialog = AlertDialog.Builder(this)
            .setMessage("هل تريد مسح جميع البيانات؟")
            .setNegativeButton("لا", null)
            .setPositiveButton("نعم") { _, _ ->
                clearAllBrowserData()
            }
            .create()

        dialog.setOnShowListener {
            val isDark = darkModeEnabled
            val dialogBackground = if (isDark) Color.BLACK else Color.WHITE
            val dialogText = if (isDark) Color.WHITE else Color.BLACK

            dialog.window?.setBackgroundDrawable(
                android.graphics.drawable.ColorDrawable(dialogBackground)
            )
            dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(dialogText)
        }

        dialog.show()
    }

    /**
     * Resets eM browser to a first-install state without uninstalling the APK.
     * All browser/site data and all app preferences created by the browser are removed.
     */
    private fun clearAllBrowserData() {
        // Destroy every WebView first so no page can recreate data while we are clearing it.
        tabs.forEach { tab ->
            tab.webView.stopLoading()
            tab.webView.clearHistory()
            tab.webView.clearCache(true)
            tab.webView.clearFormData()
            tab.webView.clearSslPreferences()
            tab.webView.clearMatches()
            tab.webView.destroy()
        }
        tabs.clear()
        activeTab = 0

        // Clear every tab profile as well as the default profile. Profiles keep
        // separate cookies/storage, so clearing only CookieManager.getInstance()
        // would leave login data behind in other tabs.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            runCatching {
                val store = ProfileStore.getInstance()
                store.getAllProfileNames().forEach { name ->
                    if (name != Profile.DEFAULT_PROFILE_NAME) {
                        store.getProfile(name)?.let { profile ->
                            profile.getCookieManager().removeAllCookies(null)
                            profile.getWebStorage().deleteAllData()
                        }
                    }
                }
            }
        }

        // Clear WebView's default-profile browser stores.
        WebStorage.getInstance().deleteAllData()
        val webViewDatabase = WebViewDatabase.getInstance(this)
        webViewDatabase.clearHttpAuthUsernamePassword()
        webViewDatabase.clearFormData()
        webViewDatabase.clearUsernamePassword()

        // Cookie deletion is asynchronous; finish the reset only after it completes.
        val cookieManager = CookieManager.getInstance()
        cookieManager.removeAllCookies {
            cookieManager.removeSessionCookies {
                cookieManager.flush()
                finishFullBrowserReset()
            }
        }
        cookieManager.flush()
    }

    private fun finishFullBrowserReset() {
        // Remove all preferences saved by eM browser, including appearance and zoom settings.
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().commit()
        incognitoEnabled = false
        darkModeEnabled = false
        zoomPercent = 100

        // Remove app-private files, databases, caches, and preferences created at runtime.
        deleteDirectoryContents(filesDir)
        deleteDirectoryContents(cacheDir)
        deleteDirectoryContents(noBackupFilesDir)
        deleteDirectoryContents(File(applicationInfo.dataDir, "shared_prefs"))
        databaseList().forEach { name -> deleteDatabase(name) }
        externalCacheDir?.let { deleteDirectoryContents(it) }

        // WebView can keep additional runtime data under app_webview/code_cache.
        File(applicationInfo.dataDir, "app_webview").let { if (it.exists()) it.deleteRecursively() }
        File(applicationInfo.dataDir, "code_cache").let { if (it.exists()) it.deleteRecursively() }

        // Re-read the same defaults used by a brand-new installation.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        // Recreate the activity so a completely fresh WebView and UI are constructed.
        recreate()
    }

    private fun deleteDirectoryContents(directory: File) {
        directory.listFiles()?.forEach { file ->
            if (file.isDirectory) file.deleteRecursively() else file.delete()
        }
    }

    private fun showZoomDialog() {
        val appTextColor = if (darkModeEnabled) Color.WHITE else Color.BLACK
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), dp(8))
        }
        val label = TextView(this).apply {
            text = "حجم النص والواجهة: $zoomPercent%"
            textSize = 17f
            setTextColor(appTextColor)
        }
        val seek = SeekBar(this).apply {
            min = MIN_ZOOM
            max = MAX_ZOOM
            progress = zoomPercent
            progressTintList = android.content.res.ColorStateList.valueOf(appTextColor)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(
                if (darkModeEnabled) Color.DKGRAY else Color.LTGRAY
            )
            thumbTintList = android.content.res.ColorStateList.valueOf(appTextColor)
        }
        box.addView(label)
        box.addView(seek)

        val dialog = AlertDialog.Builder(this)
            .setTitle("حجم النص والواجهة")
            .setView(box)
            .setPositiveButton("تم", null)
            .create()

        dialog.setOnShowListener {
            val dialogBackground = if (darkModeEnabled) Color.BLACK else Color.WHITE
            val dialogText = if (darkModeEnabled) Color.WHITE else Color.BLACK
            dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(dialogBackground))
            dialog.findViewById<TextView>(androidx.appcompat.R.id.alertTitle)?.setTextColor(dialogText)
            dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(dialogText)
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(dialogText)
        }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                zoomPercent = value.coerceIn(MIN_ZOOM, MAX_ZOOM)
                label.text = "حجم النص والواجهة: $zoomPercent%"
                tabs.forEach { it.webView.settings.textZoom = zoomPercent }
                updateChromeBar()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        dialog.setOnDismissListener {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_ZOOM, zoomPercent).apply()
        }
        dialog.show()
    }

    private fun setIncognitoMode(enabled: Boolean) {
        incognitoEnabled = enabled
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_INCOGNITO, enabled).apply()
        if (enabled) clearPrivateData()
        tabs.forEach {
            it.webView.settings.domStorageEnabled = !enabled
            it.webView.settings.databaseEnabled = !enabled
            it.webView.settings.cacheMode = if (enabled) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        }
    }

    private fun clearPrivateData() {
        tabs.forEach {
            it.webView.clearHistory()
            it.webView.clearCache(true)
            it.webView.clearFormData()
            it.webView.clearSslPreferences()
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            tabs.forEach { tab ->
                runCatching {
                    WebViewCompat.getProfile(tab.webView).getCookieManager().removeAllCookies(null)
                    WebViewCompat.getProfile(tab.webView).getWebStorage().deleteAllData()
                }
            }
        } else {
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
        }
        CookieManager.getInstance().flush()
    }

    private fun setDarkMode(enabled: Boolean) {
        darkModeEnabled = enabled
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_DARK, enabled).apply()
        AppCompatDelegate.setDefaultNightMode(
            if (enabled) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !enabled
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !enabled
    }

    private fun currentWebView(): WebView? = tabs.getOrNull(activeTab)?.webView

    private fun withArabicLanguage(url: String): String {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return url
        if (url.contains("hl=", ignoreCase = true)) return url
        return url + if (url.contains("?")) "&hl=ar" else "?hl=ar"
    }

    private fun resolveColor(attr: Int): Int {
        val value = android.util.TypedValue()
        theme.resolveAttribute(attr, value, true)
        return if (value.resourceId != 0) ContextCompat.getColor(this, value.resourceId) else value.data
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (incognitoEnabled) clearPrivateData()
        tabs.forEach { it.webView.stopLoading(); it.webView.destroy() }
        super.onDestroy()
    }
}
