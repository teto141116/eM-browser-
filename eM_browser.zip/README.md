# eM browser

Lightweight Android WebView browser with Arabic language enforcement and a dynamic Incognito toggle.

## Build
Open the project in Android Studio or push it to GitHub and run:
Actions → Build eM browser → Run workflow.

The generated APK is uploaded as the `eM-browser-debug` artifact.

## Privacy behavior
- Incognito ON clears cookies, cache, history, form data, SSL state and Web Storage when enabled and when the Activity is destroyed.
- Incognito OFF keeps normal WebView cookies/session behavior.
- App itself does not implement telemetry, analytics, advertising SDKs, or an IP collection/transmission service.
- Network requests made by websites loaded inside WebView still go to those websites; the app cannot make the device's IP invisible to the destination server without a proxy/VPN.
